/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        // Every colour is a CSS variable (RGB channels) so one set of class names serves both themes:
        // light (:root) and dark (`html.dark`). Variables are defined in src/styles.css.
        ink: { DEFAULT: 'rgb(var(--c-ink) / <alpha-value>)', soft: 'rgb(var(--c-ink-soft) / <alpha-value>)' },
        paper: 'rgb(var(--c-paper) / <alpha-value>)',
        surface: 'rgb(var(--c-surface) / <alpha-value>)',
        raised: 'rgb(var(--c-raised) / <alpha-value>)',
        field: 'rgb(var(--c-field) / <alpha-value>)',
        teal: { DEFAULT: 'rgb(var(--c-teal) / <alpha-value>)', dark: 'rgb(var(--c-teal-dark) / <alpha-value>)', 50: 'rgb(var(--c-teal-50) / <alpha-value>)' },
        'on-teal': 'rgb(var(--c-on-teal) / <alpha-value>)',
        violet: { DEFAULT: 'rgb(var(--c-violet) / <alpha-value>)', soft: 'rgb(var(--c-violet-soft) / <alpha-value>)' },
        gold: { DEFAULT: 'rgb(var(--c-gold) / <alpha-value>)', soft: 'rgb(var(--c-gold-soft) / <alpha-value>)' },
        line: { DEFAULT: 'rgb(var(--c-line) / <alpha-value>)', strong: 'rgb(var(--c-line-strong) / <alpha-value>)' },
        danger: { DEFAULT: 'rgb(var(--c-danger) / <alpha-value>)', soft: 'rgb(var(--c-danger-soft) / <alpha-value>)' },
        'on-danger': 'rgb(var(--c-on-danger) / <alpha-value>)',
        success: { soft: 'rgb(var(--c-success-soft) / <alpha-value>)', ink: 'rgb(var(--c-success-ink) / <alpha-value>)' },
      },
      fontFamily: {
        display: ['Inter', '-apple-system', 'BlinkMacSystemFont', 'Segoe UI', 'sans-serif'],
        body: ['Inter', '-apple-system', 'BlinkMacSystemFont', 'sans-serif'],
      },
      borderRadius: {
        sm: '6px',
        DEFAULT: '8px',
        md: '10px',
        lg: '14px',
        xl: '18px',
        '2xl': '22px',
      },
      boxShadow: {
        panel: 'var(--shadow-panel)',
        card: 'var(--shadow-card)',
        lift: 'var(--shadow-lift)',
        pop: 'var(--shadow-pop)',
        glow: 'var(--shadow-glow)',
      },
      keyframes: {
        'pulse-live': {
          '0%': { boxShadow: '0 0 0 0 rgba(52,211,153,.5)' },
          '70%': { boxShadow: '0 0 0 6px rgba(52,211,153,0)' },
          '100%': { boxShadow: '0 0 0 0 rgba(52,211,153,0)' },
        },
        'fade-up': {
          '0%': { opacity: '0', transform: 'translateY(10px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        'fade-in': { '0%': { opacity: '0' }, '100%': { opacity: '1' } },
        'pop-in': {
          '0%': { opacity: '0', transform: 'scale(.97) translateY(4px)' },
          '100%': { opacity: '1', transform: 'scale(1) translateY(0)' },
        },
        shimmer: { '100%': { transform: 'translateX(100%)' } },
        'timer-pulse': {
          '0%, 100%': { boxShadow: '0 0 0 0 rgb(var(--c-danger) / .35)' },
          '50%': { boxShadow: '0 0 0 6px rgb(var(--c-danger) / 0)' },
        },
        'draw-line': { '0%': { strokeDashoffset: '1' }, '100%': { strokeDashoffset: '0' } },
        'grow-x': { '0%': { transform: 'scaleX(0)' }, '100%': { transform: 'scaleX(1)' } },
        'grow-y': { '0%': { transform: 'scaleY(0)' }, '100%': { transform: 'scaleY(1)' } },
      },
      animation: {
        'pulse-live': 'pulse-live 2s infinite',
        'fade-up': 'fade-up .5s cubic-bezier(.2,.7,.2,1) both',
        'fade-in': 'fade-in .35s ease both',
        'pop-in': 'pop-in .2s ease both',
        'timer-pulse': 'timer-pulse 1.2s ease-in-out infinite',
      },
    },
  },
  plugins: [],
};
