// Salary is optional and estimated - jobs may have neither, just one bound,
// or a full range. Formats whatever is present, or returns null if nothing was set.
export function formatSalaryRange(min, max, type) {
  const hasMin = min !== null && min !== undefined && min !== '';
  const hasMax = max !== null && max !== undefined && max !== '';
  if (!hasMin && !hasMax) return null;

  const fmt = (n) => Number(n).toLocaleString('en-US');
  const suffix = type === 'Annual' ? '/yr' : '/mo';

  if (hasMin && hasMax) return `₱${fmt(min)} - ₱${fmt(max)}${suffix}`;
  if (hasMin) return `From ₱${fmt(min)}${suffix}`;
  return `Up to ₱${fmt(max)}${suffix}`;
}

// The applicant's own stated expectation - a single figure, not a range.
export function formatExpectedSalary(amount, type) {
  if (amount === null || amount === undefined || amount === '') return null;
  const suffix = type === 'Annual' ? '/yr' : '/mo';
  return `₱${Number(amount).toLocaleString('en-US')}${suffix}`;
}

// ---- Dashboard helpers ----------------------------------------------------

// "2 hours ago", "3 days ago", or a short date once it's older than a week.
export function timeAgo(dateInput) {
  if (!dateInput) return '';
  const then = new Date(dateInput).getTime();
  if (isNaN(then)) return '';
  const diff = Math.max(0, Date.now() - then) / 1000;
  if (diff < 60) return 'Just now';
  if (diff < 3600) { const m = Math.floor(diff / 60); return `${m} min${m === 1 ? '' : 's'} ago`; }
  if (diff < 86400) { const h = Math.floor(diff / 3600); return `${h} hour${h === 1 ? '' : 's'} ago`; }
  if (diff < 7 * 86400) { const d = Math.floor(diff / 86400); return `${d} day${d === 1 ? '' : 's'} ago`; }
  return new Date(dateInput).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' });
}

export function initials(name = '') {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  if (parts.length === 0) return '?';
  return (parts[0][0] + (parts.length > 1 ? parts[parts.length - 1][0] : '')).toUpperCase();
}

export function greeting(date = new Date()) {
  const h = date.getHours();
  return h < 12 ? 'Good morning' : h < 18 ? 'Good afternoon' : 'Good evening';
}

export function capitalize(s = '') {
  return s ? s[0].toUpperCase() + s.slice(1) : s;
}

// Shared score bands so rings, pills and charts agree on colour.
export function scoreBand(score) {
  return score >= 75 ? 'high' : score >= 50 ? 'mid' : 'low';
}

// Application status ENUM from schema.sql, in pipeline order (the "happy path" plus rejected).
export const STATUSES = ['submitted', 'screened', 'shortlisted', 'interview', 'offer', 'rejected'];

// Every value the applications.status column can hold. 'withdrawn' is set by the applicant and
// 'archived' by HR; neither is part of the hiring pipeline itself.
export const ALL_STATUSES = [...STATUSES, 'withdrawn', 'archived'];

// Statuses where the application is closed to further action (no interview, no status changes).
export const INACTIVE_STATUSES = ['withdrawn', 'archived'];

// Display names for statuses. The database values stay the same, only the wording lives here.
export const STATUS_LABELS = {
  submitted: 'Submitted', screened: 'Screened', shortlisted: 'Shortlisted', interview: 'Interview',
  offer: 'Offer', rejected: 'Rejected', withdrawn: 'Withdrawn', archived: 'Archived',
};
export const statusLabel = (status) => STATUS_LABELS[status] || capitalize(String(status || ''));

// AI technical interview session statuses (interview_sessions.status). "not_started" means no session row yet.
export const INTERVIEW_STATUSES = ['not_started', 'in_progress', 'completed', 'timed_out', 'cancelled'];
export const INTERVIEW_STATUS_LABELS = {
  not_started: 'Not started', in_progress: 'In progress', completed: 'Completed', timed_out: 'Timed out', cancelled: 'Cancelled',
};
export const interviewStatusLabel = (status) => INTERVIEW_STATUS_LABELS[status || 'not_started'] || capitalize(String(status));

// Dot colours used in menus so a status is recognisable at a glance.
export const STATUS_DOTS = {
  submitted: 'bg-ink-soft', screened: 'bg-teal', shortlisted: 'bg-violet', interview: 'bg-gold',
  offer: 'bg-success-ink', rejected: 'bg-danger', withdrawn: 'bg-line-strong', archived: 'bg-line-strong',
};

// 12:05 style countdown text.
export function formatClock(totalSeconds) {
  const s = Math.max(0, Math.floor(totalSeconds));
  return `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;
}
