import api from '../api';

// The resume endpoint is protected by the JWT in the Authorization header. A plain link or
// window.open() cannot send that header (which is why it used to answer "Not authenticated"),
// so the file is fetched through the shared axios instance and shown from a temporary blob URL.
//
//   await openResume(applicationId)                    PDF / TXT open in a new tab, other types download
//   await openResume(applicationId, { download: true }) always downloads
//
// Throws an Error with a readable message on failure (permission denied, file missing, network).

async function readError(err) {
  // With responseType 'blob' an error body arrives as a Blob, so parse the JSON message out of it.
  try {
    const text = await err.response.data.text();
    return JSON.parse(text).error;
  } catch {
    return null;
  }
}

function filenameFrom(headers, fallback) {
  const match = /filename="?([^";]+)"?/i.exec(headers?.['content-disposition'] || '');
  return match ? match[1] : fallback;
}

function saveBlob(url, filename) {
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
}

export async function openResume(applicationId, { download = false } = {}) {
  // Open the tab first, synchronously inside the click, or popup blockers will stop it.
  const tab = download ? null : window.open('', '_blank');
  if (tab) {
    tab.document.title = 'Resume';
    tab.document.body.innerHTML = '<p style="font-family:system-ui,sans-serif;padding:24px;color:#475569">Loading resume...</p>';
  }

  try {
    const res = await api.get(`/applications/${applicationId}/resume`, {
      responseType: 'blob',
      params: download ? { download: 1 } : undefined,
    });
    const type = res.headers['content-type'] || res.data.type || '';
    const filename = filenameFrom(res.headers, 'resume');
    const url = URL.createObjectURL(new Blob([res.data], { type }));
    const viewable = /pdf|text\/plain/i.test(type);

    if (tab && viewable) {
      tab.location.href = url;
    } else {
      tab?.close(); // Word files cannot be rendered by the browser, so they download instead
      saveBlob(url, filename);
    }
    setTimeout(() => URL.revokeObjectURL(url), 5 * 60 * 1000);
  } catch (err) {
    tab?.close();
    const message = (err.response && (await readError(err))) || 'The resume could not be opened.';
    throw new Error(message);
  }
}
