import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { io } from 'socket.io-client';
import api, { API_ORIGIN } from '../api';
import { useAuth } from './AuthContext';
import { useToast } from './ToastContext';
import { interviewStatusLabel, statusLabel } from '../utils/format';

const SocketContext = createContext(null);

export function SocketProvider({ children }) {
  const { user } = useAuth();
  const toast = useToast();
  const socketRef = useRef(null);
  const activeThreadRef = useRef(null); // application id of the chat thread currently on screen
  const [connected, setConnected] = useState(false);
  const [notifications, setNotifications] = useState([]); // recent notifications, kept so the bell dropdown has something to show
  const [unreadCount, setUnreadCount] = useState(0); // drives the bell badge; resets when the bell is opened
  const [unreadMessages, setUnreadMessages] = useState(0); // drives the badge on the Messages link

  const refreshUnreadMessages = useCallback(() => {
    if (!user) return;
    api.get('/messages/unread-count').then((res) => setUnreadMessages(res.data.count)).catch(() => {});
  }, [user]);

  useEffect(() => {
    if (user) refreshUnreadMessages();
    else setUnreadMessages(0);
  }, [user, refreshUnreadMessages]);

  // ChatThread tells us which thread is open, so an incoming message for it doesn't
  // pop a toast or bump the unread badge. Returns a cleanup function.
  const setActiveThread = useCallback((applicationId) => {
    activeThreadRef.current = applicationId === null ? null : Number(applicationId);
    return () => { if (activeThreadRef.current === Number(applicationId)) activeThreadRef.current = null; };
  }, []);

  useEffect(() => {
    // No user logged in yet -> don't open a connection
    if (!user) {
      socketRef.current?.disconnect();
      socketRef.current = null;
      setConnected(false);
      return undefined;
    }

    const token = localStorage.getItem('token');
    const socket = io(API_ORIGIN, {
      auth: { token }, // this is what socket.js on the server verifies
    });

    socket.on('connect', () => setConnected(true));
    socket.on('disconnect', () => setConnected(false));

    // Server pushes this whenever a message/status change is relevant to this user,
    // even if they're not currently looking at that application's page.
    socket.on('notification', (notif) => {
      setNotifications((prev) => [notif, ...prev].slice(0, 20));
      setUnreadCount((prev) => prev + 1);

      const viewingThisThread = notif.type === 'message' && activeThreadRef.current === Number(notif.applicationId);
      if (notif.type === 'message' && !viewingThisThread) {
        setUnreadMessages((n) => n + 1);
        toast.info('New message', { description: notif.preview });
      } else if (notif.type === 'interview_report') {
        toast.info('Assessment report ready', { description: 'The Technical Assessment Report has been generated.' });
      } else if (notif.type === 'interview_status') {
        if (user.role === 'applicant') {
          toast.warning('Interview timed out', { description: 'The 20 minute limit ended and your interview was submitted automatically.' });
        } else {
          toast.info(`Interview ${interviewStatusLabel(notif.status).toLowerCase()}`, { description: 'An applicant interview session has ended.' });
        }
      } else if (notif.type === 'status') {
        if (user.role === 'hr' && notif.status === 'withdrawn') {
          toast.info('Application withdrawn', { description: 'An applicant withdrew their application.' });
        } else if (user.role === 'applicant') {
          toast.info('Application Updated', { description: `Your application status is now ${statusLabel(notif.status)}.` });
        }
      }
    });

    // AI screening could not finish (provider down, unreadable output...). The application page shows
    // the reason and a retry; this just makes sure nobody is left staring at "Analyzing...".
    socket.on('screening:failed', () => {
      if (user.role === 'applicant') {
        toast.warning('Screening did not finish', { description: 'We could not analyze your resume automatically. Open the application to try again.' });
      } else {
        toast.warning('AI screening failed', { description: 'An application could not be screened. Open it and use Re-run AI.' });
      }
    });

    socketRef.current = socket;

    return () => socket.disconnect();
  }, [user, toast]);

  // Called when the bell is opened: dismisses the "new" badge, but keeps the
  // notification list itself so there's still something to show/click into.
  function markNotificationsRead() {
    setUnreadCount(0);
  }

  const value = useMemo(() => ({
    socket: socketRef.current, connected, notifications, unreadCount, markNotificationsRead,
    unreadMessages, refreshUnreadMessages, setActiveThread,
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }), [connected, notifications, unreadCount, unreadMessages, refreshUnreadMessages, setActiveThread, user]);

  return <SocketContext.Provider value={value}>{children}</SocketContext.Provider>;
}

export function useSocket() {
  return useContext(SocketContext);
}
