import { createContext, useContext, useState } from 'react';
import api from '../api';

// React Context is how you share state (like "who's logged in") across
// your whole app without passing it down through every component's props
// manually. Any component can call useAuth() and get the current user.
const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  // Lazy-init from localStorage so a page refresh doesn't log the user out
  const [user, setUser] = useState(() => {
    const saved = localStorage.getItem('user');
    return saved ? JSON.parse(saved) : null;
  });

  async function login(email, password) {
    const { data } = await api.post('/auth/login', { email, password });
    localStorage.setItem('token', data.token);
    localStorage.setItem('user', JSON.stringify(data.user));
    setUser(data.user);
    return data.user;
  }

  async function register(payload) {
    const { data } = await api.post('/auth/register', payload);
    localStorage.setItem('token', data.token);
    localStorage.setItem('user', JSON.stringify(data.user));
    setUser(data.user);
    return data.user;
  }

  function logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    setUser(null);
  }

  // Whatever we put in "value" is what components get back from useAuth()
  return (
    <AuthContext.Provider value={{ user, login, register, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

// A small custom hook so components just write `const { user } = useAuth()`
// instead of importing useContext + AuthContext everywhere.
export function useAuth() {
  return useContext(AuthContext);
}
