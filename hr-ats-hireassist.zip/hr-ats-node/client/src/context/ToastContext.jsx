import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';

// The app's single toast (notification pop-up) system.
//   const toast = useToast();
//   toast.success('Application Submitted', { description: 'We are screening your resume now.' });
// Types: success | error | warning | info. Toasts stack, animate in and out, pause while hovered,
// disappear on their own (errors stay a little longer) and can be dismissed with the close button.
const ToastContext = createContext(null);

const ICONS = {
  success: 'bi-check-circle-fill',
  error: 'bi-x-circle-fill',
  warning: 'bi-exclamation-triangle-fill',
  info: 'bi-info-circle-fill',
};
const DEFAULT_DURATION = { success: 4000, info: 4500, warning: 6000, error: 7000 };
const LEAVE_MS = 220;
const MAX_VISIBLE = 4;

let counter = 0;

function ToastItem({ toast, onDismiss }) {
  const [paused, setPaused] = useState(false);
  const remaining = useRef(toast.duration);
  const startedAt = useRef(0);

  // Auto-dismiss timer that survives hover pauses (resumes with whatever time was left).
  useEffect(() => {
    if (paused || toast.leaving || !toast.duration) return undefined;
    startedAt.current = Date.now();
    const timer = setTimeout(() => onDismiss(toast.id), remaining.current);
    return () => {
      clearTimeout(timer);
      remaining.current = Math.max(600, remaining.current - (Date.now() - startedAt.current));
    };
  }, [paused, toast.leaving, toast.duration, toast.id, onDismiss]);

  return (
    <div
      className={`toast toast--${toast.type} ${toast.leaving ? 'is-leaving' : ''}`}
      role={toast.type === 'error' ? 'alert' : 'status'}
      onMouseEnter={() => setPaused(true)} onMouseLeave={() => setPaused(false)}
      onFocus={() => setPaused(true)} onBlur={() => setPaused(false)}
    >
      <span className="toast__icon" aria-hidden="true"><i className={`bi ${ICONS[toast.type]}`}></i></span>
      <div className="toast__body">
        <div className="toast__title">{toast.title}</div>
        {toast.description && <div className="toast__desc">{toast.description}</div>}
      </div>
      <button type="button" className="toast__close" onClick={() => onDismiss(toast.id)} aria-label="Dismiss notification">
        <i className="bi bi-x-lg" aria-hidden="true"></i>
      </button>
    </div>
  );
}

export function ToastProvider({ children }) {
  const [toasts, setToasts] = useState([]);

  const dismiss = useCallback((id) => {
    setToasts((list) => list.map((t) => (t.id === id ? { ...t, leaving: true } : t)));
    setTimeout(() => setToasts((list) => list.filter((t) => t.id !== id)), LEAVE_MS);
  }, []);

  const push = useCallback((type, title, options = {}) => {
    const duration = options.duration ?? DEFAULT_DURATION[type];
    setToasts((list) => {
      // The same message twice in a row (double click, socket echo) shows once.
      if (list.some((t) => !t.leaving && t.type === type && t.title === title && t.description === options.description)) return list;
      const next = { id: ++counter, type, title, description: options.description, duration, leaving: false };
      return [...list, next].slice(-MAX_VISIBLE);
    });
  }, []);

  const api = useMemo(() => ({
    success: (title, options) => push('success', title, options),
    error: (title, options) => push('error', title, options),
    warning: (title, options) => push('warning', title, options),
    info: (title, options) => push('info', title, options),
    dismiss,
  }), [push, dismiss]);

  return (
    <ToastContext.Provider value={api}>
      {children}
      <div className="toast-viewport" aria-live="polite" aria-relevant="additions">
        {toasts.map((t) => <ToastItem key={t.id} toast={t} onDismiss={dismiss} />)}
      </div>
    </ToastContext.Provider>
  );
}

export function useToast() {
  return useContext(ToastContext);
}
