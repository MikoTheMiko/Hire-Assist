import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { ThemeProvider } from './context/ThemeContext';
import { ToastProvider } from './context/ToastContext';
import { SocketProvider } from './context/SocketContext';
import ProtectedRoute from './components/ProtectedRoute';
import PublicLayout from './components/layout/PublicLayout';
import HrLayout from './components/HrLayout';

import JobsList from './pages/JobsList';
import JobDetail from './pages/JobDetail';
import Login from './pages/Login';
import Register from './pages/Register';
import Apply from './pages/Apply';
import ApplicantDashboard from './pages/ApplicantDashboard';
import ApplicantApplicationView from './pages/ApplicantApplicationView';
import Interview from './pages/Interview';
import HrDashboard from './pages/HrDashboard';
import HrApplications from './pages/HrApplications';
import HrInterviews from './pages/HrInterviews';
import HrMessages from './pages/HrMessages';
import ApplicantMessages from './pages/ApplicantMessages';
import HrJobs from './pages/HrJobs';
import HrPostJob from './pages/HrPostJob';
import HrApplicationView from './pages/HrApplicationView';

// This is the whole app's structure in one place: which URL shows which
// page. Compare this to how the PHP version was one .php file per URL —
// here it's one component per "page", and React swaps them in without a
// full page reload.
//
// Two layouts: PublicLayout (topbar, used for public browsing + the
// applicant side) and HrLayout (sidebar, used for the whole /hr/* area).
// Theme and toast providers wrap everything so both layouts share them.
export default function App() {
  return (
    <ThemeProvider>
    <ToastProvider>
    <AuthProvider>
      <SocketProvider>
        <BrowserRouter>
          <Routes>
            <Route element={<PublicLayout />}>
              <Route path="/" element={<JobsList />} />
              <Route path="/jobs/:id" element={<JobDetail />} />
              <Route path="/login" element={<Login />} />
              <Route path="/register" element={<Register />} />

              <Route path="/apply/:jobId" element={
                <ProtectedRoute role="applicant"><Apply /></ProtectedRoute>
              } />
              <Route path="/applications" element={
                <ProtectedRoute role="applicant"><ApplicantDashboard /></ProtectedRoute>
              } />
              <Route path="/applications/:id" element={
                <ProtectedRoute role="applicant"><ApplicantApplicationView /></ProtectedRoute>
              } />
              <Route path="/messages" element={
                <ProtectedRoute role="applicant"><ApplicantMessages /></ProtectedRoute>
              } />
              <Route path="/applications/:id/interview" element={
                <ProtectedRoute role="applicant"><Interview /></ProtectedRoute>
              } />
            </Route>

            <Route element={<HrLayout />}>
              <Route path="/hr/dashboard" element={
                <ProtectedRoute role="hr"><HrDashboard /></ProtectedRoute>
              } />
              <Route path="/hr/applications" element={
                <ProtectedRoute role="hr"><HrApplications /></ProtectedRoute>
              } />
              <Route path="/hr/interviews" element={
                <ProtectedRoute role="hr"><HrInterviews /></ProtectedRoute>
              } />
              <Route path="/hr/messages" element={
                <ProtectedRoute role="hr"><HrMessages /></ProtectedRoute>
              } />
              <Route path="/hr/jobs" element={
                <ProtectedRoute role="hr"><HrJobs /></ProtectedRoute>
              } />
              <Route path="/hr/post-job" element={
                <ProtectedRoute role="hr"><HrPostJob /></ProtectedRoute>
              } />
              <Route path="/hr/jobs/:id/edit" element={
                <ProtectedRoute role="hr"><HrPostJob /></ProtectedRoute>
              } />
              <Route path="/hr/applications/:id" element={
                <ProtectedRoute role="hr"><HrApplicationView /></ProtectedRoute>
              } />
            </Route>
          </Routes>
        </BrowserRouter>
      </SocketProvider>
    </AuthProvider>
    </ToastProvider>
    </ThemeProvider>
  );
}
