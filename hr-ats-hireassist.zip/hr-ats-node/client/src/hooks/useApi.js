import { useCallback, useEffect, useRef, useState } from 'react';

// Small data-fetching hook used by every HR page/card.
//   const { data, loading, refreshing, error, reload } = useApi((signal) => fn(signal), [deps]);
// - `loading`    true only until the FIRST result arrives (drives skeletons)
// - `refreshing` true while re-fetching after deps changed (old data stays visible)
// - stale responses can never overwrite newer ones: each request aborts the previous
//   one and its result is ignored unless it is still the latest.
export default function useApi(fetcher, deps = []) {
  const [state, setState] = useState({ data: null, error: null, pending: true });
  const [tick, setTick] = useState(0);
  const latest = useRef(0);
  const fetcherRef = useRef(fetcher);
  fetcherRef.current = fetcher;

  useEffect(() => {
    const requestId = ++latest.current;
    const controller = new AbortController();
    setState((s) => ({ ...s, error: null, pending: true }));

    Promise.resolve(fetcherRef.current(controller.signal))
      .then((data) => {
        if (requestId === latest.current) setState({ data, error: null, pending: false });
      })
      .catch((err) => {
        if (err?.code === 'ERR_CANCELED' || err?.name === 'CanceledError' || requestId !== latest.current) return;
        setState((s) => ({
          ...s,
          pending: false,
          error: err?.response?.data?.error || err?.message || 'Request failed',
        }));
      });

    return () => controller.abort();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [...deps, tick]);

  const reload = useCallback(() => setTick((t) => t + 1), []);

  return {
    data: state.data,
    error: state.error,
    loading: state.pending && state.data === null && !state.error,
    refreshing: state.pending && state.data !== null,
    reload,
    setData: (updater) => setState((s) => ({ ...s, data: typeof updater === 'function' ? updater(s.data) : updater })),
  };
}
