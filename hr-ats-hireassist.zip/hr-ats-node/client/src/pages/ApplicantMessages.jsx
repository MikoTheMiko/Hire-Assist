import { Link } from 'react-router-dom';
import MessagesInbox from '../components/messages/MessagesInbox';

// Applicant inbox: the same experience as the HR one, scoped by the API to this applicant's own
// applications (GET /api/messages/mine/conversations). Every application is listed so a
// conversation with the recruiter can be started even before the first message.
export default function ApplicantMessages() {
  return (
    <div className="a-page">
      <header className="a-header">
        <div>
          <h1 className="a-title">Messages</h1>
          <p className="a-sub">Your conversations with recruiters, updated live.</p>
        </div>
        <Link to="/applications" className="btn btn-outline-secondary"><i className="bi bi-folder2-open" aria-hidden="true"></i> My applications</Link>
      </header>
      <MessagesInbox
        listPath="/messages/mine/conversations"
        applicationPath={(id) => `/applications/${id}`}
        height="h-[calc(100vh-290px)] min-h-[480px]"
        titleFor={(c) => c.job_title}
        subtitleFor={(c) => `Recruiter: ${c.counterpart_name}`}
        emptyList={{
          icon: 'bi-chat-dots', title: 'No conversations yet',
          message: 'Once you apply for a job, you can message the recruiter here.',
          action: <Link to="/" className="btn btn-sm btn-primary">Browse open jobs</Link>,
        }}
      />
    </div>
  );
}
