import { useEffect, useMemo, useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import api from '../api';
import useApi from '../hooks/useApi';
import useDebounce from '../hooks/useDebounce';
import { useSocket } from '../context/SocketContext';
import { ALL_STATUSES, STATUS_DOTS, statusLabel, timeAgo } from '../utils/format';
import MenuSelect from '../components/ui/MenuSelect';
import PageHeader from '../components/ui/PageHeader';
import SearchInput from '../components/ui/SearchInput';
import Avatar from '../components/ui/Avatar';
import ScoreDial from '../components/ScoreDial';
import StatusBadge from '../components/StatusBadge';
import Skeleton from '../components/ui/Skeleton';
import EmptyState from '../components/ui/EmptyState';
import ErrorState from '../components/ui/ErrorState';

// Score filter -> query params understood by GET /api/applications
const SCORE_FILTERS = {
  '': {},
  '90': { min_score: 90 },
  '75': { min_score: 75 },
  '50': { min_score: 50 },
  low: { max_score: 49 },
  none: { unscored: 1 },
};

export default function HrApplications() {
  const navigate = useNavigate();
  const { socket } = useSocket();
  const [params] = useSearchParams(); // dashboard charts deep-link here (?status=…&job=…)
  const [search, setSearch] = useState('');
  const [jobFilter, setJobFilter] = useState(params.get('job') || '');
  const [statusFilter, setStatusFilter] = useState(ALL_STATUSES.includes(params.get('status')) ? params.get('status') : '');
  const [scoreFilter, setScoreFilter] = useState('');
  const debouncedSearch = useDebounce(search, 300);

  const jobs = useApi((signal) => api.get('/jobs/mine/list', { signal }).then((r) => r.data), []);

  // Server-side filtering: the search string and filters go to the API.
  // useApi aborts the previous request, so a slow old response can't overwrite a newer one.
  const { data: applications, loading, refreshing, error, reload, setData } = useApi(
    (signal) => {
      const query = { ...SCORE_FILTERS[scoreFilter] };
      if (jobFilter) query.job_id = jobFilter;
      if (statusFilter) query.status = statusFilter;
      if (debouncedSearch.trim()) query.search = debouncedSearch.trim();
      return api.get('/applications', { params: query, signal }).then((r) => r.data);
    },
    [debouncedSearch, jobFilter, statusFilter, scoreFilter]
  );

  // AI scores land in place as screening finishes (existing behaviour)
  useEffect(() => {
    if (!socket) return undefined;
    function handleScreeningComplete({ applicationId, result }) {
      setData((prev) => prev && prev.map((a) =>
        a.id === applicationId ? { ...a, ai_overall_score: result.overall_score, ai_error: null, status: a.status === 'submitted' ? 'screened' : a.status } : a
      ));
    }
    function handleScreeningFailed({ applicationId, error }) {
      setData((prev) => prev && prev.map((a) => (a.id === applicationId ? { ...a, ai_error: error } : a)));
    }
    socket.on('screening:complete', handleScreeningComplete);
    socket.on('screening:failed', handleScreeningFailed);
    return () => {
      socket.off('screening:complete', handleScreeningComplete);
      socket.off('screening:failed', handleScreeningFailed);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [socket]);

  const filtersActive = !!(search || jobFilter || statusFilter || scoreFilter);
  const resetAll = () => { setSearch(''); setJobFilter(''); setStatusFilter(''); setScoreFilter(''); };
  const open = (id) => navigate(`/hr/applications/${id}`);
  const count = applications?.length ?? 0;
  const subtitle = useMemo(() => (
    applications ? `${count} candidate${count === 1 ? '' : 's'}${filtersActive ? ' match your filters' : ' across your active positions'}` : 'Manage and review candidates applying to your positions.'
  ), [applications, count, filtersActive]);

  return (
    <div>
      <PageHeader title="Applications" subtitle={subtitle} />

      <div className="toolbar">
        <SearchInput value={search} onChange={setSearch} placeholder="Search applicants..." label="Search applicants by name, email or job title" />
        <div className="toolbar-filters">
          <MenuSelect value={statusFilter} onChange={setStatusFilter} ariaLabel="Filter by status" prefix="Status"
            options={[{ value: '', label: 'All active' }, ...ALL_STATUSES.map((st) => ({ value: st, label: statusLabel(st), dot: STATUS_DOTS[st] }))]} />
          <MenuSelect value={jobFilter} onChange={setJobFilter} ariaLabel="Filter by job" prefix="Job"
            options={[{ value: '', label: 'All jobs' }, ...(jobs.data || []).map((j) => ({ value: String(j.id), label: j.title }))]} />
          <MenuSelect value={scoreFilter} onChange={setScoreFilter} ariaLabel="Filter by AI score" prefix="Score" options={[
            { value: '', label: 'Any' }, { value: '90', label: '90 and above' }, { value: '75', label: '75 and above' },
            { value: '50', label: '50 and above' }, { value: 'low', label: 'Below 50' }, { value: 'none', label: 'Not scored yet' }]} />
          {filtersActive && (
            <button className="btn btn-sm btn-outline-secondary" onClick={resetAll}><i className="bi bi-x-circle"></i> Reset</button>
          )}
        </div>
      </div>

      {error && <div className="card"><ErrorState message="Unable to load applications." onRetry={reload} /></div>}

      {loading && (
        <div className="card p-4 space-y-3">
          {[0, 1, 2, 3, 4].map((i) => <Skeleton key={i} className="h-14 w-full" />)}
        </div>
      )}

      {!loading && !error && applications && applications.length === 0 && (
        <div className="card">
          <EmptyState
            icon="bi-search"
            title={filtersActive ? 'No applications found' : 'No applications yet'}
            message={filtersActive ? 'Try a different search or clear your filters.' : 'Start receiving applications to see candidates here.'}
            action={filtersActive
              ? <button className="btn btn-sm btn-outline-secondary" onClick={resetAll}>Clear search &amp; filters</button>
              : <Link to="/hr/jobs" className="btn btn-sm btn-outline-secondary">Go to Jobs</Link>}
          />
        </div>
      )}

      {!error && applications && applications.length > 0 && (
        <div className={`transition-opacity ${refreshing ? 'opacity-60' : ''}`}>
          {/* Table on larger screens (scrolls horizontally if it must) */}
          <div className="hidden md:block card overflow-x-auto">
            <table className="table-modern">
              <thead>
                <tr><th>Candidate</th><th>Position</th><th>AI score</th><th>Status</th><th>Applied</th><th></th></tr>
              </thead>
              <tbody>
                {applications.map((app) => (
                  <tr key={app.id} className="row-link" onClick={() => open(app.id)}>
                    <td>
                      <div className="flex items-center gap-3">
                        <Avatar name={app.applicant_name} size={38} />
                        <div className="min-w-0">
                          <div className="font-semibold">
                            <Link to={`/hr/applications/${app.id}`} className="!text-ink hover:!text-teal" onClick={(e) => e.stopPropagation()}>{app.applicant_name}</Link>
                            {app.unread_count > 0 && <span className="badge bg-danger text-on-danger ml-2" title="Unread messages"><i className="bi bi-chat-fill"></i> {app.unread_count}</span>}
                          </div>
                          <div className="text-xs text-ink-soft truncate">{app.applicant_email}</div>
                        </div>
                      </div>
                    </td>
                    <td className="text-ink/90">{app.job_title}</td>
                    <td>{app.ai_overall_score !== null ? <ScoreDial score={app.ai_overall_score} size={46} /> : <span className={`text-xs ${app.ai_error ? 'text-danger' : 'text-ink-soft'}`} title={app.ai_error || undefined}>{app.ai_error ? 'Failed' : 'Analyzing...'}</span>}</td>
                    <td><StatusBadge status={app.status} /></td>
                    <td className="text-ink-soft text-xs whitespace-nowrap" title={new Date(app.created_at).toLocaleString()}>{timeAgo(app.created_at)}</td>
                    <td className="text-right"><i className="bi bi-chevron-right text-ink-soft"></i></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Stacked cards on mobile */}
          <div className="md:hidden space-y-3">
            {applications.map((app) => (
              <Link key={app.id} to={`/hr/applications/${app.id}`} className="card card-hover p-4 block !text-ink hover:!text-ink">
                <div className="flex justify-between items-start gap-3 mb-3">
                  <div className="flex items-center gap-3 min-w-0">
                    <Avatar name={app.applicant_name} size={40} />
                    <div className="min-w-0">
                      <div className="font-semibold truncate">{app.applicant_name}
                        {app.unread_count > 0 && <span className="badge bg-danger text-on-danger ml-1.5">{app.unread_count}</span>}
                      </div>
                      <div className="text-xs text-ink-soft truncate">{app.applicant_email}</div>
                    </div>
                  </div>
                  {app.ai_overall_score !== null ? <ScoreDial score={app.ai_overall_score} size={46} /> : <span className={`text-xs shrink-0 ${app.ai_error ? 'text-danger' : 'text-ink-soft'}`} title={app.ai_error || undefined}>{app.ai_error ? 'Failed' : 'Analyzing...'}</span>}
                </div>
                <div className="text-sm mb-3">{app.job_title}</div>
                <div className="flex justify-between items-center gap-2">
                  <StatusBadge status={app.status} />
                  <span className="text-xs text-ink-soft">{timeAgo(app.created_at)}</span>
                </div>
              </Link>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
