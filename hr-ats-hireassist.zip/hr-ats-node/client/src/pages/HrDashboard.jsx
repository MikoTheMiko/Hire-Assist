import { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useSocket } from '../context/SocketContext';
import { greeting } from '../utils/format';
import KpiRow from '../components/dashboard/KpiRow';
import ApplicationsOverview from '../components/dashboard/ApplicationsOverview';
import PipelineCard from '../components/dashboard/PipelineCard';
import JobsPerformanceCard from '../components/dashboard/JobsPerformanceCard';
import ScreeningDistributionCard from '../components/dashboard/ScreeningDistributionCard';
import InterviewPerformanceCard from '../components/dashboard/InterviewPerformanceCard';
import RecentApplicationsCard from '../components/dashboard/RecentApplicationsCard';
import RecentInterviewsCard from '../components/dashboard/RecentInterviewsCard';

// The HR home: real analytics from /api/dashboard/*. Every card loads and fails
// independently (own skeleton / error / empty state), so one slow or failing
// query never blanks the whole page.
export default function HrDashboard() {
  const { user } = useAuth();
  const { socket } = useSocket();
  const [refreshKey, setRefreshKey] = useState(0);
  const firstName = (user?.name || '').split(' ')[0];

  // Live refresh: when the AI finishes screening a resume or an interview report
  // lands, every card silently re-fetches (old numbers stay visible meanwhile).
  useEffect(() => {
    if (!socket) return undefined;
    const bump = () => setRefreshKey((k) => k + 1);
    const onNotification = (n) => { if (n?.type === 'interview_report' || n?.type === 'status') bump(); };
    socket.on('screening:complete', bump);
    socket.on('notification', onNotification);
    return () => { socket.off('screening:complete', bump); socket.off('notification', onNotification); };
  }, [socket]);

  return (
    <div className="space-y-5 sm:space-y-6">
      <div className="mb-1">
        <h1 className="page-title">{greeting()}{firstName ? `, ${firstName}` : ''}</h1>
        <p className="page-sub">Here&apos;s what&apos;s happening with your hiring pipeline.</p>
      </div>

      <KpiRow refreshKey={refreshKey} />

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-5 sm:gap-6">
        <div className="xl:col-span-2"><ApplicationsOverview refreshKey={refreshKey} /></div>
        <PipelineCard refreshKey={refreshKey} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5 sm:gap-6">
        <JobsPerformanceCard refreshKey={refreshKey} />
        <ScreeningDistributionCard refreshKey={refreshKey} />
      </div>

      <InterviewPerformanceCard refreshKey={refreshKey} />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5 sm:gap-6">
        <RecentApplicationsCard refreshKey={refreshKey} />
        <RecentInterviewsCard refreshKey={refreshKey} />
      </div>
    </div>
  );
}
