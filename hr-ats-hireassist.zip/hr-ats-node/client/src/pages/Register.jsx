import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import SegmentedControl from '../components/ui/SegmentedControl';

export default function Register() {
  const { register } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: '', email: '', role: 'applicant', desired_position: '', password: '', confirm: '' });
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);

  function update(field) {
    return (e) => setForm((f) => ({ ...f, [field]: e.target.value }));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setError(null);

    if (form.password.length < 6) return setError('Password must be at least 6 characters.');
    if (form.password !== form.confirm) return setError('Passwords do not match.');

    setLoading(true);
    try {
      const user = await register(form);
      navigate(user.role === 'hr' ? '/hr/dashboard' : '/applications');
    } catch (err) {
      setError(err.response?.data?.error || 'Registration failed.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="flex justify-center pt-4 sm:pt-10">
      <div className="w-full max-w-md">
        <div className="card">
          <div className="p-6 sm:p-8">
            <h1 className="auth-title">Create your account</h1>
            <p className="auth-sub">Apply to jobs with AI-assisted screening, or post roles as a recruiter.</p>
            {error && <div className="alert-danger mb-4" role="alert">{error}</div>}
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <span className="field-label">I am a...</span>
                <SegmentedControl full ariaLabel="Account type" value={form.role} onChange={(v) => setForm((f) => ({ ...f, role: v }))} options={[{ value: 'applicant', label: 'Job Applicant', icon: 'bi-person' }, { value: 'hr', label: 'HR / Recruiter', icon: 'bi-briefcase' }]} />
              </div>
              <div>
                <label className="field-label" htmlFor="reg-name">Full Name</label>
                <input id="reg-name" className="input" value={form.name} onChange={update('name')} required />
              </div>
              <div>
                <label className="field-label" htmlFor="reg-email">Email</label>
                <input id="reg-email" type="email" className="input" value={form.email} onChange={update('email')} required />
              </div>
              <div>
                <label className="field-label" htmlFor="reg-position">Desired Position <span className="text-ink-soft font-normal">(optional)</span></label>
                <input id="reg-position" className="input" value={form.desired_position} onChange={update('desired_position')} placeholder="e.g. Backend Developer" />
              </div>
              <div>
                <label className="field-label" htmlFor="reg-password">Password</label>
                <input id="reg-password" type="password" className="input" value={form.password} onChange={update('password')} required minLength={6} />
              </div>
              <div>
                <label className="field-label" htmlFor="reg-confirm">Confirm Password</label>
                <input id="reg-confirm" type="password" className="input" value={form.confirm} onChange={update('confirm')} required minLength={6} />
              </div>
              <button className="btn btn-primary w-full" disabled={loading}>{loading ? 'Creating account...' : 'Register'}</button>
            </form>
            <p className="text-center text-sm text-ink-soft mt-4 mb-0">Already have an account? <Link to="/login">Log in</Link></p>
          </div>
        </div>
      </div>
    </div>
  );
}
