import { useState } from 'react';
import { Link } from 'react-router-dom';
import api from '../api';
import MenuSelect from '../components/ui/MenuSelect';
import useApi from '../hooks/useApi';
import useDebounce from '../hooks/useDebounce';
import { formatSalaryRange, capitalize } from '../utils/format';
import PageHeader from '../components/ui/PageHeader';
import SearchInput from '../components/ui/SearchInput';
import Skeleton from '../components/ui/Skeleton';
import EmptyState from '../components/ui/EmptyState';
import ErrorState from '../components/ui/ErrorState';

const STATUS_STYLE = {
  open: 'bg-success-soft text-success-ink border border-success-ink/20',
  draft: 'bg-gold-soft text-gold border border-gold/20',
  closed: 'bg-raised text-ink-soft border border-line',
};

export default function HrJobs() {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [sort, setSort] = useState('newest');
  const [actionError, setActionError] = useState('');
  const [confirmDeleteId, setConfirmDeleteId] = useState(null);
  const [busyId, setBusyId] = useState(null);
  const debouncedSearch = useDebounce(search, 300);

  // Server-side search/filter/sort: GET /api/jobs/mine/list?full=1&search=&status=&sort=
  const { data: jobs, loading, refreshing, error, reload } = useApi(
    (signal) => {
      const params = { full: 1, sort };
      if (debouncedSearch.trim()) params.search = debouncedSearch.trim();
      if (statusFilter) params.status = statusFilter;
      return api.get('/jobs/mine/list', { params, signal }).then((r) => r.data);
    },
    [debouncedSearch, statusFilter, sort]
  );

  const filtersActive = !!(search || statusFilter);
  const resetAll = () => { setSearch(''); setStatusFilter(''); };

  async function handleToggleStatus(job) {
    const nextStatus = job.status === 'open' ? 'closed' : 'open';
    setBusyId(job.id);
    setActionError('');
    try {
      await api.patch(`/jobs/${job.id}/status`, { status: nextStatus });
      reload(); // re-query so an active status filter stays correct
    } catch (err) {
      setActionError(err.response?.data?.error || 'Could not update this job.');
    } finally {
      setBusyId(null);
    }
  }

  async function handleDelete(job) {
    setBusyId(job.id);
    setActionError('');
    try {
      await api.delete(`/jobs/${job.id}`);
      reload();
    } catch (err) {
      setActionError(err.response?.data?.error || 'Could not delete this job.');
    } finally {
      setBusyId(null);
      setConfirmDeleteId(null);
    }
  }

  return (
    <div>
      <PageHeader
        title="Jobs"
        subtitle={jobs ? `${jobs.length} position${jobs.length === 1 ? '' : 's'}${filtersActive ? ' match your filters' : ''}` : 'Manage your recruitment positions.'}
        actions={<Link to="/hr/post-job" className="btn btn-primary"><i className="bi bi-plus-lg"></i> Post New Job</Link>}
      />

      <div className="toolbar">
        <SearchInput value={search} onChange={setSearch} placeholder="Search jobs..." label="Search jobs by title, description, department or skills" />
        <div className="toolbar-filters">
          <MenuSelect value={statusFilter} onChange={setStatusFilter} ariaLabel="Filter by status" prefix="Status" options={[
            { value: '', label: 'All' }, { value: 'open', label: 'Open', dot: 'bg-success-ink' },
            { value: 'draft', label: 'Draft', dot: 'bg-gold' }, { value: 'closed', label: 'Closed', dot: 'bg-line-strong' }]} />
          <MenuSelect value={sort} onChange={setSort} ariaLabel="Sort jobs" prefix="Sort" options={[
            { value: 'newest', label: 'Newest first' }, { value: 'oldest', label: 'Oldest first' },
            { value: 'title', label: 'Title A to Z' }, { value: 'applicants', label: 'Most applicants' }]} />
          {filtersActive && <button className="btn btn-sm btn-outline-secondary" onClick={resetAll}><i className="bi bi-x-circle"></i> Reset</button>}
        </div>
      </div>

      {actionError && <div className="alert-danger mb-4">{actionError}</div>}
      {error && <div className="card"><ErrorState message="Unable to load jobs." onRetry={reload} /></div>}

      {loading && <div className="space-y-3">{[0, 1, 2, 3].map((i) => <Skeleton key={i} className="h-[92px] w-full !rounded-2xl" />)}</div>}

      {!loading && !error && jobs && jobs.length === 0 && (
        <div className="card">
          {filtersActive ? (
            <EmptyState icon="bi-search" title="No jobs found" message="Try a different search or clear your filters."
              action={<button className="btn btn-sm btn-outline-secondary" onClick={resetAll}>Clear search &amp; filters</button>} />
          ) : (
            <EmptyState icon="bi-briefcase" title="No active jobs" message="Create a job posting to start recruiting."
              action={<Link to="/hr/post-job" className="btn btn-sm btn-primary"><i className="bi bi-plus-lg"></i> Post New Job</Link>} />
          )}
        </div>
      )}

      {!error && jobs && jobs.length > 0 && (
        <div className={`space-y-3 transition-opacity ${refreshing ? 'opacity-60' : ''}`}>
          {jobs.map((job) => {
            const salary = formatSalaryRange(job.salary_min, job.salary_max, job.salary_type);
            const isBusy = busyId === job.id;
            const applicants = Number(job.application_count);
            return (
              <div key={job.id} className="card card-hover p-4 sm:p-5">
                <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                  <div className="min-w-0">
                    <div className="flex items-center gap-2.5 flex-wrap mb-1.5">
                      <Link to={`/jobs/${job.id}`} className="font-display font-bold text-[1.08rem] !text-ink hover:!text-teal">{job.title}</Link>
                      <span className={`badge ${STATUS_STYLE[job.status] || STATUS_STYLE.closed}`}>{capitalize(job.status)}</span>
                    </div>
                    <div className="text-ink-soft text-sm">
                      {job.department || 'General'} &middot; {job.employment_type} &middot; {job.seniority_level}
                      {salary && <> &middot; <span className="text-ink/80">{salary}</span></>}
                    </div>
                  </div>

                  <div className="flex items-center gap-3 sm:gap-4 flex-wrap shrink-0">
                    <Link to={applicants ? `/hr/applications?job=${job.id}` : '#'}
                          className={`text-center px-3 !text-ink ${applicants ? 'hover:!text-teal' : 'pointer-events-none'}`}
                          aria-label={`${applicants} applicants`}>
                      <div className="font-display text-2xl font-extrabold leading-none tabular">{applicants}</div>
                      <div className="text-[0.68rem] uppercase tracking-wider text-ink-soft mt-1">Applicant{applicants === 1 ? '' : 's'}</div>
                    </Link>
                    <div className="flex gap-2 flex-wrap">
                      <Link to={`/hr/jobs/${job.id}/edit`} className="btn btn-sm btn-outline-secondary"><i className="bi bi-pencil"></i> Edit</Link>
                      {job.status !== 'draft' && (
                        <button className="btn btn-sm btn-outline-primary" onClick={() => handleToggleStatus(job)} disabled={isBusy}
                                title={job.status === 'open' ? 'Stop accepting new applications' : 'Start accepting applications again'}>
                          <i className={`bi ${job.status === 'open' ? 'bi-lock' : 'bi-unlock'}`}></i>
                          {job.status === 'open' ? 'Close Job' : 'Reopen Job'}
                        </button>
                      )}
                      <button className="btn btn-sm btn-outline-secondary hover:!text-danger hover:!border-danger/50" onClick={() => setConfirmDeleteId(job.id)} aria-label={`Delete ${job.title}`}>
                        <i className="bi bi-trash3"></i> Delete
                      </button>
                    </div>
                  </div>
                </div>

                {confirmDeleteId === job.id && (
                  <div className="mt-4 pt-4 border-t border-line animate-pop-in">
                    <div className="alert-danger flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                      <div>
                        <p className="font-semibold mb-0.5"><i className="bi bi-exclamation-triangle-fill mr-1"></i> Delete &quot;{job.title}&quot;?</p>
                        <p className="mb-0 text-sm opacity-90">This will permanently remove the job and associated application data.</p>
                      </div>
                      <div className="flex gap-2 shrink-0">
                        <button className="btn btn-sm btn-outline-secondary" onClick={() => setConfirmDeleteId(null)} disabled={isBusy}>Cancel</button>
                        <button className="btn btn-sm btn-danger" onClick={() => handleDelete(job)} disabled={isBusy}>{isBusy ? 'Deleting...' : 'Delete Job'}</button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
