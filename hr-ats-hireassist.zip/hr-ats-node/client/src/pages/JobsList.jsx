import { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import api from '../api';
import { useAuth } from '../context/AuthContext';
import useDebounce from '../hooks/useDebounce';
import SearchBar from '../components/forms/SearchBar';
import JobCard from '../components/cards/JobCard';
import HeroPreview from '../components/cards/HeroPreview';
import Skeleton from '../components/ui/Skeleton';

const STEPS = [
  { icon: 'bi-search', title: 'Find a job', text: 'Browse open roles or search by title, skill or department.' },
  { icon: 'bi-file-earmark-arrow-up', title: 'Apply with your resume', text: 'Upload a PDF, DOCX or TXT, or paste your resume text.' },
  { icon: 'bi-chat-square-dots', title: 'Take the AI technical interview', text: 'Answer role-specific multiple-choice and short-answer questions in 20 minutes.' },
  { icon: 'bi-graph-up-arrow', title: 'Track your application', text: 'Follow your status and scores live, and message the recruiter.' },
];

const FEATURES = [
  { icon: 'bi-file-earmark-text', title: 'Resume analysis', text: 'Every resume is read and scored against the role the moment you apply.', preview: 'resume' },
  { icon: 'bi-bullseye', title: 'Skill matching', text: 'See which required skills were found, and which are missing.', preview: 'skills' },
  { icon: 'bi-mic', title: 'AI technical interview', text: 'Questions are generated from the job requirements and your background.', preview: 'interview' },
  { icon: 'bi-clipboard-check', title: 'Automated evaluation', text: 'Technical and communication scores with a written assessment.', preview: 'eval' },
  { icon: 'bi-signpost-split', title: 'Application tracking', text: 'A clear status from submitted to offer, updated in real time.', preview: 'track' },
];

function FeaturePreview({ kind }) {
  if (kind === 'resume') return <div className="fp fp-resume"><i></i><i></i><i></i><i className="short"></i><b></b></div>;
  if (kind === 'skills') return <div className="fp fp-skills"><span className="ok">Matched</span><span className="ok">Matched</span><span className="no">Missing</span></div>;
  if (kind === 'interview') return <div className="fp fp-interview"><small>Question 3 of 8</small><div className="bar"><b style={{ width: '38%' }}></b></div><span>Multiple choice</span></div>;
  if (kind === 'eval') return <div className="fp fp-eval"><div><small>Technical</small><div className="bar"><b style={{ width: '80%' }}></b></div></div><div><small>Communication</small><div className="bar"><b style={{ width: '65%' }}></b></div></div></div>;
  return <div className="fp fp-track"><span className="d on"></span><span className="l on"></span><span className="d on"></span><span className="l"></span><span className="d"></span></div>;
}

export default function JobsList() {
  const { user } = useAuth();
  const [query, setQuery] = useState('');
  const debounced = useDebounce(query, 300);
  const [jobs, setJobs] = useState([]);
  const [totals, setTotals] = useState(null); // { jobs, departments } — from the unfiltered list
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const listRef = useRef(null);

  useEffect(() => {
    let cancelled = false;
    const term = debounced.trim();
    setLoading(true);
    api.get('/jobs', { params: term ? { q: term } : {} })
      .then((res) => {
        if (cancelled) return;
        setJobs(res.data);
        setError('');
        if (!term) setTotals({ jobs: res.data.length, departments: new Set(res.data.map((j) => j.department).filter(Boolean)).size });
      })
      .catch(() => { if (!cancelled) setError('We could not load jobs right now. Please try again.'); })
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, [debounced]);

  const searching = debounced.trim() !== '';
  const firstLoad = loading && jobs.length === 0 && !totals;

  return (
    <>
      {/* ---------- Hero ---------- */}
      <section className="hero-section">
        <div className="lp-wrap hero-grid">
          <div className="hero-copy">
            <span className="eyebrow-badge"><i className="bi bi-stars" aria-hidden="true"></i> AI-assisted recruitment</span>
            <h1 className="hero-title">Get hired through fair, AI-assisted screening.</h1>
            <p className="hero-lead">Apply once. Your resume is scored against the role, you take a focused 20 minute AI technical interview, and recruiters review the results. Follow every step live.</p>

            <SearchBar
              value={query}
              onChange={setQuery}
              busy={loading && searching}
              placeholder="Search by job title, skill or department"
              label="Search open jobs"
              onSubmit={() => listRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' })}
            />

            <div className="hero-actions">
              <a className="btn btn-primary" href="#open-jobs">Browse open jobs <i className="bi bi-arrow-right" aria-hidden="true"></i></a>
              {!user && <Link className="btn btn-outline-secondary" to="/register">Create an account</Link>}
              {user?.role === 'applicant' && <Link className="btn btn-outline-secondary" to="/applications">My applications</Link>}
            </div>

            {totals && (
              <dl className="hero-stats">
                <div><dd>{totals.jobs}</dd><dt>Open positions</dt></div>
                <div><dd>{totals.departments}</dd><dt>Departments hiring</dt></div>
              </dl>
            )}
          </div>
          <HeroPreview />
        </div>
      </section>

      {/* ---------- Jobs ---------- */}
      <section id="open-jobs" className="lp-section lp-section--jobs" ref={listRef}>
        <div className="lp-wrap">
          <div className="lp-head lp-head--row">
            <div>
              <h2 className="lp-h2">{searching ? 'Search results' : 'Open positions'}</h2>
              <p className="lp-sub" aria-live="polite">
                {searching
                  ? `${loading ? 'Searching...' : `${jobs.length} ${jobs.length === 1 ? 'job matches' : 'jobs match'}`} “${debounced.trim()}”`
                  : 'Browse current openings and apply directly online.'}
              </p>
            </div>
            {searching && <button className="btn btn-sm btn-outline-secondary" onClick={() => setQuery('')}>Clear search</button>}
          </div>

          {error && <div className="alert-danger mb-4" role="alert">{error}</div>}

          {firstLoad ? (
            <div className="job-grid">{[0, 1, 2].map((i) => <Skeleton key={i} className="h-64 !rounded-2xl" />)}</div>
          ) : jobs.length === 0 && !error ? (
            <div className="lp-empty">
              <i className={`bi ${searching ? 'bi-search' : 'bi-briefcase'}`} aria-hidden="true"></i>
              <h3>{searching ? 'No jobs match your search' : 'No open positions right now'}</h3>
              <p>{searching ? 'Try a different keyword, or clear the search to see every opening.' : 'Check back soon. New roles are posted regularly.'}</p>
              {searching && <button className="btn btn-outline-primary" onClick={() => setQuery('')}>Clear search</button>}
            </div>
          ) : (
            <div className={`job-grid${loading ? ' is-loading' : ''}`}>
              {jobs.map((job) => <JobCard key={job.id} job={job} />)}
            </div>
          )}
        </div>
      </section>

      {/* ---------- How it works ---------- */}
      <section className="lp-section lp-section--alt">
        <div className="lp-wrap">
          <div className="lp-head">
            <h2 className="lp-h2">How it works</h2>
            <p className="lp-sub">From first click to final decision, in four steps.</p>
          </div>
          <ol className="steps">
            {STEPS.map((s, i) => (
              <li key={s.title} className="step">
                <span className="step__num">{String(i + 1).padStart(2, '0')}</span>
                <span className="step__icon" aria-hidden="true"><i className={`bi ${s.icon}`}></i></span>
                <h3>{s.title}</h3>
                <p>{s.text}</p>
              </li>
            ))}
          </ol>
        </div>
      </section>

      {/* ---------- AI features ---------- */}
      <section className="lp-section lp-section--ai">
        <div className="lp-wrap">
          <div className="lp-head">
            <h2 className="lp-h2">Hiring assisted by AI, decided by people</h2>
            <p className="lp-sub">The same tools recruiters use, so you always know where you stand.</p>
          </div>
          <div className="features">
            {FEATURES.map((f) => (
              <div key={f.title} className="feature">
                <FeaturePreview kind={f.preview} />
                <h3><i className={`bi ${f.icon}`} aria-hidden="true"></i> {f.title}</h3>
                <p>{f.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
