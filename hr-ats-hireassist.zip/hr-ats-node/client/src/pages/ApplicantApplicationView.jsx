import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import api from '../api';
import { useSocket } from '../context/SocketContext';
import ScoreDial from '../components/ScoreDial';
import StatusBadge, { InterviewStatusBadge } from '../components/StatusBadge';
import ConfirmDialog from '../components/ui/ConfirmDialog';
import { useToast } from '../context/ToastContext';
import ChatThread from '../components/ChatThread';
import { formatExpectedSalary, INACTIVE_STATUSES } from '../utils/format';

export default function ApplicantApplicationView() {
  const { id } = useParams();
  const { socket } = useSocket();
  const toast = useToast();
  const [withdrawOpen, setWithdrawOpen] = useState(false);
  const [withdrawing, setWithdrawing] = useState(false);
  const [app, setApp] = useState(null);
  const [interview, setInterview] = useState(undefined); // undefined = loading, null = not started
  const [retrying, setRetrying] = useState(false);

  useEffect(() => {
    api.get(`/applications/${id}`).then((res) => setApp(res.data));
    api.get(`/interviews/${id}`).then((res) => setInterview(res.data.session));
  }, [id]);

  useEffect(() => {
    if (!socket) return;
    function handleScreeningComplete(payload) {
      if (payload.applicationId === Number(id)) {
        setApp((prev) => ({
          ...prev,
          ai_overall_score: payload.result.overall_score,
          ai_skills_score: payload.result.skills_score,
          ai_experience_score: payload.result.experience_score,
          ai_education_score: payload.result.education_score,
          ai_summary: payload.result.summary,
          ai_strengths: JSON.stringify(payload.result.strengths || []),
          ai_gaps: JSON.stringify(payload.result.gaps || []),
          ai_error: null,
        }));
        setRetrying(false);
      }
    }
    function handleScreeningFailed(payload) {
      if (payload.applicationId === Number(id)) {
        setApp((prev) => (prev ? { ...prev, ai_error: payload.error } : prev));
        setRetrying(false);
      }
    }
    function handleStatusChange(payload) {
      if (payload.applicationId === Number(id)) {
        setApp((prev) => ({ ...prev, status: payload.status }));
      }
    }
    socket.on('screening:complete', handleScreeningComplete);
    socket.on('screening:failed', handleScreeningFailed);
    socket.on('application:status', handleStatusChange);
    // Keep the interview card honest if the session ends elsewhere (timer, withdraw, another tab)
    function handleInterviewStatus(payload) {
      if (payload.applicationId === Number(id)) api.get(`/interviews/${id}`).then((res) => setInterview(res.data.session));
    }
    socket.on('interview:status', handleInterviewStatus);
    return () => {
      socket.off('interview:status', handleInterviewStatus);
      socket.off('screening:complete', handleScreeningComplete);
      socket.off('screening:failed', handleScreeningFailed);
      socket.off('application:status', handleStatusChange);
    };
  }, [socket, id]);

  async function handleRetryScreening() {
    setRetrying(true);
    try {
      await api.post(`/applications/${id}/retry-screening`);
      setApp((prev) => ({ ...prev, ai_error: null }));
      // the result (or a new failure) arrives over the socket
    } catch (err) {
      setRetrying(false);
      toast.error('Could not retry screening', { description: err.response?.data?.error || 'Please try again in a moment.' });
    }
  }

  async function handleWithdraw() {
    setWithdrawing(true);
    try {
      await api.post(`/applications/${id}/withdraw`);
      setApp((prev) => ({ ...prev, status: 'withdrawn' }));
      setInterview((prev) => (prev && prev.status === 'in_progress' ? { ...prev, status: 'cancelled', current_question: null } : prev));
      setWithdrawOpen(false);
      toast.success('Application Withdrawn', { description: 'You will no longer be considered for this position.' });
    } catch (err) {
      setWithdrawOpen(false);
      toast.error('Could not withdraw', { description: err.response?.data?.error || 'Please try again.' });
    } finally {
      setWithdrawing(false);
    }
  }

  if (!app) return <p className="text-ink-soft">Loading...</p>;
  const closed = INACTIVE_STATUSES.includes(app.status);

  const strengths = app.ai_strengths ? JSON.parse(app.ai_strengths) : [];
  const gaps = app.ai_gaps ? JSON.parse(app.ai_gaps) : [];

  return (
    <div>
      <div className="mb-4"><Link to="/applications" className="text-sm">&larr; Back to My Applications</Link></div>

      <div className="flex justify-between items-start mb-5 flex-wrap gap-3">
        <div>
          <h3 className="text-2xl mb-1">{app.job_title}</h3>
          <p className="text-ink-soft mb-2">{app.department || 'General'} &middot; Applied {new Date(app.created_at).toLocaleDateString()}</p>
          <StatusBadge status={app.status} />
          {formatExpectedSalary(app.expected_salary, app.expected_salary_type) && (
            <p className="text-ink-soft text-sm mt-2 mb-0">
              <i className="bi bi-cash-stack"></i> Your expected salary: {formatExpectedSalary(app.expected_salary, app.expected_salary_type)}
            </p>
          )}
        </div>
        {!closed && (
          <button type="button" className="btn btn-outline-secondary" onClick={() => setWithdrawOpen(true)}>
            <i className="bi bi-box-arrow-left" aria-hidden="true"></i> Withdraw Application
          </button>
        )}
      </div>

      {app.status === 'withdrawn' && (
        <div className="alert-info mb-5 flex items-start gap-2" role="status">
          <i className="bi bi-info-circle mt-0.5" aria-hidden="true"></i>
          <span>You withdrew this application. It stays in your history, and you are no longer being considered for this position.</span>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 sm:gap-5 mb-5">
        <div className="lg:col-span-7">
          <div className="card h-full">
            <div className="p-5">
              <h5 className="card-title mb-2">AI Screening Summary</h5>
              {app.ai_overall_score === null && app.ai_error ? (
                <div className="alert-warning" role="alert">
                  <p className="mb-2">We could not finish analyzing your resume automatically. Your application was still submitted and the hiring team can see it.</p>
                  <button type="button" className="btn btn-sm btn-outline-primary" onClick={handleRetryScreening} disabled={retrying}>
                    <i className={`bi bi-arrow-clockwise ${retrying ? 'animate-spin' : ''}`} aria-hidden="true"></i> {retrying ? 'Retrying…' : 'Try again'}
                  </button>
                </div>
              ) : app.ai_overall_score === null ? (
                <p className="text-ink-soft">Analyzing your resume. This updates automatically once it is ready.</p>
              ) : (
                <>
                  <p>{app.ai_summary}</p>
                  {strengths.length > 0 && <><h6 className="text-sm uppercase tracking-wide text-ink-soft mt-4 mb-1">Strengths</h6><ul className="list-disc pl-5 space-y-0.5">{strengths.map((s, i) => <li key={i}>{s}</li>)}</ul></>}
                  {gaps.length > 0 && <><h6 className="text-sm uppercase tracking-wide text-ink-soft mt-4 mb-1">Areas to Highlight / Address</h6><ul className="list-disc pl-5 space-y-0.5">{gaps.map((g, i) => <li key={i}>{g}</li>)}</ul></>}
                </>
              )}
            </div>
          </div>
        </div>

        {app.ai_overall_score !== null && (
          <div className="lg:col-span-5">
            <div className="card h-full">
              <div className="p-5 text-center flex flex-col items-center justify-center h-full">
                <ScoreDial score={app.ai_overall_score} size={96} />
                <div className="text-ink-soft text-sm mt-3">Overall Fit Score</div>
              </div>
            </div>
          </div>
        )}
      </div>

      {app.ai_overall_score !== null && (interview || !closed) && (
        <div className="card mb-5">
          <div className="p-5 flex justify-between items-center flex-wrap gap-4">
            <div>
              <h5 className="card-title mb-1 flex items-center gap-2 flex-wrap">
                <span><i className="bi bi-mic mr-1"></i> Technical Interview</span>
                {interview && <InterviewStatusBadge status={interview.status} />}
              </h5>
              <p className="text-ink-soft mb-0 text-sm">
                {interview === undefined && 'Loading...'}
                {interview === null && 'A short AI-conducted technical interview based on your resume and this role. You have 20 minutes once you start.'}
                {interview?.status === 'in_progress' && `In progress. Question ${interview.current_index + 1} of ${interview.total_questions}, and the 20 minute timer is running.`}
                {interview?.status === 'completed' && (interview.report ? 'Completed. HR is reviewing your results.' : 'Completed. Your assessment report is being generated.')}
                {interview?.status === 'timed_out' && 'The 20 minute limit ended, so your interview was submitted automatically.'}
                {interview?.status === 'cancelled' && 'This interview was cancelled and can no longer be continued.'}
              </p>
            </div>
            {(interview === null && !closed) || interview?.status === 'in_progress' ? (
              <Link to={`/applications/${id}/interview`} className="btn btn-primary">
                {interview?.status === 'in_progress' ? 'Continue Interview' : 'Start Interview'}
              </Link>
            ) : interview ? (
              <Link to={`/applications/${id}/interview`} className="btn btn-outline-secondary">View Results</Link>
            ) : null}
          </div>
        </div>
      )}

      <ChatThread applicationId={id} />
    
      <ConfirmDialog
        open={withdrawOpen} tone="danger" icon="bi-box-arrow-left" busy={withdrawing}
        title="Withdraw this application?" message="You will no longer be considered for this position."
        cancelLabel="Keep Application" confirmLabel="Withdraw Application"
        onCancel={() => setWithdrawOpen(false)} onConfirm={handleWithdraw}
      />
    </div>
  );
}
