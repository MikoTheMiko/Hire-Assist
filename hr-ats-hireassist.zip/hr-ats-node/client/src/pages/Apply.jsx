import { useEffect, useRef, useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import api, { API_ORIGIN } from '../api';
import { formatSalaryRange } from '../utils/format';
import SegmentedControl from '../components/ui/SegmentedControl';
import { useToast } from '../context/ToastContext';

const MAX_BYTES = 5 * 1024 * 1024;
const ALLOWED = ['pdf', 'docx', 'txt'];
const fmtSize = (b) => (b > 1024 * 1024 ? `${(b / 1024 / 1024).toFixed(1)} MB` : `${Math.max(1, Math.round(b / 1024))} KB`);

export default function Apply() {
  const { user } = useAuth();
  const toast = useToast();
  const fileInputRef = useRef(null);
  const [progress, setProgress] = useState(0);
  const [fileError, setFileError] = useState('');
  const [dragOver, setDragOver] = useState(false);
  const { jobId } = useParams();
  const navigate = useNavigate();
  const [job, setJob] = useState(null);
  const [resumeText, setResumeText] = useState('');
  const [file, setFile] = useState(null);
  const [expectedSalary, setExpectedSalary] = useState('');
  const [expectedSalaryType, setExpectedSalaryType] = useState('Monthly');
  const [error, setError] = useState(null);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    api.get(`/jobs/${jobId}`).then((res) => setJob(res.data));
  }, [jobId]);

  function pickFile(f) {
    setFileError('');
    if (!f) { setFile(null); return; }
    const ext = f.name.split('.').pop().toLowerCase();
    if (!ALLOWED.includes(ext)) { setFileError('Unsupported file type. Please upload a PDF, DOCX or TXT file.'); setFile(null); return; }
    if (f.size > MAX_BYTES) { setFileError('That file is larger than 5 MB.'); setFile(null); return; }
    setFile(f);
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setError(null);

    if (!file && !resumeText.trim()) {
      setError('Please upload a resume file or paste your resume text.');
      return;
    }

    const formData = new FormData();
    formData.append('job_id', jobId);
    formData.append('resume_text', resumeText);
    if (file) formData.append('resume_file', file);
    if (expectedSalary !== '') {
      formData.append('expected_salary', expectedSalary);
      formData.append('expected_salary_type', expectedSalaryType);
    }

    setSubmitting(true);
    setProgress(0);
    try {
      await api.post('/applications', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
        onUploadProgress: (ev) => { if (ev.total) setProgress(Math.round((ev.loaded / ev.total) * 100)); },
      });
      toast.success('Application Submitted', { description: file ? 'Resume uploaded. We are screening it now.' : 'We are screening your resume now.' });
      navigate('/applications');
    } catch (err) {
      if (err.response) {
        setError(err.response.data?.error || `The server returned an error (${err.response.status}). Please try again.`);
      } else if (err.request) {
        // No response at all: the API is down, restarting, or the address is wrong (ERR_CONNECTION_REFUSED).
        setError(`Could not reach the server at ${API_ORIGIN}. Make sure the API is running, then try again. Your application was not submitted.`);
      } else {
        setError('Something went wrong. Please try again.');
      }
    } finally {
      setSubmitting(false);
    }
  }

  if (!job) return <div className="jd-loading" role="status"><span className="searchbar__spinner" aria-hidden="true"></span> Loading…</div>;

  const salaryBudget = formatSalaryRange(job.salary_min, job.salary_max, job.salary_type);

  return (
    <div className="ap">
      <Link to={`/jobs/${job.id}`} className="jd-back"><i className="bi bi-arrow-left" aria-hidden="true"></i> Back to job</Link>
      <header className="ap-head">
        <p className="a-eyebrow">Application</p>
        <h1 className="a-title">Apply for {job.title}</h1>
        <p className="a-sub">Your resume is screened and scored against this role automatically. The result appears live on your dashboard.</p>
      </header>

      {error && <div className="alert-danger mb-4" role="alert">{error}</div>}

      <form onSubmit={handleSubmit} className="ap-form" noValidate>
        <section className="ap-section">
          <h2 className="ap-h"><span>1</span> Personal information</h2>
          <div className="ap-grid">
            <div><label className="field-label" htmlFor="ap-name">Full name</label><input id="ap-name" className="input" value={user?.name || ''} readOnly /></div>
            <div><label className="field-label" htmlFor="ap-email">Email</label><input id="ap-email" className="input" value={user?.email || ''} readOnly /></div>
          </div>
          <p className="ap-hint">Taken from your account.</p>
        </section>

        <section className="ap-section">
          <h2 className="ap-h"><span>2</span> Resume</h2>
          <label className="field-label" htmlFor="ap-file">Upload resume <span className="ap-opt">PDF, DOCX or TXT · max 5 MB</span></label>
          <div
            className={`ap-drop${dragOver ? ' is-over' : ''}${file ? ' has-file' : ''}`}
            onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
            onDragLeave={() => setDragOver(false)}
            onDrop={(e) => { e.preventDefault(); setDragOver(false); pickFile(e.dataTransfer.files?.[0]); }}
          >
            <input id="ap-file" ref={fileInputRef} type="file" className="ap-drop__input" accept=".pdf,.docx,.txt" onChange={(e) => pickFile(e.target.files[0])} disabled={submitting} />
            {file ? (
              <div className="ap-file">
                <i className="bi bi-file-earmark-check" aria-hidden="true"></i>
                <div><strong>{file.name}</strong><span>{fmtSize(file.size)}</span></div>
                <button type="button" className="btn btn-sm btn-outline-secondary" disabled={submitting}
                  onClick={() => { pickFile(null); if (fileInputRef.current) fileInputRef.current.value = ''; }}>Remove</button>
              </div>
            ) : (
              <label htmlFor="ap-file" className="ap-drop__prompt">
                <i className="bi bi-cloud-arrow-up" aria-hidden="true"></i>
                <strong>Choose a file</strong> or drag it here
              </label>
            )}
          </div>
          {fileError && <p className="ap-error" role="alert"><i className="bi bi-exclamation-circle" aria-hidden="true"></i> {fileError}</p>}

          <div className="ap-or"><span>and / or</span></div>
          <label className="field-label" htmlFor="ap-text">Paste resume text <span className="ap-opt">recommended for the most reliable AI analysis</span></label>
          <textarea id="ap-text" className="input" rows={9} value={resumeText} onChange={(e) => setResumeText(e.target.value)} placeholder="Paste your resume content here…" disabled={submitting} />
        </section>

        <section className="ap-section">
          <h2 className="ap-h"><span>3</span> Expected salary <em>optional</em></h2>
          <div className="ap-grid">
            <div>
              <label className="field-label" htmlFor="ap-salary">Amount</label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-ink-soft text-sm" aria-hidden="true">₱</span>
                <input id="ap-salary" type="number" min="0" step="1000" className="input pl-7" value={expectedSalary} onChange={(e) => setExpectedSalary(e.target.value)} placeholder="e.g. 30000" disabled={submitting} />
              </div>
              {salaryBudget && <p className="ap-hint">This role's posted budget: {salaryBudget}</p>}
            </div>
            <div>
              <span className="field-label">Per</span>
              <SegmentedControl full ariaLabel="Salary period" value={expectedSalaryType} onChange={setExpectedSalaryType} disabled={expectedSalary === '' || submitting} options={[{ value: 'Monthly', label: 'Monthly' }, { value: 'Annual', label: 'Annual' }]} />
            </div>
          </div>
        </section>

        {submitting && (
          <div className="ap-upload" role="status" aria-live="polite">
            <div className="flex justify-between text-sm font-semibold mb-1.5"><span>{progress < 100 ? 'Uploading...' : 'Submitting. Starting AI screening...'}</span><span>{progress}%</span></div>
            <div className="pbar"><div className="pbar__fill" style={{ width: `${progress}%` }}></div></div>
          </div>
        )}

        <div className="ap-actions">
          <Link to={`/jobs/${job.id}`} className="btn btn-outline-secondary">Cancel</Link>
          <button className="btn btn-primary" disabled={submitting}>{submitting ? 'Submitting…' : 'Submit application'}</button>
        </div>
      </form>
    </div>
  );
}
