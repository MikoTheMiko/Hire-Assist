import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const user = await login(email, password);
      navigate(user.role === 'hr' ? '/hr/dashboard' : '/applications');
    } catch (err) {
      setError(err.response?.data?.error || 'Login failed.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="flex justify-center pt-4 sm:pt-10">
      <div className="w-full max-w-md">
        <div className="card">
          <div className="p-6 sm:p-8">
            <h1 className="auth-title">Welcome back</h1>
            <p className="auth-sub">Log in to track your applications or manage hiring.</p>
            {error && <div className="alert-danger mb-4" role="alert">{error}</div>}
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="field-label" htmlFor="login-email">Email</label>
                <input id="login-email" type="email" autoComplete="email" className="input" value={email} onChange={(e) => setEmail(e.target.value)} required autoFocus />
              </div>
              <div>
                <label className="field-label" htmlFor="login-password">Password</label>
                <input id="login-password" type="password" autoComplete="current-password" className="input" value={password} onChange={(e) => setPassword(e.target.value)} required />
              </div>
              <button className="btn btn-primary w-full" disabled={loading}>{loading ? 'Logging in...' : 'Log In'}</button>
            </form>
            <p className="text-center text-sm text-ink-soft mt-4 mb-0">No account? <Link to="/register">Register here</Link></p>
          </div>
        </div>
      </div>
    </div>
  );
}
