import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import api from '../api';
import { useToast } from '../context/ToastContext';
import SegmentedControl from '../components/ui/SegmentedControl';
import MenuSelect from '../components/ui/MenuSelect';

const empty = {
  title: '', department: '', seniority_level: 'Mid', employment_type: 'Full-time',
  description: '', required_skills: '', preferred_skills: '',
  min_years_experience: 0, education_requirement: '', status: 'open',
  salary_min: '', salary_max: '', salary_type: 'Monthly',
};

// Doubles as both "Post a New Job" (no :id in the route) and "Edit Job"
// (route has :id) - same form either way, just a different submit verb/URL.
export default function HrPostJob() {
  const { id } = useParams();
  const isEdit = !!id;
  const navigate = useNavigate();
  const toast = useToast();
  const [form, setForm] = useState(empty);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(isEdit);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (!isEdit) return;
    api.get(`/jobs/${id}`)
      .then((res) => {
        const job = res.data;
        setForm({
          title: job.title || '',
          department: job.department || '',
          seniority_level: job.seniority_level || 'Mid',
          employment_type: job.employment_type || 'Full-time',
          description: job.description || '',
          required_skills: job.required_skills || '',
          preferred_skills: job.preferred_skills || '',
          min_years_experience: job.min_years_experience ?? 0,
          education_requirement: job.education_requirement || '',
          status: job.status || 'open',
          salary_min: job.salary_min ?? '',
          salary_max: job.salary_max ?? '',
          salary_type: job.salary_type || 'Monthly',
        });
      })
      .catch(() => setError('Could not load this job.'))
      .finally(() => setLoading(false));
  }, [id, isEdit]);

  function update(field) {
    return (e) => setForm((f) => ({ ...f, [field]: e.target.value }));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setError(null);
    if (!form.title || !form.description) return setError('Title and description are required.');
    if (form.salary_min !== '' && form.salary_max !== '' && Number(form.salary_min) > Number(form.salary_max)) {
      return setError('Minimum salary cannot be greater than maximum salary.');
    }

    setSubmitting(true);
    try {
      if (isEdit) {
        await api.put(`/jobs/${id}`, form);
      } else {
        await api.post('/jobs', form);
      }
      toast.success(isEdit ? 'Job Updated' : 'Job Posted');
      navigate('/hr/jobs');
    } catch (err) {
      setError(err.response?.data?.error || 'Something went wrong.');
    } finally {
      setSubmitting(false);
    }
  }

  if (loading) return <p className="text-ink-soft">Loading...</p>;

  return (
    <div className="flex justify-center">
      <div className="w-full lg:max-w-3xl">
        <div className="card">
          <div className="p-6 sm:p-8">
            <h1 className="page-title">{isEdit ? 'Edit Job Posting' : 'Post a New Job'}</h1>
            <p className="page-sub mb-6">{isEdit ? 'Update the details candidates and the AI screener will see.' : 'Describe the role. The AI uses these details to screen resumes and build interview questions.'}</p>
            {error && <div className="alert-danger mb-4">{error}</div>}

            <form onSubmit={handleSubmit}>
              <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
                <div className="md:col-span-8">
                  <label className="field-label">Job Title</label>
                  <input className="input" value={form.title} onChange={update('title')} required />
                </div>
                <div className="md:col-span-4">
                  <label className="field-label">Department</label>
                  <input className="input" value={form.department} onChange={update('department')} />
                </div>

                <div className="md:col-span-4">
                  <label className="field-label">Seniority</label>
                  <SegmentedControl full ariaLabel="Seniority" value={form.seniority_level} onChange={(v) => setForm((f) => ({ ...f, seniority_level: v }))} options={['Junior', 'Mid', 'Senior', 'Lead'].map((l) => ({ value: l, label: l }))} />
                </div>
                <div className="md:col-span-4">
                  <label className="field-label">Employment Type</label>
                  <MenuSelect block ariaLabel="Employment type" value={form.employment_type} onChange={(v) => setForm((f) => ({ ...f, employment_type: v }))} options={['Full-time', 'Part-time', 'Contract', 'Internship'].map((t) => ({ value: t, label: t }))} />
                </div>
                <div className="md:col-span-4">
                  <label className="field-label">Status</label>
                  <SegmentedControl full ariaLabel="Job status" value={form.status} onChange={(v) => setForm((f) => ({ ...f, status: v }))} options={[{ value: 'open', label: 'Open' }, { value: 'draft', label: 'Draft' }, { value: 'closed', label: 'Closed' }]} />
                </div>

                <div className="md:col-span-12">
                  <label className="field-label">Description</label>
                  <textarea className="input" rows={6} value={form.description} onChange={update('description')} required />
                </div>

                <div className="md:col-span-6">
                  <label className="field-label">Required Skills <span className="text-ink-soft font-normal">(comma-separated)</span></label>
                  <input className="input" value={form.required_skills} onChange={update('required_skills')} placeholder="PHP, MySQL, REST APIs" />
                </div>
                <div className="md:col-span-6">
                  <label className="field-label">Preferred Skills <span className="text-ink-soft font-normal">(comma-separated)</span></label>
                  <input className="input" value={form.preferred_skills} onChange={update('preferred_skills')} placeholder="Docker, AWS" />
                </div>

                <div className="md:col-span-6">
                  <label className="field-label">Min. Years Experience</label>
                  <input type="number" min="0" className="input" value={form.min_years_experience} onChange={update('min_years_experience')} />
                </div>
                <div className="md:col-span-6">
                  <label className="field-label">Education Requirement</label>
                  <input className="input" value={form.education_requirement} onChange={update('education_requirement')} placeholder="Bachelor's degree in CS or related" />
                </div>

                <div className="md:col-span-4">
                  <label className="field-label">Salary Min <span className="text-ink-soft font-normal">(optional)</span></label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-ink-soft text-sm">₱</span>
                    <input type="number" min="0" step="1000" className="input pl-6" value={form.salary_min} onChange={update('salary_min')} placeholder="e.g. 25000" />
                  </div>
                </div>
                <div className="md:col-span-4">
                  <label className="field-label">Salary Max <span className="text-ink-soft font-normal">(optional)</span></label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-ink-soft text-sm">₱</span>
                    <input type="number" min="0" step="1000" className="input pl-6" value={form.salary_max} onChange={update('salary_max')} placeholder="e.g. 35000" />
                  </div>
                </div>
                <div className="md:col-span-4">
                  <label className="field-label">Salary Type</label>
                  <SegmentedControl full ariaLabel="Salary type" value={form.salary_type} onChange={(v) => setForm((f) => ({ ...f, salary_type: v }))} options={[{ value: 'Monthly', label: 'Monthly' }, { value: 'Annual', label: 'Annual' }]} />
                </div>
              </div>

              <div className="flex gap-2 mt-6">
                <button className="btn btn-primary flex-1" disabled={submitting}>
                  {submitting ? 'Saving...' : isEdit ? 'Save Changes' : 'Post Job'}
                </button>
                {isEdit && (
                  <button type="button" className="btn btn-outline-secondary" onClick={() => navigate('/hr/jobs')} disabled={submitting}>
                    Cancel
                  </button>
                )}
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}
