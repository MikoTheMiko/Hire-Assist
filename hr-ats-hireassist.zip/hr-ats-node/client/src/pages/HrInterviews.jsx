import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../api';
import useApi from '../hooks/useApi';
import useDebounce from '../hooks/useDebounce';
import MenuSelect from '../components/ui/MenuSelect';
import PageHeader from '../components/ui/PageHeader';
import SearchInput from '../components/ui/SearchInput';
import Avatar from '../components/ui/Avatar';
import ScorePill from '../components/ui/ScorePill';
import Skeleton from '../components/ui/Skeleton';
import EmptyState from '../components/ui/EmptyState';
import ErrorState from '../components/ui/ErrorState';
import { InterviewStatus } from '../components/dashboard/RecentInterviewsCard';
import { timeAgo, capitalize } from '../utils/format';

// Every AI technical-interview session across the HR user's jobs
// (GET /api/interviews/hr/list). Clicking a row opens the application, where the
// full transcript and assessment report already live.
export default function HrInterviews() {
  const navigate = useNavigate();
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('');
  const debounced = useDebounce(search, 300);

  const { data, loading, refreshing, error, reload } = useApi((signal) => {
    const params = {};
    if (debounced.trim()) params.search = debounced.trim();
    if (status) params.status = status;
    return api.get('/interviews/hr/list', { params, signal }).then((r) => r.data);
  }, [debounced, status]);

  const filtersActive = !!(search || status);
  const reset = () => { setSearch(''); setStatus(''); };

  return (
    <div>
      <PageHeader title="Interviews" subtitle="AI technical interviews taken by your candidates." />

      <div className="toolbar">
        <SearchInput value={search} onChange={setSearch} placeholder="Search candidate or job..." />
        <div className="toolbar-filters">
          <MenuSelect value={status} onChange={setStatus} ariaLabel="Filter by interview status" prefix="Status" options={[
            { value: '', label: 'All sessions' }, { value: 'in_progress', label: 'In progress', dot: 'bg-gold' },
            { value: 'completed', label: 'Completed', dot: 'bg-success-ink' }, { value: 'timed_out', label: 'Timed out', dot: 'bg-danger' },
            { value: 'cancelled', label: 'Cancelled', dot: 'bg-line-strong' }]} />
          {filtersActive && <button className="btn btn-sm btn-outline-secondary" onClick={reset}><i className="bi bi-x-circle"></i> Reset</button>}
        </div>
      </div>

      {error && <div className="card"><ErrorState message="Unable to load interviews." onRetry={reload} /></div>}
      {loading && <div className="card p-4 space-y-3">{[0, 1, 2, 3].map((i) => <Skeleton key={i} className="h-14 w-full" />)}</div>}

      {!loading && !error && data && data.length === 0 && (
        <div className="card">
          <EmptyState icon="bi-mic" title={filtersActive ? 'No interviews found' : 'No interview data yet'}
            message={filtersActive ? 'Try a different search or clear your filters.' : 'Completed interviews will appear here.'}
            action={filtersActive && <button className="btn btn-sm btn-outline-secondary" onClick={reset}>Clear search &amp; filters</button>} />
        </div>
      )}

      {!error && data && data.length > 0 && (
        <div className={`card overflow-x-auto transition-opacity ${refreshing ? 'opacity-60' : ''}`}>
          <table className="table-modern min-w-[720px]">
            <thead>
              <tr><th>Candidate</th><th>Position</th><th>Status</th><th>Technical</th><th>Communication</th><th>Recommendation</th><th>When</th></tr>
            </thead>
            <tbody>
              {data.map((s) => (
                <tr key={s.id} className="row-link" onClick={() => navigate(`/hr/applications/${s.application_id}`)}>
                  <td>
                    <div className="flex items-center gap-3">
                      <Avatar name={s.applicant_name} size={36} />
                      <div className="min-w-0"><div className="font-semibold">{s.applicant_name}</div><div className="text-xs text-ink-soft">{s.applicant_email}</div></div>
                    </div>
                  </td>
                  <td>{s.job_title}</td>
                  <td><InterviewStatus session={s} /></td>
                  <td><ScorePill score={s.report_technical_score} /></td>
                  <td><ScorePill score={s.report_communication_score} /></td>
                  <td className="text-ink-soft">{s.report_recommendation ? capitalize(s.report_recommendation) : '-'}</td>
                  <td className="text-ink-soft text-xs whitespace-nowrap">{timeAgo(s.completed_at || s.started_at)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
