import { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import api from '../api';
import { useAuth } from '../context/AuthContext';
import { useSocket } from '../context/SocketContext';
import useDebounce from '../hooks/useDebounce';
import useCountUp from '../hooks/useCountUp';
import ApplicationCard from '../components/cards/ApplicationCard';
import MenuSelect from '../components/ui/MenuSelect';
import EmptyState from '../components/ui/EmptyState';
import Skeleton from '../components/ui/Skeleton';
import { ALL_STATUSES, STATUS_DOTS, greeting, statusLabel } from '../utils/format';

function Stat({ label, value, icon }) {
  const shown = useCountUp(value);
  return (
    <div className="a-stat">
      <span className="a-stat__icon" aria-hidden="true"><i className={`bi ${icon}`}></i></span>
      <div className="a-stat__num" aria-label={`${label}: ${value}`}>{shown}</div>
      <div className="a-stat__label">{label}</div>
    </div>
  );
}

// Applicant home: summary numbers + every application, searchable and filterable.
// All numbers are computed from GET /applications/mine — nothing is hardcoded.
export default function ApplicantDashboard() {
  const { user } = useAuth();
  const { socket } = useSocket();
  const [applications, setApplications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const debounced = useDebounce(search, 250);

  useEffect(() => {
    api.get('/applications/mine')
      .then((res) => setApplications(res.data))
      .catch(() => setError('Could not load your applications.'))
      .finally(() => setLoading(false));
  }, []);

  // Live updates: when AI screening finishes or a status changes, patch that one row in place.
  useEffect(() => {
    if (!socket) return undefined;
    function handleScreeningComplete({ applicationId, result }) {
      setApplications((prev) => prev.map((a) =>
        a.id === applicationId ? { ...a, ai_overall_score: result.overall_score, ai_error: null, status: 'screened' } : a));
    }
    function handleScreeningFailed({ applicationId, error }) {
      setApplications((prev) => prev.map((a) => (a.id === applicationId ? { ...a, ai_error: error } : a)));
    }
    function handleStatusChange({ applicationId, status }) {
      setApplications((prev) => prev.map((a) => (a.id === applicationId ? { ...a, status } : a)));
    }
    socket.on('screening:complete', handleScreeningComplete);
    socket.on('screening:failed', handleScreeningFailed);
    socket.on('application:status', handleStatusChange);
    return () => {
      socket.off('screening:complete', handleScreeningComplete);
      socket.off('screening:failed', handleScreeningFailed);
      socket.off('application:status', handleStatusChange);
    };
  }, [socket]);

  const stats = useMemo(() => ({
    total: applications.length,
    pending: applications.filter((a) => a.status === 'submitted' || a.status === 'screened').length,
    invitations: applications.filter((a) => a.status === 'shortlisted' || a.status === 'interview').length,
    completed: applications.filter((a) => a.interview_status === 'completed').length,
  }), [applications]);

  const filtered = useMemo(() => {
    const term = debounced.trim().toLowerCase();
    return applications.filter((a) =>
      (!statusFilter || a.status === statusFilter) &&
      (!term || `${a.job_title} ${a.department || ''}`.toLowerCase().includes(term)));
  }, [applications, debounced, statusFilter]);

  const filtersActive = !!(search || statusFilter);
  const reset = () => { setSearch(''); setStatusFilter(''); };

  return (
    <div className="a-page">
      <header className="a-header">
        <div>
          <p className="a-eyebrow">{greeting()}, {user?.name?.split(' ')[0]}</p>
          <h1 className="a-title">My Applications</h1>
          <p className="a-sub">Track every application, screening result and interview in one place.</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Link to="/messages" className="btn btn-outline-secondary"><i className="bi bi-chat-dots" aria-hidden="true"></i> Messages</Link>
          <Link to="/" className="btn btn-primary"><i className="bi bi-search" aria-hidden="true"></i> Browse jobs</Link>
        </div>
      </header>

      {error && <div className="alert-danger mb-4" role="alert">{error}</div>}

      <section className="a-stats" aria-label="Summary">
        <Stat label="Total applications" value={stats.total} icon="bi-folder2-open" />
        <Stat label="Pending review" value={stats.pending} icon="bi-hourglass-split" />
        <Stat label="Interview invitations" value={stats.invitations} icon="bi-envelope-check" />
        <Stat label="Interviews completed" value={stats.completed} icon="bi-check2-circle" />
      </section>

      {applications.length > 0 && (
        <div className="a-toolbar">
          <div className="search-wrap" role="search">
            <i className="bi bi-search lead" aria-hidden="true"></i>
            <input
              type="search" className="search-input [&::-webkit-search-cancel-button]:hidden" value={search}
              placeholder="Search by job title or department" aria-label="Search your applications"
              onChange={(e) => setSearch(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Escape') setSearch(''); }}
            />
            {search && <button type="button" className="search-clear" onClick={() => setSearch('')} aria-label="Clear search"><i className="bi bi-x-lg text-[0.7rem]" aria-hidden="true"></i></button>}
          </div>
          <MenuSelect value={statusFilter} onChange={setStatusFilter} ariaLabel="Filter by status" prefix="Status"
            options={[{ value: '', label: 'All' }, ...ALL_STATUSES.filter((s) => s !== 'archived').map((s) => ({ value: s, label: statusLabel(s), dot: STATUS_DOTS[s] }))]} />
          {filtersActive && <button className="btn btn-sm btn-outline-secondary" onClick={reset}>Reset</button>}
        </div>
      )}

      {loading ? (
        <div className="a-list">{[0, 1, 2].map((i) => <Skeleton key={i} className="h-36 !rounded-2xl" />)}</div>
      ) : applications.length === 0 ? (
        <EmptyState icon="bi-inbox" title="No applications yet" message="When you apply for a job, it will show up here with live screening and interview progress."
          action={<Link to="/" className="btn btn-primary">Browse open positions</Link>} />
      ) : filtered.length === 0 ? (
        <EmptyState icon="bi-search" title="No matching applications" message="Try a different search or clear your filters."
          action={<button className="btn btn-sm btn-outline-secondary" onClick={reset}>Clear search &amp; filters</button>} />
      ) : (
        <div className="a-list stagger">
          {filtered.map((app) => <ApplicationCard key={app.id} app={app} />)}
        </div>
      )}
    </div>
  );
}
