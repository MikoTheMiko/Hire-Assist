import { useEffect, useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import api from '../api';
import { useAuth } from '../context/AuthContext';
import { formatSalaryRange, timeAgo } from '../utils/format';

export default function JobDetail() {
  const { id } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [job, setJob] = useState(null);
  const [alreadyApplied, setAlreadyApplied] = useState(false);
  const [error, setError] = useState('');
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [togglingStatus, setTogglingStatus] = useState(false);

  useEffect(() => {
    api.get(`/jobs/${id}`).then((res) => setJob(res.data));

    if (user?.role === 'applicant') {
      api.get('/applications/mine').then((res) => {
        setAlreadyApplied(res.data.some((a) => a.job_id === Number(id)));
      });
    }
  }, [id, user]);

  if (!job) {
    return <div className="jd-loading" role="status" aria-live="polite"><span className="searchbar__spinner" aria-hidden="true"></span> Loading job…</div>;
  }

  const requiredSkills = (job.required_skills || '').split(',').map((s) => s.trim()).filter(Boolean);
  const preferredSkills = (job.preferred_skills || '').split(',').map((s) => s.trim()).filter(Boolean);
  const salary = formatSalaryRange(job.salary_min, job.salary_max, job.salary_type);
  const isOwner = user?.role === 'hr' && job.created_by === user.id;

  async function handleDelete() {
    setDeleting(true);
    setError('');
    try {
      await api.delete(`/jobs/${id}`);
      navigate('/hr/jobs');
    } catch (err) {
      setError(err.response?.data?.error || 'Could not delete this job.');
      setDeleting(false);
      setConfirmDelete(false);
    }
  }

  async function handleToggleStatus() {
    const nextStatus = job.status === 'open' ? 'closed' : 'open';
    setTogglingStatus(true);
    setError('');
    try {
      await api.patch(`/jobs/${id}/status`, { status: nextStatus });
      setJob((prev) => ({ ...prev, status: nextStatus }));
    } catch (err) {
      setError(err.response?.data?.error || 'Could not update this job.');
    } finally {
      setTogglingStatus(false);
    }
  }

  const canApply = user?.role === 'applicant' && !alreadyApplied && job.status === 'open';

  const applyPanel = (
    <>
      {!user && <><p className="jd-panel__text">Log in as an applicant to apply for this position.</p><Link to="/login" className="btn btn-primary w-full">Log in to apply</Link></>}
      {user && user.role !== 'applicant' && <p className="jd-panel__text mb-0">Only applicant accounts can apply for jobs.</p>}
      {user?.role === 'applicant' && alreadyApplied && (
        <>
          <p className="jd-panel__ok"><i className="bi bi-check-circle-fill" aria-hidden="true"></i> You already applied to this job.</p>
          <Link to="/applications" className="btn btn-outline-primary w-full">View my application</Link>
        </>
      )}
      {canApply && <Link to={`/apply/${job.id}`} className="btn btn-primary w-full jd-apply-btn">Apply now <i className="bi bi-arrow-right" aria-hidden="true"></i></Link>}
      {user?.role === 'applicant' && !alreadyApplied && job.status !== 'open' && (
        <p className="jd-panel__text mb-0">This position is no longer accepting applications.</p>
      )}
    </>
  );

  return (
    <div className="jd">
      <Link to="/" className="jd-back"><i className="bi bi-arrow-left" aria-hidden="true"></i> All jobs</Link>
      {error && <div className="alert-danger mb-4" role="alert">{error}</div>}

      <div className="jd-grid">
        <div className="jd-main">
          <header className="jd-card jd-header">
            <div className="jd-header__top">
              <div className="job-card__mark jd-mark" aria-hidden="true">{(job.department || job.title || '?')[0].toUpperCase()}</div>
              <div className="jd-header__text">
                <h1 className="jd-title">{job.title}</h1>
                <p className="jd-org">{job.department || 'General'}{job.posted_by ? ` · Posted by ${job.posted_by}` : ''}</p>
              </div>
              <span className={`badge shrink-0 ${job.status === 'open' ? 'bg-success-soft text-success-ink' : 'bg-line text-ink-soft'}`}>{job.status}</span>
            </div>

            <ul className="jd-facts">
              {job.employment_type && <li><i className="bi bi-briefcase" aria-hidden="true"></i><span><small>Job type</small>{job.employment_type}</span></li>}
              {job.seniority_level && <li><i className="bi bi-bar-chart" aria-hidden="true"></i><span><small>Level</small>{job.seniority_level}</span></li>}
              {salary && <li><i className="bi bi-cash-stack" aria-hidden="true"></i><span><small>Salary (estimated)</small>{salary}</span></li>}
              {job.created_at && <li><i className="bi bi-clock" aria-hidden="true"></i><span><small>Posted</small>{timeAgo(job.created_at)}</span></li>}
            </ul>

            {isOwner && (
              <div className="jd-owner">
                <div className="flex gap-2 flex-wrap">
                  <Link to={`/hr/jobs/${job.id}/edit`} className="btn btn-sm btn-outline-secondary"><i className="bi bi-pencil" aria-hidden="true"></i> Edit</Link>
                  {job.status !== 'draft' && (
                    <button className="btn btn-sm btn-outline-primary" onClick={handleToggleStatus} disabled={togglingStatus}>
                      <i className={`bi ${job.status === 'open' ? 'bi-lock' : 'bi-unlock'}`} aria-hidden="true"></i>
                      {job.status === 'open' ? 'Close Job' : 'Reopen Job'}
                    </button>
                  )}
                  <button className="btn btn-sm btn-outline-secondary" onClick={() => setConfirmDelete(true)}><i className="bi bi-trash3" aria-hidden="true"></i> Delete</button>
                </div>
                {confirmDelete && (
                  <div className="alert-danger flex flex-col sm:flex-row sm:items-center justify-between gap-3 mt-3" role="alertdialog" aria-label="Confirm delete">
                    <div>
                      <p className="font-semibold mb-0.5"><i className="bi bi-exclamation-triangle-fill mr-1" aria-hidden="true"></i> Delete "{job.title}"?</p>
                      <p className="mb-0 text-sm opacity-90">This will permanently remove the job and associated application data.</p>
                    </div>
                    <div className="flex gap-2 shrink-0">
                      <button className="btn btn-sm btn-outline-secondary" onClick={() => setConfirmDelete(false)} disabled={deleting}>Cancel</button>
                      <button className="btn btn-sm btn-danger" onClick={handleDelete} disabled={deleting}>{deleting ? 'Deleting...' : 'Delete Job'}</button>
                    </div>
                  </div>
                )}
              </div>
            )}
          </header>

          <section className="jd-card">
            <h2 className="jd-h2">About the role</h2>
            <p className="jd-desc">{job.description}</p>
          </section>

          {(requiredSkills.length > 0 || preferredSkills.length > 0 || job.min_years_experience || job.education_requirement) && (
            <section className="jd-card">
              <h2 className="jd-h2">Requirements</h2>
              <div className="jd-reqs">
                <div><small>Experience</small><strong>{job.min_years_experience ? `${job.min_years_experience}+ years` : 'Not specified'}</strong></div>
                <div><small>Education</small><strong>{job.education_requirement || 'Not specified'}</strong></div>
              </div>
              {requiredSkills.length > 0 && (
                <>
                  <h3 className="jd-h3">Required skills</h3>
                  <div className="jd-skills">{requiredSkills.map((sk) => <span key={sk} className="jd-skill jd-skill--req">{sk}</span>)}</div>
                </>
              )}
              {preferredSkills.length > 0 && (
                <>
                  <h3 className="jd-h3">Nice to have</h3>
                  <div className="jd-skills">{preferredSkills.map((sk) => <span key={sk} className="jd-skill">{sk}</span>)}</div>
                </>
              )}
            </section>
          )}
        </div>

        <aside className="jd-side">
          <div className="jd-card jd-panel">
            <h2 className="jd-panel__title">{canApply ? 'Interested in this role?' : 'Apply'}</h2>
            {applyPanel}
            <ul className="jd-panel__steps">
              <li><i className="bi bi-file-earmark-arrow-up" aria-hidden="true"></i> Submit your resume</li>
              <li><i className="bi bi-cpu" aria-hidden="true"></i> Automatic AI screening</li>
              <li><i className="bi bi-mic" aria-hidden="true"></i> Optional AI technical interview</li>
            </ul>
          </div>
        </aside>
      </div>

      {/* Mobile: keep the CTA within thumb reach */}
      {canApply && (
        <div className="jd-mobile-cta">
          <div><strong>{job.title}</strong>{salary && <span>{salary}</span>}</div>
          <Link to={`/apply/${job.id}`} className="btn btn-primary">Apply now</Link>
        </div>
      )}
    </div>
  );
}
