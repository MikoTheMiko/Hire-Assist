import { useEffect, useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import api from '../api';
import { useSocket } from '../context/SocketContext';
import ScoreDial from '../components/ScoreDial';
import StatusBadge, { InterviewStatusBadge } from '../components/StatusBadge';
import MenuSelect from '../components/ui/MenuSelect';
import ConfirmDialog from '../components/ui/ConfirmDialog';
import { useToast } from '../context/ToastContext';
import { openResume } from '../utils/resume';
import ChatThread from '../components/ChatThread';
import Avatar from '../components/ui/Avatar';
import Skeleton from '../components/ui/Skeleton';
import { formatSalaryRange, formatExpectedSalary, STATUSES, STATUS_DOTS, statusLabel } from '../utils/format';


function ProgressBar({ value }) {
  return (
    <div className="h-2 rounded-full bg-line overflow-hidden">
      <div className="h-full bg-gradient-to-r from-teal to-violet rounded-full transition-[width] duration-700 ease-out" style={{ width: `${value}%` }}></div>
    </div>
  );
}

export default function HrApplicationView() {
  const { id } = useParams();
  const { socket } = useSocket();
  const toast = useToast();
  const navigate = useNavigate();
  const [archiveOpen, setArchiveOpen] = useState(false);
  const [archiving, setArchiving] = useState(false);
  const [openingResume, setOpeningResume] = useState(false);
  const [app, setApp] = useState(null);
  const [rerunning, setRerunning] = useState(false);
  const [updatingStatus, setUpdatingStatus] = useState(false);
  const [interview, setInterview] = useState(undefined); // undefined = loading, null = not started

  useEffect(() => {
    api.get(`/applications/${id}`).then((res) => setApp(res.data));
    api.get(`/interviews/${id}`).then((res) => setInterview(res.data.session));
  }, [id]);

  useEffect(() => {
    if (!socket) return;
    function handleScreeningComplete(payload) {
      if (payload.applicationId === Number(id)) {
        const r = payload.result;
        setApp((prev) => ({
          ...prev,
          ai_overall_score: r.overall_score,
          ai_skills_score: r.skills_score,
          ai_experience_score: r.experience_score,
          ai_education_score: r.education_score,
          ai_summary: r.summary,
          ai_strengths: JSON.stringify(r.strengths || []),
          ai_gaps: JSON.stringify(r.gaps || []),
          ai_matched_skills: JSON.stringify(r.matched_skills || []),
          ai_missing_skills: JSON.stringify(r.missing_skills || []),
          ai_questions: JSON.stringify(r.suggested_questions || []),
          ai_error: null,
        }));
        setRerunning(false);
      }
    }
    function handleScreeningFailed(payload) {
      if (payload.applicationId === Number(id)) {
        setApp((prev) => (prev ? { ...prev, ai_error: payload.error } : prev));
        setRerunning(false);
      }
    }
    socket.on('screening:complete', handleScreeningComplete);
    socket.on('screening:failed', handleScreeningFailed);

    // Live view of the interview as the applicant goes through it, and the
    // final report the moment the AI finishes compiling it.
    function handleInterviewStarted(payload) {
      if (payload.applicationId === Number(id)) setInterview(payload.session);
    }
    function handleInterviewTurn(payload) {
      if (payload.applicationId === Number(id)) {
        setInterview((prev) => (prev ? {
          ...prev,
          history: [...prev.history, payload.turn],
          current_index: payload.turn.question_index + 1,
        } : prev));
      }
    }
    function handleReportReady(payload) {
      if (payload.applicationId === Number(id)) {
        setInterview((prev) => (prev ? { ...prev, report: payload.report } : prev));
      }
    }
    function handleInterviewStatus(payload) {
      if (payload.applicationId === Number(id)) {
        api.get(`/interviews/${id}`).then((res) => setInterview(res.data.session));
      }
    }
    function handleApplicationStatus(payload) {
      if (payload.applicationId === Number(id)) setApp((prev) => (prev ? { ...prev, status: payload.status } : prev));
    }
    socket.on('interview:status', handleInterviewStatus);
    socket.on('application:status', handleApplicationStatus);
    socket.on('interview:started', handleInterviewStarted);
    socket.on('interview:turn', handleInterviewTurn);
    socket.on('interview:report_ready', handleReportReady);

    return () => {
      socket.off('screening:complete', handleScreeningComplete);
      socket.off('screening:failed', handleScreeningFailed);
      socket.off('interview:status', handleInterviewStatus);
      socket.off('application:status', handleApplicationStatus);
      socket.off('interview:started', handleInterviewStarted);
      socket.off('interview:turn', handleInterviewTurn);
      socket.off('interview:report_ready', handleReportReady);
    };
  }, [socket, id]);

  async function handleStatusChange(status) {
    setUpdatingStatus(true);
    try {
      await api.patch(`/applications/${id}/status`, { status });
      setApp((prev) => ({ ...prev, status }));
      toast.success('Application Updated', { description: `Status changed to ${statusLabel(status)}.` });
    } catch (err) {
      toast.error('Could not update status', { description: err.response?.data?.error || 'Please try again.' });
    } finally {
      setUpdatingStatus(false);
    }
  }

  async function handleArchive() {
    setArchiving(true);
    try {
      await api.patch(`/applications/${id}/archive`);
      toast.success('Application Archived', { description: 'It was removed from your active applications.' });
      navigate('/hr/applications');
    } catch (err) {
      setArchiveOpen(false);
      toast.error('Could not archive', { description: err.response?.data?.error || 'Please try again.' });
    } finally {
      setArchiving(false);
    }
  }

  async function handleRestore() {
    setUpdatingStatus(true);
    try {
      const res = await api.patch(`/applications/${id}/restore`);
      setApp((prev) => ({ ...prev, status: res.data.status }));
      toast.success('Application Restored', { description: `Back to ${statusLabel(res.data.status)}.` });
    } catch (err) {
      toast.error('Could not restore', { description: err.response?.data?.error || 'Please try again.' });
    } finally {
      setUpdatingStatus(false);
    }
  }

  async function handleOpenResume(download = false) {
    setOpeningResume(true);
    try {
      await openResume(id, { download });
    } catch (err) {
      toast.error('Resume unavailable', { description: err.message });
    } finally {
      setOpeningResume(false);
    }
  }

  async function handleRerun() {
    setRerunning(true);
    try {
      await api.post(`/applications/${id}/rerun-ai`);
    } catch {
      setRerunning(false);
      toast.error('Could not re-run AI analysis');
    }
    // result arrives via socket - handleScreeningComplete above updates state and clears rerunning
  }

  if (!app) {
    return (
      <div className="space-y-5" aria-busy="true">
        <Skeleton className="h-5 w-40" />
        <Skeleton className="h-28 w-full !rounded-2xl" />
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5"><Skeleton className="h-48 !rounded-2xl" /><Skeleton className="h-48 lg:col-span-2 !rounded-2xl" /></div>
      </div>
    );
  }

  const strengths = app.ai_strengths ? JSON.parse(app.ai_strengths) : [];
  const gaps = app.ai_gaps ? JSON.parse(app.ai_gaps) : [];
  const matched = app.ai_matched_skills ? JSON.parse(app.ai_matched_skills) : [];
  const missing = app.ai_missing_skills ? JSON.parse(app.ai_missing_skills) : [];
  const questions = app.ai_questions ? JSON.parse(app.ai_questions) : [];
  const jobBudget = formatSalaryRange(app.job_salary_min, app.job_salary_max, app.job_salary_type);
  const expectedSalary = formatExpectedSalary(app.expected_salary, app.expected_salary_type);

  return (
    <div>
      <div className="mb-4"><Link to="/hr/applications" className="text-sm inline-flex items-center gap-1"><i className="bi bi-arrow-left"></i> Back to Applications</Link></div>

      {/* Candidate header */}
      <div className="card p-5 sm:p-6 mb-5 bg-gradient-to-br from-surface to-raised">
        <div className="flex justify-between items-start flex-wrap gap-5">
          <div className="flex items-start gap-4 min-w-0">
            <Avatar name={app.applicant_name} size={64} />
            <div className="min-w-0">
              <div className="flex items-center gap-3 flex-wrap mb-1">
                <h1 className="page-title !mb-0">{app.applicant_name}</h1>
                <StatusBadge status={app.status} />
              </div>
              <p className="text-ink-soft mb-1">{app.applicant_email}</p>
              <p className="mb-1 text-[0.92rem]">Applied for <strong>{app.job_title}</strong> &middot; {new Date(app.created_at).toLocaleDateString()}</p>
              {app.resume_path && (
                <div className="flex flex-wrap items-center gap-x-4 gap-y-1">
                  <button type="button" className="text-sm inline-flex items-center gap-1 font-semibold text-teal hover:text-teal-dark" onClick={() => handleOpenResume(false)} disabled={openingResume}>
                    <i className="bi bi-file-earmark-text"></i> {openingResume ? 'Opening...' : 'View uploaded resume file'}
                  </button>
                  <button type="button" className="text-sm inline-flex items-center gap-1 text-ink-soft hover:text-ink" onClick={() => handleOpenResume(true)} disabled={openingResume}>
                    <i className="bi bi-download"></i> Download
                  </button>
                </div>
              )}
            </div>
          </div>

          <div className="flex gap-2 items-start">
            {app.status === 'archived' ? (
              <button className="btn btn-sm btn-outline-primary !py-2" onClick={handleRestore} disabled={updatingStatus}>
                <i className="bi bi-arrow-counterclockwise"></i> Restore
              </button>
            ) : app.status === 'withdrawn' ? (
              <span className="text-xs text-ink-soft max-w-[180px] leading-snug pt-2">Withdrawn by the applicant. Status is locked.</span>
            ) : (
              <MenuSelect
                value={app.status} onChange={handleStatusChange} disabled={updatingStatus} ariaLabel="Application status" prefix="Status" align="right"
                options={STATUSES.map((st) => ({ value: st, label: statusLabel(st), dot: STATUS_DOTS[st] }))}
              />
            )}
            <button className="btn btn-sm btn-outline-secondary !py-2" onClick={handleRerun} disabled={rerunning}>
              <i className={`bi bi-arrow-clockwise ${rerunning ? 'animate-spin' : ''}`}></i> {rerunning ? 'Analyzing...' : 'Re-run AI'}
            </button>
            {app.status !== 'archived' && (
              <button className="btn btn-sm btn-outline-secondary !py-2" onClick={() => setArchiveOpen(true)} title="Remove from active applications">
                <i className="bi bi-archive"></i> Archive
              </button>
            )}
          </div>
        </div>
      </div>

      {(jobBudget || expectedSalary) && (
        <div className="card mb-5">
          <div className="p-5 grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <div className="text-xs uppercase tracking-wide text-ink-soft mb-1">Job Budget (HR-set)</div>
              <div className="text-xl font-display font-bold">{jobBudget || <span className="text-ink-soft font-normal text-base">Not specified</span>}</div>
            </div>
            <div>
              <div className="text-xs uppercase tracking-wide text-ink-soft mb-1">Applicant's Expected Salary</div>
              <div className="text-xl font-display font-bold">{expectedSalary || <span className="text-ink-soft font-normal text-base">Not specified</span>}</div>
            </div>
          </div>
        </div>
      )}

      {app.ai_overall_score === null ? (
        <div className="alert-warning mb-5" role="alert">
          {app.ai_error
            ? <>AI screening failed for this application. Click "Re-run AI" above to try again. <span className="block mt-1 text-xs opacity-80 break-words">Reason: {app.ai_error}</span></>
            : 'This application has not been AI-analyzed yet. Click "Re-run AI" above to analyze it.'}
        </div>
      ) : (
        <>
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 sm:gap-5 mb-5">
            <div className="lg:col-span-3">
              <div className="card h-full">
                <div className="p-5 flex flex-col items-center justify-center h-full text-center">
                  <ScoreDial score={app.ai_overall_score} size={96} />
                  <div className="text-ink-soft text-sm mt-3">Overall Fit Score</div>
                </div>
              </div>
            </div>
            <div className="lg:col-span-9">
              <div className="card h-full">
                <div className="p-5">
                  <h6 className="card-title mb-3">Score Breakdown</h6>
                  {[['Skills Match', app.ai_skills_score], ['Experience Relevance', app.ai_experience_score], ['Education Fit', app.ai_education_score]].map(([label, val]) => (
                    <div className="mb-3 last:mb-0" key={label}>
                      <div className="flex justify-between text-sm mb-1"><span>{label}</span><span>{val}/100</span></div>
                      <ProgressBar value={val} />
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-5 mb-5">
            <div className="card h-full">
              <div className="p-5">
                <h6 className="card-title mb-2">Summary</h6>
                <p>{app.ai_summary}</p>
                <h6 className="text-sm uppercase tracking-wide text-ink-soft mt-4 mb-1">Strengths</h6>
                <ul className="list-disc pl-5 space-y-0.5">{strengths.length ? strengths.map((s, i) => <li key={i}>{s}</li>) : <li className="text-ink-soft list-none pl-0">None listed</li>}</ul>
                <h6 className="text-sm uppercase tracking-wide text-ink-soft mt-4 mb-1">Gaps / Concerns</h6>
                <ul className="list-disc pl-5 space-y-0.5">{gaps.length ? gaps.map((g, i) => <li key={i}>{g}</li>) : <li className="text-ink-soft list-none pl-0">None listed</li>}</ul>
              </div>
            </div>
            <div className="card h-full">
              <div className="p-5">
                <h6 className="card-title mb-3">Skills</h6>
                <div className="mb-4">
                  <div className="text-xs text-ink-soft mb-1.5">Matched</div>
                  <div className="flex flex-wrap gap-1.5">
                    {matched.length ? matched.map((s) => <span key={s} className="badge bg-success-soft text-success-ink border border-success-ink/15">{s}</span>) : <span className="text-ink-soft text-sm">None</span>}
                  </div>
                </div>
                <div>
                  <div className="text-xs text-ink-soft mb-1.5">Missing</div>
                  <div className="flex flex-wrap gap-1.5">
                    {missing.length ? missing.map((s) => <span key={s} className="badge bg-danger-soft text-danger border border-danger/15">{s}</span>) : <span className="text-ink-soft text-sm">None</span>}
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="card mb-5">
            <div className="p-5">
              <h6 className="card-title mb-3"><i className="bi bi-patch-question mr-1"></i> Suggested Interview Questions</h6>
              {questions.length === 0 && <p className="text-ink-soft">No questions generated.</p>}
              <div className="divide-y divide-line">
                {questions.map((q, i) => (
                  <details key={i} className="disclosure group py-2.5" open={i === 0}>
                    <summary className="flex items-center justify-between gap-3 font-medium text-sm py-1">
                      {q.question}
                      <i className="bi bi-chevron-down text-ink-soft transition-transform group-open:rotate-180 shrink-0"></i>
                    </summary>
                    <div className="text-ink-soft text-sm pt-2 pr-6"><strong className="text-ink">Why ask this:</strong> {q.reason}</div>
                  </details>
                ))}
              </div>
            </div>
          </div>
        </>
      )}

      <div className="card mb-5">
        <div className="p-5">
          <div className="flex items-center gap-2 flex-wrap mb-3">
            <h6 className="card-title mb-0"><i className="bi bi-mic mr-1"></i> Technical Interview &amp; Assessment Report</h6>
            <InterviewStatusBadge status={interview ? interview.status : interview === null ? 'not_started' : undefined} />
          </div>

          {interview === undefined && <p className="text-ink-soft mb-0">Loading...</p>}
          {interview === null && <p className="text-ink-soft mb-0">The applicant hasn't started the AI technical interview yet.</p>}

          {interview && (
            <>
              {interview.status === 'in_progress' && (
                <div className="alert-warning">
                  In progress. On question {Math.min(interview.current_index + 1, interview.total_questions)} of {interview.total_questions}, with the 20 minute timer running.
                  Updates live as the applicant answers.
                </div>
              )}
              {interview.status === 'timed_out' && (
                <div className="alert-danger mb-3">
                  Timed out. The 20 minute limit ended and the interview was submitted automatically.
                  {' '}{interview.answered_count} answered, {interview.skipped_count} skipped, {interview.total_questions - interview.history.length} not reached.
                </div>
              )}
              {interview.status === 'cancelled' && (
                <div className="alert-info mb-3">
                  Cancelled ({interview.ended_reason === 'application_withdrawn' ? 'application withdrawn' : interview.ended_reason === 'application_archived' ? 'application archived' : 'the applicant left the interview'}).
                  Progress up to that point is kept below.
                </div>
              )}
              {(interview.status === 'completed' || interview.status === 'timed_out') && !interview.report && interview.answered_count > 0 && (
                <div className="alert-info">The Technical Assessment Report is being generated.</div>
              )}
              {(interview.status === 'completed' || interview.status === 'timed_out') && interview.answered_count === 0 && (
                <div className="alert-info">No questions were answered, so there is no assessment report.</div>
              )}

              {interview.report && (
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 sm:gap-5 mb-4">
                  <div className="lg:col-span-3">
                    <div className="card h-full">
                      <div className="p-5 flex flex-col items-center justify-center h-full text-center">
                        <ScoreDial score={interview.report.technical_score} size={88} />
                        <div className="text-ink-soft text-sm mt-2">Technical Score</div>
                      </div>
                    </div>
                  </div>
                  <div className="lg:col-span-9">
                    <div className="card h-full">
                      <div className="p-5">
                        <div className="flex justify-between items-start gap-3 mb-3">
                          <h6 className="mb-0">Recommendation</h6>
                          <span className="badge bg-teal text-on-teal shrink-0 uppercase tracking-wide">{interview.report.recommendation}</span>
                        </div>
                        <div className="mb-3">
                          <div className="flex justify-between text-sm mb-1"><span>Communication</span><span>{interview.report.communication_score}/100</span></div>
                          <ProgressBar value={interview.report.communication_score} />
                        </div>
                        <p className="mb-0">{interview.report.summary}</p>
                      </div>
                    </div>
                  </div>
                  <div className="lg:col-span-6">
                    <h6 className="text-sm uppercase tracking-wide text-ink-soft mb-1">Strengths</h6>
                    <ul className="list-disc pl-5 space-y-0.5">{interview.report.strengths.length ? interview.report.strengths.map((s, i) => <li key={i}>{s}</li>) : <li className="text-ink-soft list-none pl-0">None listed</li>}</ul>
                  </div>
                  <div className="lg:col-span-6">
                    <h6 className="text-sm uppercase tracking-wide text-ink-soft mb-1">Weaknesses</h6>
                    <ul className="list-disc pl-5 space-y-0.5">{interview.report.weaknesses.length ? interview.report.weaknesses.map((w, i) => <li key={i}>{w}</li>) : <li className="text-ink-soft list-none pl-0">None listed</li>}</ul>
                  </div>
                </div>
              )}

              {interview.history.length > 0 && (
                <>
                  <h6 className="text-sm uppercase tracking-wide text-ink-soft mt-5 mb-1">Interview Transcript</h6>
                  <div className="divide-y divide-line">
                    {interview.history.map((turn, i) => (
                      <details key={i} className="disclosure group py-2.5">
                        <summary className="flex items-center justify-between gap-3 text-sm py-1">
                          <span className="flex-1"><span className="font-medium">Q{turn.question_index + 1}:</span> {turn.question}</span>
                          <span className="flex items-center gap-2 shrink-0">
                            {turn.skipped && <span className="badge bg-raised text-ink-soft border border-line">Skipped</span>}
                            {turn.eval_score !== null && turn.eval_score !== undefined && (
                              <span className="badge bg-line text-ink-soft">{turn.eval_score}/100</span>
                            )}
                            <i className="bi bi-chevron-down text-ink-soft transition-transform group-open:rotate-180"></i>
                          </span>
                        </summary>
                        <div className="pt-2 pr-6 text-sm">
                          {turn.skipped ? (
                            <p className="text-ink-soft mb-0">The applicant skipped this question. It is recorded as unanswered, not as a wrong answer.</p>
                          ) : (
                            <>
                              <p className="mb-2"><strong>Answer:</strong> {turn.answer}</p>
                              <p className="text-ink-soft mb-0"><strong>AI evaluation:</strong> {turn.eval_feedback}</p>
                            </>
                          )}
                        </div>
                      </details>
                    ))}
                  </div>
                </>
              )}
            </>
          )}
        </div>
      </div>

      <ChatThread applicationId={id} />

      <ConfirmDialog
        open={archiveOpen} tone="danger" icon="bi-archive" busy={archiving}
        title="Archive this application?"
        message="It will be removed from your active applications. All history stays saved, any live interview is cancelled, and you can restore it later."
        cancelLabel="Keep Active" confirmLabel="Archive Application"
        onCancel={() => setArchiveOpen(false)} onConfirm={handleArchive}
      />
    </div>
  );
}
