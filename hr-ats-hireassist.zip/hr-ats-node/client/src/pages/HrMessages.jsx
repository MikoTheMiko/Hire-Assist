import { Link } from 'react-router-dom';
import PageHeader from '../components/ui/PageHeader';
import MessagesInbox from '../components/messages/MessagesInbox';

// HR inbox: one conversation per application that has at least one message
// (GET /api/messages/hr/conversations). Shares its layout with the applicant inbox.
export default function HrMessages() {
  return (
    <div>
      <PageHeader title="Messages" subtitle="Conversations with candidates, updated live." />
      <MessagesInbox
        listPath="/messages/hr/conversations"
        applicationPath={(id) => `/hr/applications/${id}`}
        titleFor={(c) => c.applicant_name}
        subtitleFor={(c) => c.job_title}
        emptyList={{
          icon: 'bi-chat-dots', title: 'No conversations yet',
          message: 'Message a candidate from their application page and it will show up here.',
          action: <Link to="/hr/applications" className="btn btn-sm btn-outline-secondary">Go to Applications</Link>,
        }}
      />
    </div>
  );
}
