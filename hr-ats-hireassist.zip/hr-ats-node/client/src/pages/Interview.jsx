import { useCallback, useEffect, useRef, useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import api from '../api';
import { useSocket } from '../context/SocketContext';
import { useToast } from '../context/ToastContext';
import ScoreDial from '../components/ScoreDial';
import { InterviewStatusBadge } from '../components/StatusBadge';
import InterviewTimer from '../components/interview/InterviewTimer';
import ConfirmDialog from '../components/ui/ConfirmDialog';
import { interviewStatusLabel } from '../utils/format';

// Small wrapper around the browser's SpeechRecognition API so the rest of
// the component doesn't need to care about vendor prefixes or lifecycle.
// Returns null if the browser doesn't support it at all.
function useSpeechToText({ onFinalChunk }) {
  const recognitionRef = useRef(null);
  const [listening, setListening] = useState(false);
  const [interimText, setInterimText] = useState('');
  const [supported] = useState(() => typeof window !== 'undefined' && !!(window.SpeechRecognition || window.webkitSpeechRecognition));

  useEffect(() => {
    if (!supported) return;
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    const recognition = new SpeechRecognition();
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.lang = 'en-US';

    recognition.onresult = (event) => {
      let interim = '';
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const transcript = event.results[i][0].transcript;
        if (event.results[i].isFinal) {
          onFinalChunk(transcript);
        } else {
          interim += transcript;
        }
      }
      setInterimText(interim);
    };
    recognition.onerror = () => setListening(false);
    recognition.onend = () => setListening(false);

    recognitionRef.current = recognition;
    return () => recognition.stop();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [supported]);

  function start() {
    if (!recognitionRef.current || listening) return;
    setInterimText('');
    try {
      recognitionRef.current.start();
      setListening(true);
    } catch {
      // start() throws if already running - safe to ignore
    }
  }

  function stop() {
    recognitionRef.current?.stop();
    setListening(false);
    setInterimText('');
  }

  return { supported, listening, interimText, start, stop };
}

function QuestionTypePill({ type }) {
  const isMc = type === 'multiple_choice';
  return (
    <span className={`qtype-pill ${isMc ? 'mc' : 'id'}`}>
      <i className={`bi ${isMc ? 'bi-ui-checks' : 'bi-input-cursor-text'}`}></i>
      {isMc ? 'Multiple Choice' : 'Identification'}
    </span>
  );
}

function RailStep({ index, currentIndex, total, focusArea, turn, live }) {
  const state = turn?.skipped ? 'skipped' : turn ? 'done' : live && index === currentIndex ? 'active' : 'pending';
  return (
    <div className="interview-rail-step">
      <span className={`interview-rail-dot ${state}`}>
        {state === 'done' ? <i className="bi bi-check-lg"></i> : state === 'skipped' ? <i className="bi bi-skip-forward-fill"></i> : index + 1}
      </span>
      <div className="min-w-0">
        <div className={state === 'pending' ? 'text-ink-soft/70' : 'text-ink'}>
          Question {index + 1} of {total}{state === 'skipped' ? ' (skipped)' : ''}
        </div>
        {focusArea && <div className="text-ink-soft text-xs truncate">{focusArea}</div>}
      </div>
    </div>
  );
}

const ENDED_NOTICE = {
  completed: null,
  timed_out: { tone: 'alert-warning', icon: 'bi-alarm', text: 'Time expired. The 20 minute limit ended, so your interview was submitted automatically. No more answers can be added.' },
  cancelled: { tone: 'alert-info', icon: 'bi-slash-circle', text: 'This interview was cancelled. Your progress was saved, but it cannot be resumed.' },
};

// The whole "AI asks a question -> applicant answers -> AI evaluates -> AI
// asks the next one" loop lives here, now against a 20 minute clock owned by the server.
// `session` mirrors what the server serializes: { status, current_index, total_questions, current_question,
// remaining_seconds, history: [{question, answer, skipped, eval_score, eval_feedback}], report }.
export default function Interview() {
  const { id } = useParams(); // this is the application id
  const navigate = useNavigate();
  const toast = useToast();
  const { socket } = useSocket();
  const [session, setSession] = useState(undefined); // undefined = loading, null = not started
  const [clock, setClock] = useState({ remaining: 0, key: 0 }); // last server reading of the timer; only replaced by a server response
  const [timeUp, setTimeUp] = useState(false);
  const [starting, setStarting] = useState(false);
  const [draft, setDraft] = useState('');
  const [selectedChoice, setSelectedChoice] = useState(null);
  const [submitting, setSubmitting] = useState(false);
  const [skipping, setSkipping] = useState(false);
  const [leaveOpen, setLeaveOpen] = useState(false);
  const [cancelling, setCancelling] = useState(false);
  const [error, setError] = useState('');
  const bottomRef = useRef(null);

  const speech = useSpeechToText({
    onFinalChunk: (chunk) => setDraft((prev) => (prev ? `${prev.trim()} ${chunk.trim()}` : chunk.trim())),
  });

  // Takes any session object from the server and makes it the current one, re-anchoring the timer.
  const applySession = useCallback((next) => {
    setSession(next);
    if (next?.status === 'in_progress') {
      setClock((c) => ({ remaining: next.remaining_seconds, key: c.key + 1 }));
      setTimeUp(false);
    }
  }, []);

  const load = useCallback(() => (
    api.get(`/interviews/${id}`)
      .then((res) => applySession(res.data.session))
      .catch((err) => { setSession(null); setError(err.response?.data?.error || 'Could not load the interview.'); })
  ), [id, applySession]);

  useEffect(() => { load(); }, [load]);

  // Report arrives in the background after the interview ends. Status events keep this page honest
  // if the interview is closed elsewhere (timer sweeper, withdrawn application, another tab).
  useEffect(() => {
    if (!socket) return undefined;
    socket.emit('application:join', id);

    function handleReportReady(payload) {
      if (payload.applicationId === Number(id)) {
        setSession((prev) => (prev ? { ...prev, report: payload.report } : prev));
      }
    }
    function handleStatus(payload) {
      if (payload.applicationId === Number(id)) load();
    }
    socket.on('interview:report_ready', handleReportReady);
    socket.on('interview:status', handleStatus);
    return () => {
      socket.emit('application:leave', id);
      socket.off('interview:report_ready', handleReportReady);
      socket.off('interview:status', handleStatus);
    };
  }, [socket, id, load]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [session?.history?.length]);

  // Reset the per-question input state whenever the active question changes.
  useEffect(() => {
    setDraft('');
    setSelectedChoice(null);
    speech.stop();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [session?.current_index]);

  // Timer hit 00:00: lock the form immediately, then ask the server, which closes the session as timed_out.
  const handleExpire = useCallback(async () => {
    setTimeUp(true);
    speech.stop();
    try {
      const res = await api.get(`/interviews/${id}`);
      applySession(res.data.session);
      if (res.data.session?.status === 'timed_out') {
        toast.warning('Interview timed out', { description: 'The 20 minute limit ended and your interview was submitted automatically.' });
      }
    } catch {
      setError('Time is up. We could not confirm the result yet, please refresh the page.');
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id, applySession, toast]);

  const inProgress = session?.status === 'in_progress';
  const canAnswer = inProgress && !timeUp;
  const isMultipleChoice = session?.current_question?.type === 'multiple_choice';
  const canSubmit = isMultipleChoice ? !!selectedChoice : !!draft.trim();
  const busy = submitting || skipping;

  // A 409 from the server carries the up-to-date session (expired, cancelled, withdrawn...): show that instead.
  function handleConflict(err, fallback) {
    const data = err.response?.data;
    if (err.response?.status === 409 && data?.session) {
      applySession(data.session);
      setError('');
      if (data.code === 'timed_out') toast.warning('Interview timed out', { description: data.error });
      else toast.warning('Interview closed', { description: data.error });
      return;
    }
    setError(data?.error || fallback);
  }

  async function handleStart() {
    setStarting(true);
    setError('');
    try {
      const res = await api.post(`/interviews/${id}/start`);
      applySession(res.data.session);
      if (res.data.session.status === 'in_progress' && res.status === 201) {
        toast.success('Interview Started', { description: 'You have 20 minutes. The timer is running.' });
      }
    } catch (err) {
      setError(err.response?.data?.error || 'Could not start the interview.');
    } finally {
      setStarting(false);
    }
  }

  // Shared by submit and skip: appends the finished turn and moves to the next question or the end.
  function advance(prev, turn, data) {
    return {
      ...prev,
      history: [...prev.history, turn],
      status: data.done ? 'completed' : 'in_progress',
      current_index: data.done ? prev.current_index + 1 : data.current_index,
      current_question: data.done ? null : data.next_question,
      remaining_seconds: data.done ? 0 : prev.remaining_seconds,
    };
  }

  async function handleSubmit(e) {
    e.preventDefault();
    const answerText = isMultipleChoice ? selectedChoice : draft.trim();
    if (!answerText || busy || !canAnswer) return;
    setSubmitting(true);
    setError('');
    speech.stop();
    try {
      const res = await api.post(`/interviews/${id}/answer`, { answer: answerText });
      setSession((prev) => advance(prev, {
        question_index: prev.current_index,
        question: prev.current_question.question,
        focus_area: prev.current_question.focus_area,
        type: prev.current_question.type,
        choices: prev.current_question.choices,
        answer: answerText,
        skipped: false,
        eval_score: res.data.eval.score,
        eval_feedback: res.data.eval.feedback,
      }, res.data));
      if (res.data.done) toast.success('Interview Completed', { description: 'Your Technical Assessment Report is being generated.' });
    } catch (err) {
      handleConflict(err, 'Could not submit your answer.');
    } finally {
      setSubmitting(false);
    }
  }

  async function handleSkip() {
    if (busy || !canAnswer) return;
    setSkipping(true);
    setError('');
    speech.stop();
    try {
      const res = await api.post(`/interviews/${id}/skip`);
      setSession((prev) => advance(prev, {
        question_index: prev.current_index,
        question: prev.current_question.question,
        focus_area: prev.current_question.focus_area,
        type: prev.current_question.type,
        choices: prev.current_question.choices,
        answer: '',
        skipped: true,
        eval_score: null,
        eval_feedback: null,
      }, res.data));
      if (res.data.done) toast.success('Interview Completed', { description: 'You have reached the end of the questions.' });
    } catch (err) {
      handleConflict(err, 'Could not skip this question.');
    } finally {
      setSkipping(false);
    }
  }

  async function handleCancelInterview() {
    setCancelling(true);
    try {
      await api.post(`/interviews/${id}/cancel`);
      setLeaveOpen(false);
      toast.success('Interview Cancelled', { description: 'Your progress was saved.' });
      navigate(`/applications/${id}`);
    } catch (err) {
      setLeaveOpen(false);
      handleConflict(err, 'Could not cancel the interview.');
    } finally {
      setCancelling(false);
    }
  }

  // "Back to application" must not silently walk away from a live interview.
  function onBackClick(e) {
    if (inProgress) {
      e.preventDefault();
      setLeaveOpen(true);
    }
  }

  if (session === undefined) return <div className="jd-loading" role="status"><span className="searchbar__spinner" aria-hidden="true"></span> Loading interview...</div>;

  const total = session?.total_questions || 0;
  const doneCount = session ? session.history.length : 0;
  const ended = session && !inProgress;
  const endedNotice = ended ? ENDED_NOTICE[session.status] : null;
  const answeredCount = session ? session.history.filter((t) => !t.skipped).length : 0;

  return (
    <div>
      <Link to={`/applications/${id}`} onClick={onBackClick} className="jd-back"><i className="bi bi-arrow-left" aria-hidden="true"></i> Back to application</Link>
      <div className="flex flex-wrap items-start justify-between gap-3 mb-5">
        <div>
          <h1 className="page-title">Technical Interview</h1>
          <p className="text-ink-soft mb-0">A short, AI-conducted interview based on your resume and this role's requirements.</p>
        </div>
        <InterviewStatusBadge status={session ? session.status : 'not_started'} />
      </div>

      {error && <div className="alert-danger mb-4" role="alert">{error}</div>}

      {session === null && (
        <div className="card">
          <div className="p-8 sm:p-12 text-center">
            <div className="interviewer-avatar mx-auto mb-4" style={{ width: 56, height: 56, fontSize: '1.5rem' }}>
              <i className="bi bi-cpu"></i>
            </div>
            <h5 className="text-lg mb-2">Ready to start your technical interview?</h5>
            <p className="text-ink-soft mb-3 max-w-[60ch] mx-auto">
              The AI will analyze your resume against the job requirements and ask you 5 personalized
              technical questions, a mix of multiple choice and identification. You can type your
              answers or use the microphone.
            </p>
            <p className="text-ink-soft mb-5 max-w-[60ch] mx-auto inline-flex items-start gap-2 text-left text-sm">
              <i className="bi bi-stopwatch mt-0.5" aria-hidden="true"></i>
              <span>You have <strong className="text-ink">20 minutes</strong> in total. The timer starts when you press Start, keeps running if you refresh, and cannot be paused. You can skip any question.</span>
            </p>
            <div>
              <button className="btn btn-primary btn-lg" onClick={handleStart} disabled={starting}>
                {starting && <span className="btn-spinner" aria-hidden="true"></span>}
                {starting ? 'Preparing your questions...' : 'Start Interview'}
              </button>
            </div>
          </div>
        </div>
      )}

      {session && (
        <div className="interview-bar">
          <div className="flex items-center gap-4">
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between text-xs text-ink-soft mb-1.5">
                <span>{inProgress ? `Question ${Math.min(session.current_index + 1, total)} of ${total}` : `${doneCount} of ${total} questions handled`}</span>
                <span>{doneCount}/{total}</span>
              </div>
              <div className="interview-progress !mb-0" role="progressbar" aria-label="Interview progress" aria-valuemin={0} aria-valuemax={total} aria-valuenow={doneCount}>
                <div style={{ width: `${total ? (doneCount / total) * 100 : 0}%` }}></div>
              </div>
            </div>
            {inProgress && (
              <InterviewTimer
                remainingSeconds={clock.remaining} totalSeconds={session.duration_seconds} syncKey={clock.key}
                running={!timeUp} onExpire={handleExpire}
              />
            )}
            {inProgress && (
              <button type="button" className="btn btn-sm btn-outline-secondary shrink-0" onClick={() => setLeaveOpen(true)}>
                <i className="bi bi-box-arrow-left" aria-hidden="true"></i><span className="hidden sm:inline">Leave</span>
              </button>
            )}
          </div>
        </div>
      )}

      {session && (
        <div className="interview-shell">
          {/* Progress rail */}
          <aside className="interview-rail">
            <div className="text-xs uppercase tracking-wide text-ink-soft mb-3">Interview Progress</div>
            {Array.from({ length: total }).map((_, i) => {
              const turn = session.history.find((t) => t.question_index === i);
              return (
                <RailStep
                  key={i} index={i} currentIndex={session.current_index} total={total} live={inProgress}
                  focusArea={turn?.focus_area || (i === session.current_index ? session.current_question?.focus_area : null)}
                  turn={turn}
                />
              );
            })}
            {session.status === 'completed' && (
              <div className="mt-3 pt-3 border-t border-line text-sm text-success-ink flex items-center gap-1.5">
                <i className="bi bi-check-circle-fill"></i> Interview complete
              </div>
            )}
          </aside>

          {/* Main stage */}
          <div>
            <div className="interview-stage mb-5">
              <div className="interview-stage-header">
                <div className="interviewer-avatar"><i className="bi bi-cpu"></i></div>
                <div className="min-w-0">
                  <div className="font-display font-semibold text-sm">AI Interviewer</div>
                  <div className="text-ink-soft text-xs">
                    {inProgress ? `Question ${Math.min(session.current_index + 1, total)} of ${total}` : `Session ${interviewStatusLabel(session.status).toLowerCase()}`}
                  </div>
                </div>
              </div>

              <div className="p-4 sm:p-5">
                {endedNotice && (
                  <div className={`${endedNotice.tone} mb-4 flex items-start gap-2`}>
                    <i className={`bi ${endedNotice.icon} mt-0.5`} aria-hidden="true"></i>
                    <span>{endedNotice.text}{session.status === 'timed_out' && ` You answered ${answeredCount} of ${total} questions.`}</span>
                  </div>
                )}

                <div className="max-h-[420px] overflow-y-auto mb-4">
                  {session.history.map((turn, i) => (
                    <div key={i} className="mb-3">
                      <div className="chat-bubble them">
                        <div className="flex items-center justify-between gap-2 mb-1.5">
                          <span className="text-sm font-semibold">AI Interviewer{turn.focus_area ? ` · ${turn.focus_area}` : ''}</span>
                          {turn.type && <QuestionTypePill type={turn.type} />}
                        </div>
                        {turn.question}
                      </div>
                      {turn.skipped ? (
                        <div className="chat-bubble skipped">
                          <i className="bi bi-skip-forward-fill mr-1.5" aria-hidden="true"></i>You skipped this question
                        </div>
                      ) : (
                        <div className="chat-bubble me">
                          <div className="text-sm font-semibold mb-1">You</div>
                          {turn.answer}
                        </div>
                      )}
                    </div>
                  ))}
                  <div ref={bottomRef} />
                </div>

                {inProgress && timeUp && (
                  <div className="alert-warning mb-0 flex items-start gap-2" role="status">
                    <i className="bi bi-alarm mt-0.5" aria-hidden="true"></i>
                    <span>Time is up. Submitting your interview...</span>
                  </div>
                )}

                {canAnswer && session.current_question && (
                  <div key={session.current_index} className="border-t border-line pt-4 q-enter">
                    <div className="flex items-center justify-between gap-2 mb-3">
                      <div className="font-medium text-sm">
                        {session.current_question.focus_area && (
                          <span className="text-ink-soft mr-2">{session.current_question.focus_area}</span>
                        )}
                      </div>
                      <QuestionTypePill type={session.current_question.type} />
                    </div>

                    <p className="interview-question">{session.current_question.question}</p>

                    <form onSubmit={handleSubmit}>
                      {isMultipleChoice ? (
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 mb-4" role="radiogroup" aria-label="Answer choices">
                          {session.current_question.choices.map((choice, i) => (
                            <button
                              type="button"
                              key={i}
                              role="radio"
                              aria-checked={selectedChoice === choice}
                              className={`choice-option ${selectedChoice === choice ? 'selected' : ''}`}
                              onClick={() => setSelectedChoice(choice)}
                              disabled={busy}
                            >
                              <span className="choice-marker">{String.fromCharCode(65 + i)}</span>
                              {choice}
                            </button>
                          ))}
                        </div>
                      ) : (
                        <div className="flex items-start gap-3 mb-2">
                          <textarea
                            className="input"
                            aria-label="Your answer"
                            rows={4}
                            placeholder={speech.listening ? 'Listening...' : 'Type your answer, or use the mic...'}
                            value={speech.listening ? `${draft}${draft ? ' ' : ''}${speech.interimText}` : draft}
                            onChange={(e) => setDraft(e.target.value)}
                            disabled={busy}
                          />
                          {speech.supported && (
                            <button
                              type="button"
                              className={`mic-btn ${speech.listening ? 'recording' : ''}`}
                              onClick={() => (speech.listening ? speech.stop() : speech.start())}
                              disabled={busy}
                              title={speech.listening ? 'Stop recording' : 'Answer with your voice'}
                              aria-label={speech.listening ? 'Stop recording' : 'Answer with your voice'}
                              aria-pressed={speech.listening}
                            >
                              <i className={`bi ${speech.listening ? 'bi-mic-fill' : 'bi-mic'}`}></i>
                            </button>
                          )}
                        </div>
                      )}

                      {speech.listening && (
                        <div className="text-xs text-danger flex items-center gap-1.5 mb-3">
                          <span className="w-1.5 h-1.5 rounded-full bg-danger animate-pulse-live"></span>
                          Recording. Click the mic again to stop.
                        </div>
                      )}

                      <div className="flex flex-wrap items-center gap-2.5">
                        <button className="btn btn-primary" type="submit" disabled={busy || !canSubmit}>
                          {submitting && <span className="btn-spinner" aria-hidden="true"></span>}
                          {submitting ? 'Evaluating...' : 'Submit Answer'}
                        </button>
                        <button className="btn btn-outline-secondary" type="button" onClick={handleSkip} disabled={busy}>
                          {skipping ? <span className="btn-spinner" aria-hidden="true"></span> : <i className="bi bi-skip-forward" aria-hidden="true"></i>}
                          Skip question
                        </button>
                      </div>
                    </form>
                  </div>
                )}

                {session.status === 'completed' && !session.report && answeredCount > 0 && (
                  <div className="alert-info mb-0">
                    <i className="bi bi-hourglass-split"></i> Interview complete. Generating your Technical Assessment Report. This updates automatically.
                  </div>
                )}
                {session.status === 'completed' && answeredCount === 0 && (
                  <div className="alert-info mb-0">Interview complete. You skipped every question, so there is no assessment report to generate.</div>
                )}
                {session.status === 'timed_out' && !session.report && answeredCount > 0 && (
                  <div className="alert-info mb-0">
                    <i className="bi bi-hourglass-split"></i> Generating a report from the questions you answered. This updates automatically.
                  </div>
                )}
              </div>
            </div>

            {session.report && (
              <div className="card">
                <div className="p-5">
                  <h5 className="card-title mb-4">Your Technical Assessment Report</h5>
                  <div className="flex flex-col sm:flex-row items-center gap-6 mb-3">
                    <div className="text-center shrink-0">
                      <ScoreDial score={session.report.technical_score} size={120} label="Technical score" />
                      <div className="text-ink-soft text-sm font-semibold mt-2">Technical</div>
                    </div>
                    {session.report.communication_score !== null && session.report.communication_score !== undefined && (
                      <div className="text-center shrink-0">
                        <ScoreDial score={session.report.communication_score} size={120} label="Communication score" />
                        <div className="text-ink-soft text-sm font-semibold mt-2">Communication</div>
                      </div>
                    )}
                    <div>
                      <p className="mb-0">{session.report.summary}</p>
                    </div>
                  </div>
                  <p className="text-ink-soft text-sm mb-0">
                    HR has been notified and will review your full results alongside this report.
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      <ConfirmDialog
        open={leaveOpen} tone="danger" icon="bi-box-arrow-left" busy={cancelling}
        title="Leave this interview?"
        message="Your current progress will be saved, but the interview will be marked as cancelled."
        cancelLabel="Continue Interview" confirmLabel="Cancel Interview"
        onCancel={() => setLeaveOpen(false)} onConfirm={handleCancelInterview}
      />
    </div>
  );
}
