import api from '../api';

// All dashboard analytics come from the backend (/api/dashboard/*), computed
// with SQL aggregation on the logged-in HR user's own jobs. Nothing here
// calculates global statistics client-side.
const get = (path, params, signal) => api.get(`/dashboard/${path}`, { params, signal }).then((r) => r.data);

export const getStats = (signal) => get('stats', undefined, signal);
export const getApplicationsOverTime = (range, signal) => get('applications-over-time', { range }, signal);
export const getPipeline = (signal) => get('pipeline', undefined, signal);
export const getJobsPerformance = (signal) => get('jobs-performance', { limit: 8 }, signal);
export const getScreeningDistribution = (signal) => get('screening-distribution', undefined, signal);
export const getInterviewPerformance = (signal) => get('interview-performance', undefined, signal);
export const getRecentApplications = (signal) => get('recent-applications', { limit: 6 }, signal);
export const getRecentInterviews = (signal) => get('recent-interviews', { limit: 6 }, signal);
