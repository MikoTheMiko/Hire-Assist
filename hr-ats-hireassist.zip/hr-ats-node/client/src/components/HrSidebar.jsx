import { useEffect } from 'react';
import { NavLink, Link, useLocation } from 'react-router-dom';
import { Logo } from './ui/Logo';
import ThemeToggle from './ui/ThemeToggle';
import { useSocket } from '../context/SocketContext';

// Existing routes are preserved; the old "Applications" list moved from
// /hr/dashboard to /hr/applications so /hr/dashboard can be the analytics home.
const GROUPS = [
  { label: 'Overview', items: [{ to: '/hr/dashboard', icon: 'bi-grid-1x2', label: 'Dashboard' }] },
  {
    label: 'Recruitment',
    items: [
      { to: '/hr/jobs', icon: 'bi-briefcase', label: 'Jobs', also: ['/hr/post-job'] },
      { to: '/hr/applications', icon: 'bi-people', label: 'Applications' },
      { to: '/hr/interviews', icon: 'bi-mic', label: 'Interviews' },
    ],
  },
  { label: 'Communication', items: [{ to: '/hr/messages', icon: 'bi-chat-dots', label: 'Messages' }] },
];

export function Brand({ collapsed, onNavigate }) {
  return (
    <div className="flex items-center px-4 h-[68px] shrink-0">
      <Logo to="/hr/dashboard" onClick={onNavigate} size={34} showWordmark={!collapsed} />
    </div>
  );
}

function SidebarContents({ collapsed, onNavigate, onToggleCollapse }) {
  const { pathname } = useLocation();
  const { unreadMessages } = useSocket();

  return (
    <div className="flex flex-col h-full">
      <Brand collapsed={collapsed} onNavigate={onNavigate} />

      <nav className="px-3 flex-1 overflow-y-auto pb-4" aria-label="HR navigation">
        {GROUPS.map((g) => (
          <div key={g.label}>
            {collapsed ? <div className="border-t border-line my-3 first:hidden"></div> : <div className="sidebar-group">{g.label}</div>}
            {g.items.map((l) => {
              const forcedActive = l.also?.some((p) => pathname.startsWith(p));
              return (
                <NavLink
                  key={l.to} to={l.to} onClick={onNavigate} title={collapsed ? l.label : undefined}
                  className={({ isActive }) => `sidebar-link ${isActive || forcedActive ? 'active' : ''} ${collapsed ? 'justify-center !px-0' : ''}`}
                >
                  <i className={`bi ${l.icon}`}></i>
                  {!collapsed && <span>{l.label}</span>}
                  {collapsed && <span className="sr-only">{l.label}</span>}
                  {l.to === '/hr/messages' && unreadMessages > 0 && (
                    <span className={collapsed ? 'absolute top-1.5 right-2.5 w-2.5 h-2.5 rounded-full bg-danger' : 'ml-auto nav-badge !m-0'} aria-label={`${unreadMessages} unread messages`}>
                      {!collapsed && (unreadMessages > 99 ? '99+' : unreadMessages)}
                    </span>
                  )}
                </NavLink>
              );
            })}
          </div>
        ))}
      </nav>

      <div className="px-3 py-3 border-t border-line shrink-0">
        {/* The top bar hides its theme switch on small screens, so the mobile drawer carries one */}
        {!onToggleCollapse && <div className="mb-3"><ThemeToggle labels /></div>}
        <Link to="/" onClick={onNavigate} title={collapsed ? 'View public site' : undefined}
              className={`sidebar-link !mb-1 ${collapsed ? 'justify-center !px-0' : ''}`}>
          <i className="bi bi-globe2"></i>{!collapsed && <span>View public site</span>}
        </Link>
        {onToggleCollapse && (
          <button type="button" onClick={onToggleCollapse}
                  className={`sidebar-link w-full !mb-0 ${collapsed ? 'justify-center !px-0' : ''}`}
                  aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'} aria-pressed={collapsed}>
            <i className={`bi ${collapsed ? 'bi-chevron-double-right' : 'bi-chevron-double-left'}`}></i>
            {!collapsed && <span>Collapse</span>}
          </button>
        )}
      </div>
    </div>
  );
}

export default function HrSidebar({ collapsed, onToggleCollapse, mobileOpen, onCloseMobile }) {
  // Escape closes the mobile drawer
  useEffect(() => {
    if (!mobileOpen) return undefined;
    const onKey = (e) => { if (e.key === 'Escape') onCloseMobile(); };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [mobileOpen, onCloseMobile]);

  return (
    <>
      {/* Desktop: persistent sidebar (width animates between full and icon-only) */}
      <aside
        className={`hidden lg:flex lg:flex-col lg:fixed lg:inset-y-0 lg:left-0 bg-surface/90 backdrop-blur border-r border-line z-30 transition-[width] duration-300 ease-out ${collapsed ? 'lg:w-[76px]' : 'lg:w-64'}`}
      >
        <SidebarContents collapsed={collapsed} onToggleCollapse={onToggleCollapse} />
      </aside>

      {/* Mobile: slide-in drawer with fading backdrop (always mounted so it can animate) */}
      <div className={`lg:hidden fixed inset-0 z-40 ${mobileOpen ? '' : 'pointer-events-none'}`} aria-hidden={!mobileOpen}>
        <div className={`absolute inset-0 bg-black/60 backdrop-blur-sm transition-opacity duration-300 ${mobileOpen ? 'opacity-100' : 'opacity-0'}`} onClick={onCloseMobile}></div>
        <aside className={`absolute inset-y-0 left-0 w-72 max-w-[82vw] bg-surface border-r border-line transition-transform duration-300 ease-out ${mobileOpen ? 'translate-x-0' : '-translate-x-full'}`}>
          <SidebarContents collapsed={false} onNavigate={onCloseMobile} />
        </aside>
      </div>
    </>
  );
}
