import useApi from '../../hooks/useApi';
import { getPipeline } from '../../services/dashboardApi';
import ChartCard from '../ui/ChartCard';
import HBarChart from '../charts/HBarChart';
import { statusLabel } from '../../utils/format';

// Same colours as the status badges, so the chart and the tables agree.
const STAGE_COLOR = {
  submitted: '#94A3B8', screened: '#0EA5E9', shortlisted: '#6366F1',
  interview: '#F59E0B', offer: '#10B981', rejected: '#F87171', withdrawn: '#64748B',
};

export default function PipelineCard({ refreshKey }) {
  const { data, loading, refreshing, error, reload } = useApi((signal) => getPipeline(signal), [refreshKey]);

  return (
    <ChartCard
      title="Hiring Pipeline" subtitle="Applications by current status"
      loading={loading} refreshing={refreshing} error={error} onRetry={reload}
      isEmpty={data && data.total === 0}
      empty={{ icon: 'bi-funnel', title: 'No applications yet', message: 'Start receiving applications to see your hiring analytics.' }}
      skeletonHeight={300}
    >
      {data && (
        <HBarChart
          labelWidth={92}
          items={data.stages.map((s) => ({
            key: s.status, label: statusLabel(s.status), value: s.count, color: STAGE_COLOR[s.status],
            to: `/hr/applications?status=${s.status}`, // drill down into the filtered list
          }))}
        />
      )}
    </ChartCard>
  );
}
