import { Link } from 'react-router-dom';
import useApi from '../../hooks/useApi';
import { getJobsPerformance } from '../../services/dashboardApi';
import ChartCard from '../ui/ChartCard';
import HBarChart from '../charts/HBarChart';

export default function JobsPerformanceCard({ refreshKey }) {
  const { data, loading, refreshing, error, reload } = useApi((signal) => getJobsPerformance(signal), [refreshKey]);

  return (
    <ChartCard
      title="Applications by Job" subtitle="Top postings by applicant volume"
      loading={loading} refreshing={refreshing} error={error} onRetry={reload}
      isEmpty={data && data.jobs.length === 0}
      empty={{
        icon: 'bi-briefcase', title: 'No applications yet',
        message: 'Once candidates apply, your most popular postings will show up here.',
        action: <Link to="/hr/jobs" className="btn btn-sm btn-outline-secondary">Go to Jobs</Link>,
      }}
      skeletonHeight={260}
    >
      {data && (
        <HBarChart
          colorFallback="#8B5CF6" labelWidth={130}
          items={data.jobs.map((j) => ({
            key: j.id, label: j.title, value: j.applications, to: `/hr/applications?job=${j.id}`,
          }))}
        />
      )}
    </ChartCard>
  );
}
