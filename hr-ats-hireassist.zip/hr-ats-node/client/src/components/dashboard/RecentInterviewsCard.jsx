import { Link, useNavigate } from 'react-router-dom';
import useApi from '../../hooks/useApi';
import { getRecentInterviews } from '../../services/dashboardApi';
import ChartCard from '../ui/ChartCard';
import Avatar from '../ui/Avatar';
import ScorePill from '../ui/ScorePill';
import { InterviewStatusBadge } from '../StatusBadge';
import { timeAgo } from '../../utils/format';

// The system has no scheduled interviews — sessions are started by applicants —
// so this shows real session activity (status, progress, score, when).
export function InterviewStatus({ session }) {
  const total = session.total_questions;
  const detail = session.status === 'in_progress' && total ? `${Math.min(session.current_index + 1, total)}/${total}` : undefined;
  return <InterviewStatusBadge status={session.status} detail={detail} />;
}

export default function RecentInterviewsCard({ refreshKey }) {
  const navigate = useNavigate();
  const { data, loading, refreshing, error, reload } = useApi((signal) => getRecentInterviews(signal), [refreshKey]);

  return (
    <ChartCard
      title="Recent Interview Activity" subtitle="Latest AI technical interview sessions"
      loading={loading} refreshing={refreshing} error={error} onRetry={reload}
      isEmpty={data && data.interviews.length === 0}
      empty={{ icon: 'bi-mic', title: 'No interview data yet', message: 'Completed interviews will appear here.' }}
      skeletonHeight={280}
      action={<Link to="/hr/interviews" className="text-[0.8rem] font-semibold">View all <i className="bi bi-arrow-right"></i></Link>}
    >
      {data && (
        <ul className="list-none m-0 p-0 space-y-0.5">
          {data.interviews.map((s) => (
            <li key={s.id}>
              <button type="button" className="list-row w-full text-left" onClick={() => navigate(`/hr/applications/${s.application_id}`)}>
                <Avatar name={s.applicant_name} size={38} />
                <div className="min-w-0 flex-1">
                  <div className="font-medium text-[0.92rem] truncate">{s.applicant_name}</div>
                  <div className="text-ink-soft text-[0.78rem] truncate">{s.job_title} · {timeAgo(s.completed_at || s.started_at)}</div>
                </div>
                <div className="hidden sm:block"><InterviewStatus session={s} /></div>
                <ScorePill score={s.report_technical_score} pendingLabel="-" />
              </button>
            </li>
          ))}
        </ul>
      )}
    </ChartCard>
  );
}
