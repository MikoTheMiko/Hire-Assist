import useApi from '../../hooks/useApi';
import { getScreeningDistribution } from '../../services/dashboardApi';
import ChartCard from '../ui/ChartCard';
import ColumnChart from '../charts/ColumnChart';

const BUCKET_COLOR = { '90-100': '#10B981', '80-89': '#0EA5E9', '70-79': '#6366F1', '60-69': '#F59E0B', 'below-60': '#EF4444' };

export default function ScreeningDistributionCard({ refreshKey }) {
  const { data, loading, refreshing, error, reload } = useApi((signal) => getScreeningDistribution(signal), [refreshKey]);

  const subtitle = data && data.scored > 0
    ? `${data.scored} screened · average ${data.average}${data.pending ? ` · ${data.pending} pending` : ''}`
    : 'AI resume screening scores';

  return (
    <ChartCard
      title="AI Screening Distribution" subtitle={subtitle}
      loading={loading} refreshing={refreshing} error={error} onRetry={reload}
      isEmpty={data && data.scored === 0}
      empty={{
        icon: 'bi-stars', title: 'No screening scores yet',
        message: data?.pending ? `${data.pending} application${data.pending === 1 ? ' is' : 's are'} waiting for AI screening.` : 'Scores appear as soon as applications are screened.',
      }}
      skeletonHeight={260}
    >
      {data && <ColumnChart items={data.buckets.map((b) => ({ key: b.key, label: b.label, value: b.count, color: BUCKET_COLOR[b.key] }))} />}
    </ChartCard>
  );
}
