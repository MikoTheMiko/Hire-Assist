import useApi from '../../hooks/useApi';
import { getStats } from '../../services/dashboardApi';
import StatCard, { StatCardSkeleton } from '../ui/StatCard';
import ErrorState from '../ui/ErrorState';

// Four headline numbers, all from GET /api/dashboard/stats.
export default function KpiRow({ refreshKey }) {
  const { data, loading, error, reload } = useApi((signal) => getStats(signal), [refreshKey]);

  if (loading) {
    return <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">{[0, 1, 2, 3].map((i) => <StatCardSkeleton key={i} />)}</div>;
  }
  if (error) {
    return <div className="card"><ErrorState message="Unable to load hiring analytics." onRetry={reload} /></div>;
  }

  const { applications, jobs, interviews, offers } = data;

  const jobsFootnote = jobs.total === 0
    ? 'Create a job posting to start recruiting'
    : `${jobs.drafts} draft${jobs.drafts === 1 ? '' : 's'} · ${jobs.closed} closed`;

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 stagger">
      <StatCard
        label="Total Applications" icon="bi-people" accent="teal"
        value={applications.total} sparkline={applications.sparkline}
        changePct={applications.change_pct} changeLabel="vs previous 30 days"
        footnote={applications.total === 0 ? 'No applications yet' : `${applications.last30} in the last 30 days`}
      />
      <StatCard
        label="Open Jobs" icon="bi-briefcase" accent="violet"
        value={jobs.open} footnote={jobsFootnote}
      />
      <StatCard
        label="Interviews" icon="bi-mic" accent="gold"
        value={interviews.total} sparkline={interviews.sparkline}
        changePct={interviews.change_pct} changeLabel="vs previous 30 days"
        footnote={interviews.total === 0 ? 'No interviews started yet' : `${interviews.completed} completed · ${interviews.in_progress} in progress`}
      />
      <StatCard
        label="Offers" icon="bi-patch-check" accent="green"
        value={offers.total}
        footnote={offers.total === 0 ? 'No offers extended yet' : `${offers.rate_pct}% of all applications`}
      />
    </div>
  );
}
