import { Link, useNavigate } from 'react-router-dom';
import useApi from '../../hooks/useApi';
import { getRecentApplications } from '../../services/dashboardApi';
import ChartCard from '../ui/ChartCard';
import Avatar from '../ui/Avatar';
import ScorePill from '../ui/ScorePill';
import StatusBadge from '../StatusBadge';
import { timeAgo } from '../../utils/format';

// One clickable row per application -> existing /hr/applications/:id page.
export function CandidateRow({ app, onOpen }) {
  return (
    <li>
      <button type="button" className="list-row w-full text-left" onClick={() => onOpen(app.id)}>
        <Avatar name={app.applicant_name} size={38} />
        <div className="min-w-0 flex-1">
          <div className="font-medium text-[0.92rem] truncate">{app.applicant_name}</div>
          <div className="text-ink-soft text-[0.78rem] truncate">{app.job_title} · {timeAgo(app.created_at)}</div>
        </div>
        <div className="hidden sm:block"><StatusBadge status={app.status} /></div>
        <ScorePill score={app.ai_overall_score} pendingLabel={app.ai_error ? 'Failed' : 'Analyzing…'} />
      </button>
    </li>
  );
}

export default function RecentApplicationsCard({ refreshKey }) {
  const navigate = useNavigate();
  const { data, loading, refreshing, error, reload } = useApi((signal) => getRecentApplications(signal), [refreshKey]);

  return (
    <ChartCard
      title="Recent Applications" subtitle="Newest candidates across your jobs"
      loading={loading} refreshing={refreshing} error={error} onRetry={reload}
      isEmpty={data && data.applications.length === 0}
      empty={{ icon: 'bi-people', title: 'No applications yet', message: 'Start receiving applications to see them here.' }}
      skeletonHeight={280}
      action={<Link to="/hr/applications" className="text-[0.8rem] font-semibold">View all <i className="bi bi-arrow-right"></i></Link>}
    >
      {data && (
        <ul className="list-none m-0 p-0 space-y-0.5">
          {data.applications.map((a) => <CandidateRow key={a.id} app={a} onOpen={(id) => navigate(`/hr/applications/${id}`)} />)}
        </ul>
      )}
    </ChartCard>
  );
}
