import useApi from '../../hooks/useApi';
import useCountUp from '../../hooks/useCountUp';
import { getInterviewPerformance } from '../../services/dashboardApi';
import ChartCard from '../ui/ChartCard';
import ScoreDial from '../ScoreDial';

function Metric({ label, value, hint, children }) {
  return (
    <div className="flex items-center gap-4 rounded-xl bg-paper border border-line p-4">
      {children}
      <div className="min-w-0">
        <div className="eyebrow mb-1">{label}</div>
        <div className="font-display text-3xl font-extrabold leading-none tabular">{value}</div>
        {hint && <div className="text-[0.75rem] text-ink-soft mt-1.5">{hint}</div>}
      </div>
    </div>
  );
}

function Animated({ value }) {
  return <>{useCountUp(value)}</>;
}

export default function InterviewPerformanceCard({ refreshKey }) {
  const { data, loading, refreshing, error, reload } = useApi((signal) => getInterviewPerformance(signal), [refreshKey]);
  const hasScores = data && data.scored > 0;

  return (
    <ChartCard
      title="Interview Performance" subtitle="AI technical interview results (completed sessions with a finished report)"
      loading={loading} refreshing={refreshing} error={error} onRetry={reload}
      isEmpty={data && data.total === 0}
      empty={{ icon: 'bi-mic', title: 'No interview data yet', message: 'Completed interviews will appear here.' }}
      skeletonHeight={120}
    >
      {data && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Metric
            label="Technical average"
            value={hasScores ? <><Animated value={data.technical_avg} /><span className="text-base text-ink-soft font-semibold">/100</span></> : '-'}
            hint={hasScores ? `across ${data.scored} report${data.scored === 1 ? '' : 's'}` : 'Available once a report is ready'}
          >
            {hasScores && <ScoreDial score={data.technical_avg} size={56} />}
          </Metric>
          <Metric
            label="Communication average"
            value={hasScores ? <><Animated value={data.communication_avg} /><span className="text-base text-ink-soft font-semibold">/100</span></> : '-'}
            hint={hasScores ? `across ${data.scored} report${data.scored === 1 ? '' : 's'}` : 'Available once a report is ready'}
          >
            {hasScores && <ScoreDial score={data.communication_avg} size={56} />}
          </Metric>
          <Metric
            label="Completed interviews"
            value={<Animated value={data.completed} />}
            hint={[data.in_progress && `${data.in_progress} in progress`, data.timed_out && `${data.timed_out} timed out`, data.cancelled && `${data.cancelled} cancelled`].filter(Boolean).join(', ') || `${data.total} total session${data.total === 1 ? '' : 's'}`}
          >
            <span className="w-14 h-14 rounded-full bg-success-soft text-success-ink flex items-center justify-center text-2xl shrink-0"><i className="bi bi-check2-circle"></i></span>
          </Metric>
        </div>
      )}
    </ChartCard>
  );
}
