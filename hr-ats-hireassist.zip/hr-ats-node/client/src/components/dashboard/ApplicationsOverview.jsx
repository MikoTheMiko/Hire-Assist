import { useState } from 'react';
import useApi from '../../hooks/useApi';
import { getApplicationsOverTime } from '../../services/dashboardApi';
import ChartCard from '../ui/ChartCard';
import LineAreaChart from '../charts/LineAreaChart';

const RANGES = [
  { id: '7d', label: '7 days', sub: 'daily, last 7 days' },
  { id: '30d', label: '30 days', sub: 'daily, last 30 days' },
  { id: '6m', label: '6 months', sub: 'monthly, last 6 months' },
];

export default function ApplicationsOverview({ refreshKey }) {
  const [range, setRange] = useState('30d');
  const { data, loading, refreshing, error, reload } = useApi(
    (signal) => getApplicationsOverTime(range, signal), [range, refreshKey]
  );
  const current = RANGES.find((r) => r.id === range);

  return (
    <ChartCard
      title="Applications Overview"
      subtitle={data ? `${data.total} application${data.total === 1 ? '' : 's'} · ${current.sub}` : current.sub}
      loading={loading} refreshing={refreshing} error={error} onRetry={reload}
      isEmpty={data && data.total === 0 && range === '6m'}
      empty={{ icon: 'bi-graph-up', title: 'No applications yet', message: 'Start receiving applications to see your hiring analytics.' }}
      skeletonHeight={300}
      action={
        <div className="segmented" role="group" aria-label="Time range">
          {RANGES.map((r) => (
            <button key={r.id} aria-pressed={range === r.id} onClick={() => setRange(r.id)}>{r.label}</button>
          ))}
        </div>
      }
    >
      {data && data.total === 0 ? (
        <div className="flex flex-col items-center justify-center text-center py-12">
          <p className="font-display font-semibold mb-1">No applications in this period</p>
          <p className="text-ink-soft text-sm mb-0">Try a wider range, or start receiving applications to see trends here.</p>
        </div>
      ) : (
        // key => the line redraws (animates) whenever the range changes
        data && <LineAreaChart key={range} points={data.points} />
      )}
    </ChartCard>
  );
}
