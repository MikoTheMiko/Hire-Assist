import { interviewStatusLabel, statusLabel } from '../utils/format';

const ICONS = {
  submitted: 'bi-send', screened: 'bi-cpu', shortlisted: 'bi-star', interview: 'bi-chat-dots', offer: 'bi-patch-check',
  rejected: 'bi-x-circle', withdrawn: 'bi-box-arrow-left', archived: 'bi-archive',
};

const INTERVIEW_ICONS = {
  not_started: 'bi-circle', in_progress: 'bi-hourglass-split', completed: 'bi-check2-circle', timed_out: 'bi-alarm', cancelled: 'bi-slash-circle',
};

// Application status. Conveyed by icon + text as well as colour.
export default function StatusBadge({ status }) {
  return (
    <span className={`badge-status-${status} uppercase tracking-wide`}>
      <i className={`bi ${ICONS[status] || 'bi-circle'}`} aria-hidden="true"></i>{statusLabel(status)}
    </span>
  );
}

// AI technical interview session status (not_started | in_progress | completed | timed_out | cancelled).
// `detail` appends extra text, e.g. "3/5" for an interview that is still running.
export function InterviewStatusBadge({ status = 'not_started', detail }) {
  return (
    <span className={`badge-interview-${status}`}>
      <i className={`bi ${INTERVIEW_ICONS[status] || 'bi-circle'}`} aria-hidden="true"></i>
      {interviewStatusLabel(status)}{detail ? ` · ${detail}` : ''}
    </span>
  );
}
