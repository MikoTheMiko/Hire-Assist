import { Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

// Wrap any <Route> element with this to require login (and optionally a role).
// Usage: <ProtectedRoute role="hr"><HrDashboard /></ProtectedRoute>
export default function ProtectedRoute({ children, role }) {
  const { user } = useAuth();

  if (!user) return <Navigate to="/login" replace />;
  if (role && user.role !== role) return <Navigate to="/" replace />;

  return children;
}
