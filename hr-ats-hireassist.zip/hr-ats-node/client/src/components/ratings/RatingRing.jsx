import { useEffect, useRef, useState } from 'react';
import { scoreBand } from '../../utils/format';

const DURATION = 1200; // ms — sweep and count-up run together

// Close match for cubic-bezier(0.16, 1, 0.3, 1) (an "expo out"), used for the number count-up
// so it lands at the same moment as the CSS stroke sweep.
const easeOut = (p) => (p >= 1 ? 1 : 1 - Math.pow(2, -10 * p));

const prefersReducedMotion = () =>
  typeof window !== 'undefined' && !!window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;

// Bold, thick, round-capped SVG progress ring. Animates ONCE (0 → score, clockwise from 12 o'clock)
// the first time it scrolls into view; re-renders with a new score animate from the old value.
// Usage: <RatingRing score={82} size={120} label="AI fit score" />
export default function RatingRing({ score, size = 96, label = 'Score', sublabel, thickness, showPercent = false, className = '' }) {
  const valid = score !== null && score !== undefined && !Number.isNaN(Number(score));
  const target = valid ? Math.max(0, Math.min(100, Number(score))) : 0;

  const ref = useRef(null);
  const [visible, setVisible] = useState(false);
  const [progress, setProgress] = useState(0);   // drives stroke offset (CSS-transitioned)
  const [shown, setShown] = useState(0);         // drives the centre number
  const fromRef = useRef(0);

  // Wait until the ring is actually on screen before animating.
  useEffect(() => {
    const el = ref.current;
    if (!el) return undefined;
    if (typeof IntersectionObserver === 'undefined') { setVisible(true); return undefined; }
    const io = new IntersectionObserver((entries) => {
      if (entries.some((e) => e.isIntersecting)) { setVisible(true); io.disconnect(); }
    }, { threshold: 0.25 });
    io.observe(el);
    return () => io.disconnect();
  }, []);

  useEffect(() => {
    if (!visible) return undefined;
    if (prefersReducedMotion()) { setProgress(target); setShown(target); fromRef.current = target; return undefined; }
    const start = fromRef.current;
    const t0 = performance.now();
    let raf;
    setProgress(target); // CSS transition handles the stroke sweep
    const tick = (now) => {
      const p = Math.min(1, (now - t0) / DURATION);
      setShown(Math.round(start + (target - start) * easeOut(p)));
      if (p < 1) raf = requestAnimationFrame(tick); else fromRef.current = target;
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [visible, target]);

  if (!valid) return null;

  const stroke = thickness || Math.max(7, Math.round(size * 0.17)); // 46px → 8, 72px → 12, 96px → 16, 140px → 24
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const band = scoreBand(target);
  const numSize = Math.round(size * (size >= 110 ? 0.3 : 0.32));

  return (
    <div
      ref={ref}
      className={`rating-ring rating-${band} ${className}`}
      style={{ width: size, height: size, maxWidth: '100%' }}
      role="img"
      aria-label={`${label}: ${target} out of 100`}
      title={`${label}: ${target}`}
    >
      <svg viewBox={`0 0 ${size} ${size}`} width="100%" height="100%" aria-hidden="true" focusable="false">
        <circle className="rating-track" cx={size / 2} cy={size / 2} r={r} fill="none" strokeWidth={stroke} />
        <circle
          className="rating-progress"
          cx={size / 2} cy={size / 2} r={r} fill="none"
          strokeWidth={stroke} strokeLinecap="round"
          strokeDasharray={c}
          strokeDashoffset={c * (1 - progress / 100)}
          transform={`rotate(-90 ${size / 2} ${size / 2})`}
        />
      </svg>
      <div className="rating-center" aria-hidden="true">
        <span className="rating-num" style={{ fontSize: numSize }}>{shown}{showPercent && <small>%</small>}</span>
        {sublabel && size >= 96 && <span className="rating-sub">{sublabel}</span>}
      </div>
    </div>
  );
}
