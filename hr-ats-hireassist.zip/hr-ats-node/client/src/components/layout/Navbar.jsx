import { useEffect, useState } from 'react';
import { Link, NavLink, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { useSocket } from '../../context/SocketContext';
import NotificationsBell from '../NotificationsBell';
import Avatar from '../ui/Avatar';
import ThemeToggle from '../ui/ThemeToggle';
import { Logo } from '../ui/Logo';

// Public + applicant top navigation. HR users get the sidebar layout instead.
export default function Navbar() {
  const { user, logout } = useAuth();
  const { connected, unreadMessages } = useSocket();
  const navigate = useNavigate();
  const { pathname } = useLocation();
  const [open, setOpen] = useState(false);

  useEffect(() => { setOpen(false); }, [pathname]);
  useEffect(() => {
    if (!open) return undefined;
    const onKey = (e) => { if (e.key === 'Escape') setOpen(false); };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [open]);

  function handleLogout() {
    logout();
    setOpen(false);
    navigate('/login');
  }

  const links = [
    { to: '/', label: 'Jobs', end: true },
    ...(user?.role === 'applicant' ? [
      { to: '/applications', label: 'My Applications' },
      { to: '/messages', label: 'Messages', badge: unreadMessages },
    ] : []),
    ...(user?.role === 'hr' ? [{ to: '/hr/dashboard', label: 'HR Dashboard' }] : []),
  ];

  return (
    <header className="site-nav">
      <div className="site-nav__inner">
        <Logo to="/" size={32} className="site-nav__brand" />

        <nav className="site-nav__links" aria-label="Primary">
          {links.map((l) => (
            <NavLink key={l.to} to={l.to} end={l.end} className={({ isActive }) => `site-nav__link${isActive ? ' is-active' : ''}`}>
              {l.label}
              {l.badge > 0 && <span className="nav-badge" aria-label={`${l.badge} unread`}>{l.badge > 99 ? '99+' : l.badge}</span>}
            </NavLink>
          ))}
        </nav>

        <div className="site-nav__right">
          <ThemeToggle />
          {user ? (
            <>
              <span className="site-nav__live" role="status" title={connected ? 'Real-time updates connected' : 'Connecting to real-time updates'}>
                <span className={`live-dot ${connected ? '' : 'offline'}`}></span>
                <span className="site-nav__live-text">{connected ? 'Live' : 'Connecting...'}</span>
              </span>
              <NotificationsBell align="right" />
              <span className="site-nav__user">
                <Avatar name={user.name} size={32} />
                <span className="site-nav__name">{user.name}</span>
              </span>
              <button className="btn btn-sm btn-outline-secondary site-nav__logout" onClick={handleLogout}>
                <i className="bi bi-box-arrow-right" aria-hidden="true"></i> Logout
              </button>
            </>
          ) : (
            <>
              <Link to="/login" className="site-nav__link site-nav__signin">Log in</Link>
              <Link to="/register" className="btn btn-sm btn-primary">Sign up</Link>
            </>
          )}
        </div>

        <button
          className="site-nav__toggle"
          onClick={() => setOpen((v) => !v)}
          aria-label={open ? 'Close menu' : 'Open menu'}
          aria-expanded={open}
          aria-controls="mobile-menu"
        >
          <i className={`bi ${open ? 'bi-x-lg' : 'bi-list'}`} aria-hidden="true"></i>
        </button>
      </div>

      {open && (
        <div id="mobile-menu" className="site-nav__mobile">
          {user && (
            <div className="site-nav__mobile-user">
              <Avatar name={user.name} size={36} />
              <div>
                <strong>{user.name}</strong>
                <span>{connected ? 'Live updates on' : 'Connecting...'}</span>
              </div>
              <NotificationsBell align="right" />
            </div>
          )}
          {links.map((l) => (
            <NavLink key={l.to} to={l.to} end={l.end} className={({ isActive }) => `site-nav__mlink${isActive ? ' is-active' : ''}`}>
              {l.label}
              {l.badge > 0 && <span className="nav-badge" aria-label={`${l.badge} unread`}>{l.badge > 99 ? '99+' : l.badge}</span>}
            </NavLink>
          ))}
          <div className="site-nav__mobile-theme"><span>Theme</span><ThemeToggle labels /></div>
          {user ? (
            <button className="btn btn-outline-secondary w-full" onClick={handleLogout}>Logout</button>
          ) : (
            <div className="site-nav__mobile-cta">
              <Link to="/login" className="btn btn-outline-secondary">Log in</Link>
              <Link to="/register" className="btn btn-primary">Sign up</Link>
            </div>
          )}
        </div>
      )}
    </header>
  );
}
