import { Outlet, useLocation } from 'react-router-dom';
import Navbar from './Navbar';
import { Logo } from '../ui/Logo';

// Public + applicant shell (the HR area uses HrLayout). One light theme app-wide.
export default function PublicLayout() {
  const { pathname } = useLocation();
  const isLanding = pathname === '/';

  return (
    <div className="site-shell">
      <a href="#main" className="skip-link">Skip to content</a>
      <Navbar />
      <main id="main" className={isLanding ? 'site-main site-main--landing' : 'site-main site-container'} key={pathname}>
        <Outlet />
      </main>
      <footer className="site-footer">
        <div className="site-container site-footer__inner">
          <Logo size={26} />
          <span>AI-assisted hiring. Resumes screened, interviews scored, applicants kept in the loop.</span>
        </div>
      </footer>
    </div>
  );
}
