import { useState } from 'react';
import { Link } from 'react-router-dom';
import { useSocket } from '../context/SocketContext';
import { useAuth } from '../context/AuthContext';
import { interviewStatusLabel, statusLabel } from '../utils/format';

function describe(n, role) {
  if (n.type === 'message') return `New message: "${n.preview}..."`;
  if (n.type === 'interview_report') return 'Interview assessment report is ready';
  if (n.type === 'interview_status') return `Interview ${interviewStatusLabel(n.status).toLowerCase()}`;
  if (n.status === 'withdrawn' && role === 'hr') return 'An applicant withdrew their application';
  return `Status updated: ${statusLabel(n.status)}`;
}

export default function NotificationsBell({ align = 'right' }) {
  const { user } = useAuth();
  const { notifications, unreadCount, markNotificationsRead } = useSocket();
  const [open, setOpen] = useState(false);

  function toggle() {
    setOpen((v) => {
      const next = !v;
      if (next) markNotificationsRead(); // dismiss the badge, but keep the list itself visible
      return next;
    });
  }

  return (
    <div className="relative">
      <button className="btn-icon relative" onClick={toggle} aria-label="Notifications" aria-expanded={open}>
        <i className="bi bi-bell"></i>
        {unreadCount > 0 && (
          <span className="absolute -top-1.5 -right-1.5 bg-danger text-on-danger font-bold text-[0.62rem] rounded-full min-w-[1.1rem] h-[1.1rem] flex items-center justify-center px-1 leading-none">
            {unreadCount}
          </span>
        )}
      </button>
      {open && (
        <div className={`absolute ${align === 'right' ? 'right-0' : 'left-0'} mt-2 w-[300px] max-w-[85vw] bg-surface border border-line text-ink rounded-2xl shadow-pop py-1 z-50 animate-pop-in`}>
          {notifications.length === 0 ? (
            <div className="text-sm text-ink-soft p-3">No notifications yet</div>
          ) : (
            notifications.map((n, i) => (
              <Link
                key={i}
                to={user.role === 'hr' ? `/hr/applications/${n.applicationId}` : `/applications/${n.applicationId}`}
                className="block text-sm p-2.5 border-b border-line last:border-b-0 text-ink hover:bg-raised"
                onClick={() => setOpen(false)}
              >
                {describe(n, user.role)}
              </Link>
            ))
          )}
        </div>
      )}
    </div>
  );
}
