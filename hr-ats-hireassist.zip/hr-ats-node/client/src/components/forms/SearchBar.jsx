import { useRef } from 'react';

// Large search field for the public job board: icon, clear button, Escape-to-clear, focus ring.
// Controlled by the parent, which debounces before calling the API.
export default function SearchBar({ value, onChange, placeholder = 'Search jobs…', label, onSubmit, busy = false, autoFocus = false }) {
  const inputRef = useRef(null);
  return (
    <form
      className="searchbar"
      role="search"
      onSubmit={(e) => { e.preventDefault(); onSubmit?.(value); }}
    >
      <i className="bi bi-search searchbar__icon" aria-hidden="true"></i>
      <input
        ref={inputRef}
        type="search"
        className="searchbar__input"
        value={value}
        placeholder={placeholder}
        aria-label={label || placeholder}
        autoFocus={autoFocus}
        onChange={(e) => onChange(e.target.value)}
        onKeyDown={(e) => { if (e.key === 'Escape' && value) onChange(''); }}
      />
      {busy && <span className="searchbar__spinner" aria-hidden="true"></span>}
      {value && (
        <button type="button" className="searchbar__clear" aria-label="Clear search" onClick={() => { onChange(''); inputRef.current?.focus(); }}>
          <i className="bi bi-x-lg" aria-hidden="true"></i>
        </button>
      )}
      <button type="submit" className="btn btn-primary searchbar__go">Search</button>
    </form>
  );
}
