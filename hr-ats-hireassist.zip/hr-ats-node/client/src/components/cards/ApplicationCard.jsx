import { Link } from 'react-router-dom';
import RatingRing from '../ratings/RatingRing';
import StatusBadge from '../StatusBadge';
import ProgressBar from '../ui/ProgressBar';
import { formatExpectedSalary, INACTIVE_STATUSES, STATUSES } from '../../utils/format';

const INTERVIEW_LABEL = {
  in_progress: { icon: 'bi-hourglass-split', text: 'Interview in progress' },
  completed: { icon: 'bi-check2-circle', text: 'Interview completed' },
  timed_out: { icon: 'bi-alarm', text: 'Interview timed out' },
  cancelled: { icon: 'bi-slash-circle', text: 'Interview cancelled' },
};

// Pipeline position (rejected is off the happy path, so it shows a full-width neutral bar).
function pipelinePct(status) {
  if (status === 'rejected' || status === 'withdrawn') return 100;
  const i = STATUSES.indexOf(status);
  return Math.round(((i + 1) / (STATUSES.length - 1)) * 100);
}

export default function ApplicationCard({ app }) {
  const iv = INTERVIEW_LABEL[app.interview_status];
  const canInterview = app.ai_overall_score !== null && app.status !== 'rejected' && !INACTIVE_STATUSES.includes(app.status);
  const expected = formatExpectedSalary(app.expected_salary, app.expected_salary_type);

  return (
    <article className="app-card">
      <div className="app-card__main">
        <div className="app-card__head">
          <h3 className="app-card__title"><Link to={`/applications/${app.id}`}>{app.job_title}</Link></h3>
          <p className="app-card__meta">
            {app.department || 'General'} · Applied {new Date(app.created_at).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' })}
            {expected && <> · Expected {expected}</>}
          </p>
        </div>

        <div className="app-card__badges">
          <StatusBadge status={app.status} />
          {app.ai_overall_score !== null
            ? <span className="app-chip"><i className="bi bi-cpu" aria-hidden="true"></i>Screened</span>
            : app.ai_error
              ? <span className="app-chip app-chip--alert"><i className="bi bi-exclamation-triangle" aria-hidden="true"></i>Screening failed</span>
              : <span className="app-chip"><i className="bi bi-cpu" aria-hidden="true"></i>Screening in progress...</span>}
          {iv
            ? <span className="app-chip"><i className={`bi ${iv.icon}`} aria-hidden="true"></i>{iv.text}</span>
            : canInterview && <span className="app-chip app-chip--cta"><i className="bi bi-mic" aria-hidden="true"></i>Interview available</span>}
          {app.unread_count > 0 && <span className="app-chip app-chip--alert"><i className="bi bi-chat-left-text" aria-hidden="true"></i>{app.unread_count} new message{app.unread_count > 1 ? 's' : ''}</span>}
        </div>

        <ProgressBar value={pipelinePct(app.status)} label={`Application progress: ${app.status}`} className={app.status === 'rejected' || app.status === 'withdrawn' ? 'pbar--muted' : ''} />
      </div>

      <div className="app-card__side">
        {app.ai_overall_score !== null && <RatingRing score={app.ai_overall_score} size={84} label="AI fit score" />}
        <Link to={`/applications/${app.id}`} className="btn btn-outline-primary">View details</Link>
      </div>
    </article>
  );
}
