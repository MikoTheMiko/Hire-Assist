import RatingRing from '../ratings/RatingRing';

// One quiet, static product preview for the landing hero. It shows what the platform produces.
// The figures are a labelled EXAMPLE, not applicant data. Deliberately a single card with no motion,
// so the headline, description and call to action stay the focus of the page.
export default function HeroPreview() {
  return (
    <div className="hero-preview" aria-hidden="true">
      <div className="hp-card">
        <div className="hp-tag">Example AI screening</div>
        <div className="hp-main__row">
          <RatingRing score={92} size={96} label="Example match score" sublabel="Match" />
          <div className="hp-main__text">
            <strong>Resume to role match</strong>
            <span>Skills, experience and education weighed against the job.</span>
          </div>
        </div>
        <div className="hp-skills">
          {['React', 'Node.js', 'SQL', 'REST APIs'].map((s) => <span key={s}><i className="bi bi-check2"></i>{s}</span>)}
          <span className="miss"><i className="bi bi-dash"></i>Docker</span>
        </div>
        <div className="hp-steps" role="presentation">
          {['Submitted', 'Screened', 'Interview', 'Offer'].map((s, i) => (
            <div key={s} className={`hp-step${i < 3 ? ' done' : ''}`}><i></i><span>{s}</span></div>
          ))}
        </div>
      </div>
    </div>
  );
}
