import { Link } from 'react-router-dom';
import { formatSalaryRange, timeAgo } from '../../utils/format';

// Public job card. Every field comes from the jobs table; missing values are simply omitted.
export default function JobCard({ job }) {
  const salary = formatSalaryRange(job.salary_min, job.salary_max, job.salary_type);
  const skills = (job.required_skills || '').split(',').map((s) => s.trim()).filter(Boolean).slice(0, 3);
  const excerpt = (job.description || '').replace(/\s+/g, ' ').trim();

  return (
    <article className="job-card">
      <div className="job-card__top">
        <div className="job-card__mark" aria-hidden="true">{(job.department || job.title || '?')[0].toUpperCase()}</div>
        <div className="job-card__head">
          <h3 className="job-card__title"><Link to={`/jobs/${job.id}`}>{job.title}</Link></h3>
          <p className="job-card__org">{job.department || 'General'}{job.posted_by ? ` · ${job.posted_by}` : ''}</p>
        </div>
      </div>

      <ul className="job-card__meta">
        {job.employment_type && <li><i className="bi bi-briefcase" aria-hidden="true"></i>{job.employment_type}</li>}
        {job.seniority_level && <li><i className="bi bi-bar-chart" aria-hidden="true"></i>{job.seniority_level}</li>}
        {job.created_at && <li><i className="bi bi-clock" aria-hidden="true"></i>{timeAgo(job.created_at)}</li>}
      </ul>

      {salary && <p className="job-card__salary">{salary}</p>}

      <p className="job-card__excerpt">{excerpt.slice(0, 130)}{excerpt.length > 130 ? '…' : ''}</p>

      {skills.length > 0 && (
        <div className="job-card__skills">
          {skills.map((s) => <span key={s}>{s}</span>)}
        </div>
      )}

      <Link to={`/jobs/${job.id}`} className="btn btn-outline-primary job-card__cta" aria-label={`View and apply for ${job.title}`}>
        View &amp; apply <i className="bi bi-arrow-right" aria-hidden="true"></i>
      </Link>
    </article>
  );
}
