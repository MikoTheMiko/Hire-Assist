import { useCallback, useState } from 'react';
import { Outlet, useLocation } from 'react-router-dom';
import HrSidebar from './HrSidebar';
import Topbar from './Topbar';

const COLLAPSE_KEY = 'hr.sidebar.collapsed';

// Shell for every /hr/* page: sidebar + top bar + animated page container.
export default function HrLayout() {
  const { pathname } = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [collapsed, setCollapsed] = useState(() => {
    try { return localStorage.getItem(COLLAPSE_KEY) === '1'; } catch { return false; }
  });

  const closeMobile = useCallback(() => setMobileOpen(false), []);
  const toggleCollapsed = useCallback(() => {
    setCollapsed((c) => {
      try { localStorage.setItem(COLLAPSE_KEY, c ? '0' : '1'); } catch { /* storage unavailable */ }
      return !c;
    });
  }, []);

  return (
    <div className="min-h-screen">
      <HrSidebar collapsed={collapsed} onToggleCollapse={toggleCollapsed} mobileOpen={mobileOpen} onCloseMobile={closeMobile} />

      <div className={`transition-[padding] duration-300 ease-out ${collapsed ? 'lg:pl-[76px]' : 'lg:pl-64'}`}>
        <Topbar onOpenMobile={() => setMobileOpen(true)} />
        <main className="max-w-[1500px] mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
          {/* keyed by path so each page fades/slides in on navigation */}
          <div key={pathname} className="page-enter"><Outlet /></div>
        </main>
      </div>
    </div>
  );
}
