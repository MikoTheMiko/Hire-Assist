import { useEffect, useRef, useState } from 'react';
import api from '../api';
import { useAuth } from '../context/AuthContext';
import { useSocket } from '../context/SocketContext';
import { useToast } from '../context/ToastContext';
import { initials } from '../utils/format';

// Drop this into any application's detail page - it handles loading the
// existing thread, joining the live socket room for it, and appending new
// messages the instant they arrive (yours or the other person's) with no
// refresh and no polling.
export default function ChatThread({ applicationId, embedded = false }) {
  const { user } = useAuth();
  const { socket, connected, refreshUnreadMessages, setActiveThread } = useSocket();
  const toast = useToast();
  const [messages, setMessages] = useState([]);
  const [draft, setDraft] = useState('');
  const [sending, setSending] = useState(false);
  const bottomRef = useRef(null);

  // Load the existing thread once (the server marks incoming messages as read), then refresh the unread badge
  useEffect(() => {
    api.get(`/messages/${applicationId}`).then((res) => { setMessages(res.data); refreshUnreadMessages(); });
  }, [applicationId, refreshUnreadMessages]);

  // Tell the socket layer which thread is on screen so its messages don't count as unread or pop a toast
  useEffect(() => setActiveThread(applicationId), [applicationId, setActiveThread]);

  // Join the room for this application so the server knows to push new
  // messages here, and listen for them.
  useEffect(() => {
    if (!socket) return;

    socket.emit('application:join', applicationId);

    function handleNewMessage(message) {
      if (message.application_id === Number(applicationId)) {
        setMessages((prev) => [...prev, message]);
        // Someone else's message arriving while the thread is open is read straight away
        if (message.sender_id !== user.id) api.post(`/messages/${applicationId}/read`).then(refreshUnreadMessages).catch(() => {});
      }
    }

    socket.on('message:new', handleNewMessage);

    return () => {
      socket.emit('application:leave', applicationId);
      socket.off('message:new', handleNewMessage);
    };
  }, [socket, applicationId, user.id, refreshUnreadMessages]);

  // Auto-scroll to the latest message
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  async function handleSend(e) {
    e?.preventDefault();
    if (!draft.trim() || sending) return;
    setSending(true);
    try {
      // We don't need to manually add this to `messages` - the server
      // broadcasts it back to us over the socket (handleNewMessage above
      // catches it), which keeps a single source of truth.
      await api.post(`/messages/${applicationId}`, { body: draft.trim() });
      setDraft('');
      toast.success('Message Sent', { duration: 2000 });
    } catch (err) {
      toast.error('Message not sent', { description: err.response?.data?.error || 'Please try again.' });
    } finally {
      setSending(false);
    }
  }

  const time = (d) => new Date(d).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
  const day = (d) => new Date(d).toLocaleDateString(undefined, { weekday: 'short', month: 'short', day: 'numeric' });

  return (
    <div className={embedded ? 'flex flex-col h-full min-h-0' : 'card'}>
      <div className={embedded ? 'flex flex-col h-full min-h-0' : 'p-4 sm:p-5'}>
        {!embedded && (
          <div className="flex items-center justify-between mb-3">
            <h5 className="card-title mb-0"><i className="bi bi-chat-dots mr-1.5 text-teal"></i> Messages</h5>
            <span className="text-xs text-ink-soft flex items-center"><span className={`live-dot ${connected ? '' : 'offline'}`}></span>{connected ? 'Live' : 'Offline'}</span>
          </div>
        )}

        <div className={`overflow-y-auto ${embedded ? 'flex-1 min-h-0 px-4 sm:px-5 py-4' : 'mb-3 max-h-[420px] rounded-xl bg-paper border border-line p-4'}`}>
          {messages.length === 0 && (
            <div className="h-full flex flex-col items-center justify-center text-center py-10">
              <div className="w-11 h-11 rounded-2xl bg-raised border border-line text-ink-soft flex items-center justify-center text-lg mb-2"><i className="bi bi-chat-dots"></i></div>
              <p className="text-ink-soft text-sm mb-0">No messages yet. Say hello!</p>
            </div>
          )}
          {messages.map((m, i) => {
            const isMe = m.sender_id === user.id;
            const newDay = i === 0 || day(messages[i - 1].created_at) !== day(m.created_at);
            return (
              <div key={m.id}>
                {newDay && <div className="text-center text-[0.68rem] uppercase tracking-wider text-ink-soft/80 my-3">{day(m.created_at)}</div>}
                <div className={`flex items-end gap-2 ${isMe ? 'flex-row-reverse' : ''}`}>
                  {!isMe && (
                    <span className="avatar w-7 h-7 text-[0.62rem] bg-violet/15 text-violet mb-2" aria-hidden="true">{initials(m.sender_name)}</span>
                  )}
                  <div className={`chat-bubble ${isMe ? 'me' : 'them'}`}>
                    {!isMe && <div className="text-[0.72rem] font-semibold text-ink-soft mb-0.5">{m.sender_name}</div>}
                    <div className="whitespace-pre-wrap break-words">{m.body}</div>
                    <div className={`text-[0.66rem] mt-1 ${isMe ? 'text-on-teal/60' : 'text-ink-soft'}`}>{time(m.created_at)}</div>
                  </div>
                </div>
              </div>
            );
          })}
          <div ref={bottomRef} />
        </div>

        <form onSubmit={handleSend} className={`flex items-end gap-2 ${embedded ? 'px-4 sm:px-5 py-3 border-t border-line' : ''}`}>
          <textarea
            className="input flex-1 resize-none"
            rows={embedded ? 1 : 2}
            placeholder="Type a message..."
            aria-label="Message"
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) handleSend(e); }}
            required
          />
          <button className="btn btn-primary !h-[42px]" type="submit" disabled={sending || !draft.trim()} aria-label="Send message">
            <i className="bi bi-send-fill"></i>
          </button>
        </form>
      </div>
    </div>
  );
}
