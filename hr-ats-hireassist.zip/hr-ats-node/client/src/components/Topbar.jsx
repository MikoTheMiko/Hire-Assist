import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useSocket } from '../context/SocketContext';
import NotificationsBell from './NotificationsBell';
import Avatar from './ui/Avatar';
import ThemeToggle from './ui/ThemeToggle';
import { Logo } from './ui/Logo';

const TITLES = [
  ['/hr/dashboard', 'Dashboard'], ['/hr/post-job', 'New job'], ['/hr/jobs', 'Jobs'],
  ['/hr/applications', 'Applications'], ['/hr/interviews', 'Interviews'], ['/hr/messages', 'Messages'],
];

// Sticky top bar: mobile menu toggle, current section, live connection status,
// notifications, and the signed-in user.
export default function Topbar({ onOpenMobile }) {
  const { user, logout } = useAuth();
  const { connected } = useSocket();
  const { pathname } = useLocation();
  const navigate = useNavigate();
  const section = TITLES.find(([p]) => pathname.startsWith(p))?.[1] || '';

  function handleLogout() {
    logout();
    navigate('/login');
  }

  return (
    <header className="sticky top-0 z-20 h-[68px] flex items-center gap-3 px-4 sm:px-6 lg:px-8 bg-paper/75 backdrop-blur-xl border-b border-line/70">
      <button className="btn-icon lg:hidden" onClick={onOpenMobile} aria-label="Open menu">
        <i className="bi bi-list text-xl"></i>
      </button>
      <Logo to="/hr/dashboard" size={28} showWordmark={false} className="lg:hidden" />

      <div className="hidden lg:flex items-center gap-2 text-sm">
        <span className="text-ink-soft">HR</span>
        <i className="bi bi-chevron-right text-[0.65rem] text-ink-soft/60"></i>
        <span className="font-semibold">{section}</span>
      </div>

      <div className="ml-auto flex items-center gap-2 sm:gap-3">
        <span className="hidden sm:flex items-center text-xs text-ink-soft" role="status">
          <span className={`live-dot ${connected ? '' : 'offline'}`}></span>
          {connected ? 'Live' : 'Connecting...'}
        </span>
        <ThemeToggle className="hidden sm:inline-flex" />
        <NotificationsBell align="right" />
        <div className="flex items-center gap-2.5 pl-2 sm:pl-3 border-l border-line">
          <Avatar name={user?.name} size={34} />
          <div className="hidden md:block leading-tight max-w-[140px]">
            <div className="text-[0.85rem] font-semibold truncate">{user?.name}</div>
            <div className="text-[0.7rem] text-ink-soft">HR</div>
          </div>
          <button className="btn-icon" onClick={handleLogout} aria-label="Log out" title="Log out">
            <i className="bi bi-box-arrow-right"></i>
          </button>
        </div>
      </div>
    </header>
  );
}
