import { useEffect } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import api from '../../api';
import useApi from '../../hooks/useApi';
import { useSocket } from '../../context/SocketContext';
import { timeAgo } from '../../utils/format';
import Avatar from '../ui/Avatar';
import Skeleton from '../ui/Skeleton';
import EmptyState from '../ui/EmptyState';
import ErrorState from '../ui/ErrorState';
import ChatThread from '../ChatThread';
import StatusBadge from '../StatusBadge';

// Two-pane inbox shared by the HR and applicant Messages pages: conversation list on the left, the
// existing live ChatThread for the selected application on the right. Threads are per-application,
// exactly as the backend models them. The role-specific parts are passed in:
//   listPath        endpoint returning the conversations (HR or applicant flavour, both already scoped by the API)
//   applicationPath builds the "View application" link
//   emptyList       copy for the empty conversation list
//   height          Tailwind height classes so the card fits under the role's own header
export default function MessagesInbox({ listPath, applicationPath, emptyList, height = 'h-[calc(100vh-220px)] min-h-[520px]', titleFor, subtitleFor }) {
  const { socket, refreshUnreadMessages } = useSocket();
  const [params, setParams] = useSearchParams();
  const selectedId = params.get('app');

  const { data: conversations, loading, error, reload, setData } = useApi(
    (signal) => api.get(listPath, { signal }).then((r) => r.data), [listPath]
  );

  // New message notifications (delivered to the user's personal room) refresh the list
  useEffect(() => {
    if (!socket) return undefined;
    const onNotification = (n) => { if (n?.type === 'message') reload(); };
    socket.on('notification', onNotification);
    return () => socket.off('notification', onNotification);
  }, [socket, reload]);

  const selected = conversations?.find((c) => String(c.application_id) === selectedId);

  function select(c) {
    setParams({ app: String(c.application_id) });
    // opening the thread marks incoming messages read on the server; mirror that locally
    setData((prev) => prev && prev.map((x) => (x.application_id === c.application_id ? { ...x, unread_count: 0 } : x)));
    setTimeout(refreshUnreadMessages, 400);
  }

  if (error) return <div className="card"><ErrorState message="Unable to load conversations." onRetry={reload} /></div>;

  return (
    <div className={`card overflow-hidden grid grid-cols-1 lg:grid-cols-[340px_1fr] ${height}`}>
      {/* Conversation list (hidden on mobile while a thread is open) */}
      <div className={`border-r border-line flex-col min-h-0 ${selected ? 'hidden lg:flex' : 'flex'}`}>
        <div className="px-5 py-4 border-b border-line eyebrow">Conversations</div>
        <div className="flex-1 overflow-y-auto">
          {loading && <div className="p-4 space-y-3">{[0, 1, 2, 3].map((i) => <Skeleton key={i} className="h-16 w-full" />)}</div>}
          {!loading && conversations?.length === 0 && <EmptyState compact {...emptyList} />}
          {conversations?.map((c) => {
            const active = String(c.application_id) === selectedId;
            const title = titleFor(c);
            return (
              <button key={c.application_id} onClick={() => select(c)} aria-current={active ? 'true' : undefined}
                      className={`w-full text-left flex items-start gap-3 px-5 py-3.5 border-b border-line/60 transition-colors ${active ? 'bg-teal-50' : 'hover:bg-raised/60'}`}>
                <Avatar name={title} size={40} />
                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between gap-2">
                    <span className={`truncate text-[0.9rem] ${c.unread_count ? 'font-bold' : 'font-semibold'}`}>{title}</span>
                    {c.last_at && <span className="text-[0.68rem] text-ink-soft shrink-0">{timeAgo(c.last_at)}</span>}
                  </div>
                  <div className="text-[0.72rem] text-ink-soft truncate">{subtitleFor(c)}</div>
                  <div className="flex items-center justify-between gap-2 mt-0.5">
                    <span className={`text-[0.8rem] truncate ${c.unread_count ? 'text-ink' : 'text-ink-soft'}`}>{c.last_body || 'No messages yet'}</span>
                    {c.unread_count > 0 && <span className="badge bg-teal text-on-teal shrink-0">{c.unread_count}</span>}
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Thread */}
      <div className={`min-h-0 flex-col ${selected ? 'flex' : 'hidden lg:flex'}`}>
        {selected ? (
          <>
            <div className="flex items-center gap-3 px-4 sm:px-5 py-3.5 border-b border-line">
              <button className="btn-icon lg:hidden" onClick={() => setParams({})} aria-label="Back to conversations"><i className="bi bi-arrow-left"></i></button>
              <Avatar name={titleFor(selected)} size={38} />
              <div className="min-w-0 flex-1">
                <div className="font-semibold truncate">{titleFor(selected)}</div>
                <div className="text-xs text-ink-soft truncate">{subtitleFor(selected)}</div>
              </div>
              <div className="hidden sm:block"><StatusBadge status={selected.status} /></div>
              <Link to={applicationPath(selected.application_id)} className="btn btn-sm btn-outline-secondary">View application</Link>
            </div>
            <div className="flex-1 min-h-0"><ChatThread key={selected.application_id} applicationId={selected.application_id} embedded /></div>
          </>
        ) : (
          <EmptyState icon="bi-chat-square-text" title="Select a conversation" message="Choose a conversation on the left to read and reply." />
        )}
      </div>
    </div>
  );
}
