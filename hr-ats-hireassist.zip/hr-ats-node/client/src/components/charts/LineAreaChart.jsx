import { useId, useMemo, useState } from 'react';
import useElementWidth from '../../hooks/useElementWidth';

// Smooth area/line chart with hover tooltip. Data: [{ label, count }].
// Drawn as plain SVG at the container's real pixel width (no chart dependency).
const M = { top: 14, right: 14, bottom: 28, left: 34 };

// Monotone cubic interpolation: smooth curve that never overshoots the data
// (so a run of zeros can't dip below the axis).
function smoothPath(pts) {
  if (pts.length < 2) return '';
  const n = pts.length;
  const dx = [], dy = [], m = [];
  for (let i = 0; i < n - 1; i++) { dx[i] = pts[i + 1][0] - pts[i][0]; dy[i] = pts[i + 1][1] - pts[i][1]; m[i] = dy[i] / dx[i]; }
  const t = [m[0]];
  for (let i = 1; i < n - 1; i++) t[i] = m[i - 1] * m[i] <= 0 ? 0 : (m[i - 1] + m[i]) / 2;
  t[n - 1] = m[n - 2];
  for (let i = 0; i < n - 1; i++) {
    if (m[i] === 0) { t[i] = 0; t[i + 1] = 0; continue; }
    const a = t[i] / m[i], b = t[i + 1] / m[i], s = a * a + b * b;
    if (s > 9) { const k = 3 / Math.sqrt(s); t[i] = k * a * m[i]; t[i + 1] = k * b * m[i]; }
  }
  let d = `M${pts[0][0].toFixed(1)},${pts[0][1].toFixed(1)}`;
  for (let i = 0; i < n - 1; i++) {
    const h = dx[i] / 3;
    d += ` C${(pts[i][0] + h).toFixed(1)},${(pts[i][1] + t[i] * h).toFixed(1)} ${(pts[i + 1][0] - h).toFixed(1)},${(pts[i + 1][1] - t[i + 1] * h).toFixed(1)} ${pts[i + 1][0].toFixed(1)},${pts[i + 1][1].toFixed(1)}`;
  }
  return d;
}

export default function LineAreaChart({ points = [], height = 280, color = '#6366F1', unit = 'application' }) {
  const [ref, width] = useElementWidth(640);
  const [hover, setHover] = useState(null);
  const gid = `area-${useId().replace(/:/g, '')}`;

  const geo = useMemo(() => {
    const max = Math.max(...points.map((p) => p.count), 0);
    const step = Math.max(1, Math.ceil(max / 4)); // integer y-ticks only (counts are whole numbers)
    const yMax = step * 4;
    const innerW = Math.max(10, width - M.left - M.right);
    const innerH = height - M.top - M.bottom;
    const x = (i) => M.left + (points.length === 1 ? innerW / 2 : (i / (points.length - 1)) * innerW);
    const y = (v) => M.top + innerH - (v / yMax) * innerH;
    const pts = points.map((p, i) => [x(i), y(p.count)]);
    const ticks = [0, 1, 2, 3, 4].map((k) => ({ v: k * step, y: y(k * step) }));
    const every = Math.max(1, Math.ceil(points.length / Math.max(2, Math.floor(innerW / 70))));
    return { pts, ticks, innerH, x, every };
  }, [points, width, height]);

  const line = smoothPath(geo.pts);
  const baseY = M.top + geo.innerH;
  const area = line && `${line} L${geo.pts[geo.pts.length - 1][0].toFixed(1)},${baseY} L${geo.pts[0][0].toFixed(1)},${baseY} Z`;

  function onMove(e) {
    const rect = e.currentTarget.getBoundingClientRect();
    const px = e.clientX - rect.left;
    let best = 0, bestD = Infinity;
    geo.pts.forEach(([x], i) => { const d = Math.abs(x - px); if (d < bestD) { bestD = d; best = i; } });
    setHover(best);
  }

  const hp = hover !== null ? points[hover] : null;
  const hx = hover !== null ? geo.pts[hover][0] : 0;
  const hy = hover !== null ? geo.pts[hover][1] : 0;
  const tipLeft = Math.min(Math.max(hx, 60), width - 60);

  return (
    <div ref={ref} className="relative w-full select-none" style={{ height }}>
      <svg
        width={width} height={height} role="img"
        aria-label={`Line chart of ${unit}s over time. ${points.map((p) => `${p.label}: ${p.count}`).join(', ')}`}
        onPointerMove={onMove} onPointerLeave={() => setHover(null)}
      >
        <defs>
          <linearGradient id={gid} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={color} stopOpacity="0.32" />
            <stop offset="100%" stopColor={color} stopOpacity="0" />
          </linearGradient>
        </defs>

        {geo.ticks.map((t) => (
          <g key={t.v}>
            <line x1={M.left} x2={width - M.right} y1={t.y} y2={t.y} stroke="#E2E8F0" strokeDasharray={t.v === 0 ? '0' : '3 5'} />
            <text x={M.left - 8} y={t.y + 4} textAnchor="end" fontSize="11" fill="#64748B" className="tabular">{t.v}</text>
          </g>
        ))}

        {points.map((p, i) => i % geo.every === 0 && (
          <text key={p.key || i} x={geo.x(i)} y={height - 8} textAnchor="middle" fontSize="11" fill="#64748B">{p.label}</text>
        ))}

        {area && <path d={area} fill={`url(#${gid})`} className="chart-area" />}
        {line && <path d={line} fill="none" stroke={color} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" pathLength="1" className="chart-line" />}

        {hp && (
          <g pointerEvents="none">
            <line x1={hx} x2={hx} y1={M.top} y2={baseY} stroke={color} strokeOpacity="0.35" strokeDasharray="3 4" />
            <circle cx={hx} cy={hy} r="9" fill={color} fillOpacity="0.18" />
            <circle cx={hx} cy={hy} r="4.5" fill="#FFFFFF" stroke={color} strokeWidth="2.5" />
          </g>
        )}
      </svg>

      {hp && (
        <div
          className="absolute pointer-events-none -translate-x-1/2 -translate-y-full px-3 py-2 rounded-xl bg-raised border border-line shadow-pop text-center whitespace-nowrap z-10"
          style={{ left: tipLeft, top: Math.max(hy - 14, 40) }}
        >
          <div className="font-display font-bold text-base leading-none tabular">{hp.count}</div>
          <div className="text-[0.7rem] text-ink-soft mt-1">{hp.label}</div>
        </div>
      )}
    </div>
  );
}
