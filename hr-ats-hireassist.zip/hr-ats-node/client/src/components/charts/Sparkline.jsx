import { useId } from 'react';

// Tiny inline trend line for KPI cards. Purely presentational: it draws whatever
// series it is given (real daily counts from the API).
export default function Sparkline({ values = [], color = '#6366F1', width = 90, height = 36 }) {
  const gid = `spark-${useId().replace(/:/g, '')}`;
  if (values.length < 2) return null;

  const max = Math.max(...values, 1);
  const pad = 3;
  const stepX = (width - pad * 2) / (values.length - 1);
  const pts = values.map((v, i) => [pad + i * stepX, height - pad - (v / max) * (height - pad * 2)]);
  const line = pts.map(([x, y], i) => `${i ? 'L' : 'M'}${x.toFixed(1)},${y.toFixed(1)}`).join(' ');
  const area = `${line} L${pts[pts.length - 1][0].toFixed(1)},${height} L${pts[0][0].toFixed(1)},${height} Z`;
  const flat = values.every((v) => v === 0);

  return (
    <svg width={width} height={height} viewBox={`0 0 ${width} ${height}`} aria-hidden="true" className="shrink-0">
      <defs>
        <linearGradient id={gid} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.28" />
          <stop offset="100%" stopColor={color} stopOpacity="0" />
        </linearGradient>
      </defs>
      {!flat && <path d={area} fill={`url(#${gid})`} className="chart-area" />}
      <path d={line} fill="none" stroke={color} strokeOpacity={flat ? 0.3 : 1} strokeWidth="1.75"
            strokeLinecap="round" strokeLinejoin="round" pathLength="1" className="chart-line" />
    </svg>
  );
}
