import { Link } from 'react-router-dom';

// Horizontal bar list: label + track + value. Items: [{ key, label, value, color?, to?, sub? }].
// Pure CSS bars (animated grow-in, staggered) — accessible as a plain list.
export default function HBarChart({ items = [], colorFallback = '#6366F1', labelWidth = 116, valueSuffix = '' }) {
  const max = Math.max(...items.map((i) => i.value), 1);

  return (
    <ul className="space-y-3.5 m-0 p-0 list-none">
      {items.map((item, idx) => {
        const pct = (item.value / max) * 100;
        const color = item.color || colorFallback;
        const row = (
          <div className="flex items-center gap-3 group">
            <div className="shrink-0 text-[0.82rem] text-ink-soft group-hover:text-ink transition-colors truncate" style={{ width: labelWidth }} title={item.label}>
              {item.label}
            </div>
            <div className="flex-1 h-2.5 rounded-full bg-raised overflow-hidden">
              {item.value > 0 && (
                <div
                  className="h-full rounded-full bar-grow"
                  style={{ width: `${Math.max(pct, 2)}%`, background: `linear-gradient(90deg, ${color}, ${color}CC)`, animationDelay: `${idx * 70}ms` }}
                />
              )}
            </div>
            <div className="w-10 shrink-0 text-right font-display font-bold text-[0.95rem] tabular">
              {item.value}{valueSuffix}
            </div>
          </div>
        );
        return (
          <li key={item.key ?? item.label}>
            {item.to ? <Link to={item.to} className="block !text-inherit hover:!text-inherit" aria-label={`${item.label}: ${item.value}`}>{row}</Link> : row}
            {item.sub && <div className="text-[0.7rem] text-ink-soft mt-1" style={{ marginLeft: labelWidth + 12 }}>{item.sub}</div>}
          </li>
        );
      })}
    </ul>
  );
}
