// Vertical column chart for a small fixed set of buckets (e.g. AI score bands).
// Items: [{ key, label, value, color }]
export default function ColumnChart({ items = [], height = 190 }) {
  const max = Math.max(...items.map((i) => i.value), 1);

  return (
    <div className="flex items-end justify-between gap-2 sm:gap-3" style={{ height: height + 44 }}>
      {items.map((item, idx) => {
        const h = (item.value / max) * height;
        return (
          <div key={item.key} className="flex-1 flex flex-col items-center justify-end h-full min-w-0" aria-label={`${item.label}: ${item.value}`}>
            <div className="font-display font-bold text-[0.95rem] mb-1.5 tabular">{item.value}</div>
            <div className="w-full flex items-end justify-center" style={{ height }}>
              <div
                className="w-full max-w-[56px] rounded-t-lg col-grow"
                style={{
                  height: item.value > 0 ? Math.max(h, 6) : 3,
                  background: item.value > 0 ? `linear-gradient(180deg, ${item.color}, ${item.color}66)` : '#E2E8F0',
                  animationDelay: `${idx * 80}ms`,
                }}
              />
            </div>
            <div className="text-[0.72rem] text-ink-soft mt-2 whitespace-nowrap">{item.label}</div>
          </div>
        );
      })}
    </div>
  );
}
