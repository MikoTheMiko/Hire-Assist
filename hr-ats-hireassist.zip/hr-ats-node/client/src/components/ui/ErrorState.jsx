export default function ErrorState({ message = 'Something went wrong.', onRetry, compact = false }) {
  return (
    <div role="alert" className={`flex flex-col items-center justify-center text-center ${compact ? 'py-8' : 'py-12'} px-4`}>
      <div className="w-12 h-12 rounded-2xl bg-danger-soft border border-danger/25 text-danger flex items-center justify-center text-xl mb-3">
        <i className="bi bi-exclamation-triangle"></i>
      </div>
      <div className="font-display font-semibold mb-1">{message}</div>
      {onRetry && (
        <button className="btn btn-sm btn-outline-secondary mt-3" onClick={onRetry}>
          <i className="bi bi-arrow-clockwise"></i> Try again
        </button>
      )}
    </div>
  );
}
