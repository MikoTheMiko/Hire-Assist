// Toolbar search field: icon, clear button, Escape-to-clear. Controlled by the
// parent (which debounces before hitting the API).
export default function SearchInput({ value, onChange, placeholder = 'Search...', label }) {
  return (
    <div className="search-wrap" role="search">
      <i className="bi bi-search lead" aria-hidden="true"></i>
      <input
        type="search"
        className="search-input [&::-webkit-search-cancel-button]:hidden"
        value={value}
        placeholder={placeholder}
        aria-label={label || placeholder}
        onChange={(e) => onChange(e.target.value)}
        onKeyDown={(e) => { if (e.key === 'Escape' && value) onChange(''); }}
      />
      {value && (
        <button type="button" className="search-clear" onClick={() => onChange('')} aria-label="Clear search">
          <i className="bi bi-x-lg text-[0.7rem]"></i>
        </button>
      )}
    </div>
  );
}
