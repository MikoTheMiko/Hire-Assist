import { Link } from 'react-router-dom';

// HireAssist mark: an indigo rounded square with a clean white "H" and a small "assist" spark above the right stem.
export function LogoMark({ size = 32, className = '' }) {
  return (
    <svg className={className} width={size} height={size} viewBox="0 0 32 32" role="img" aria-label="HireAssist" focusable="false">
      <rect width="32" height="32" rx="9" fill="#4F46E5" />
      <path d="M9.5 8.5h3.4v15h-3.4zM19.1 13.5h3.4v10h-3.4zM9.5 14.6h13v3.3h-13z" fill="#fff" />
      <path d="M20.8 4.6l1.05 2.35 2.35 1.05-2.35 1.05-1.05 2.35-1.05-2.35L17.4 8l2.35-1.05z" fill="#C7D2FE" />
    </svg>
  );
}

// Mark + wordmark. `to` makes it a link; omit for a static logo.
export function Logo({ size = 32, to, onClick, showWordmark = true, className = '' }) {
  const inner = (
    <>
      <LogoMark size={size} />
      {showWordmark && <span className="logo-word">Hire<b>Assist</b></span>}
    </>
  );
  if (!to) return <span className={`logo ${className}`}>{inner}</span>;
  return <Link to={to} onClick={onClick} className={`logo ${className}`} aria-label="HireAssist home">{inner}</Link>;
}

export default Logo;
