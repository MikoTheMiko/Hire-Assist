import { useEffect, useId, useMemo, useRef, useState } from 'react';

// Modern replacement for a native <select>: a button that opens a styled popover list.
//   <MenuSelect value={v} onChange={setV} prefix="Status" ariaLabel="Filter by status"
//               options={[{ value: '', label: 'All statuses' }, { value: 'open', label: 'Open', dot: 'bg-success-ink' }]} />
// Keyboard: Enter/Space/Arrow opens, arrows move, Enter picks, Escape closes, Home/End jump.
export default function MenuSelect({
  value, onChange, options, ariaLabel, prefix, placeholder = 'Select', disabled = false,
  block = false, align = 'left', className = '',
}) {
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState(0);
  const rootRef = useRef(null);
  const buttonRef = useRef(null);
  const listRef = useRef(null);
  const listId = useId();

  const selectedIndex = useMemo(() => options.findIndex((o) => o.value === value), [options, value]);
  const selected = options[selectedIndex];

  useEffect(() => {
    if (!open) return undefined;
    const onDocMouseDown = (e) => { if (!rootRef.current?.contains(e.target)) setOpen(false); };
    document.addEventListener('mousedown', onDocMouseDown);
    return () => document.removeEventListener('mousedown', onDocMouseDown);
  }, [open]);

  useEffect(() => {
    if (open) listRef.current?.querySelector(`[data-index="${active}"]`)?.scrollIntoView({ block: 'nearest' });
  }, [open, active]);

  function openMenu() {
    setActive(Math.max(0, selectedIndex));
    setOpen(true);
  }

  function pick(index) {
    const option = options[index];
    if (!option) return;
    setOpen(false);
    buttonRef.current?.focus();
    if (option.value !== value) onChange(option.value);
  }

  function onKeyDown(e) {
    if (disabled) return;
    if (!open) {
      if (['ArrowDown', 'ArrowUp', 'Enter', ' '].includes(e.key)) { e.preventDefault(); openMenu(); }
      return;
    }
    if (e.key === 'Escape') { e.preventDefault(); setOpen(false); }
    else if (e.key === 'ArrowDown') { e.preventDefault(); setActive((i) => Math.min(options.length - 1, i + 1)); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); setActive((i) => Math.max(0, i - 1)); }
    else if (e.key === 'Home') { e.preventDefault(); setActive(0); }
    else if (e.key === 'End') { e.preventDefault(); setActive(options.length - 1); }
    else if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); pick(active); }
    else if (e.key === 'Tab') setOpen(false);
  }

  return (
    <div ref={rootRef} className={`menu ${block ? 'menu--block' : ''} ${className}`} onKeyDown={onKeyDown}>
      <button
        ref={buttonRef} type="button" className="menu-btn" disabled={disabled}
        aria-haspopup="listbox" aria-expanded={open} aria-controls={open ? listId : undefined} aria-label={ariaLabel}
        onClick={() => (open ? setOpen(false) : openMenu())}
      >
        {prefix && <span className="menu-btn__prefix">{prefix}</span>}
        <span className="menu-btn__value">
          {selected?.dot && <span className={`menu-dot ${selected.dot}`} aria-hidden="true"></span>}
          {selected ? selected.label : placeholder}
        </span>
        <i className={`bi bi-chevron-down menu-btn__chevron ${open ? 'is-open' : ''}`} aria-hidden="true"></i>
      </button>

      {open && (
        <ul ref={listRef} id={listId} className={`menu-pop ${align === 'right' ? 'menu-pop--right' : ''}`} role="listbox" aria-label={ariaLabel} tabIndex={-1}>
          {options.map((o, i) => (
            <li
              key={String(o.value)} role="option" data-index={i} aria-selected={o.value === value}
              className={`menu-item ${i === active ? 'is-active' : ''} ${o.value === value ? 'is-selected' : ''}`}
              onMouseEnter={() => setActive(i)} onMouseDown={(e) => e.preventDefault()} onClick={() => pick(i)}
            >
              {o.dot && <span className={`menu-dot ${o.dot}`} aria-hidden="true"></span>}
              <span className="menu-item__label">{o.label}</span>
              {o.value === value && <i className="bi bi-check2 menu-item__check" aria-hidden="true"></i>}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
