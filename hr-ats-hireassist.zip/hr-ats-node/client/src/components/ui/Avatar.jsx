import { initials } from '../../utils/format';

// Deterministic colour per name, so the same candidate always gets the same avatar.
const PALETTE = [
  'bg-teal/15 text-teal', 'bg-violet/15 text-violet', 'bg-gold/15 text-gold',
  'bg-success-ink/15 text-success-ink', 'bg-danger/15 text-danger',
];

export default function Avatar({ name, size = 36 }) {
  const hash = [...(name || '?')].reduce((h, c) => (h * 31 + c.charCodeAt(0)) >>> 0, 7);
  return (
    <span
      className={`avatar ${PALETTE[hash % PALETTE.length]}`}
      style={{ width: size, height: size, fontSize: size * 0.36 }}
      aria-hidden="true"
    >
      {initials(name)}
    </span>
  );
}
