export default function EmptyState({ icon = 'bi-inbox', title, message, action, compact = false }) {
  return (
    <div className={`flex flex-col items-center justify-center text-center ${compact ? 'py-8' : 'py-14'} px-4`}>
      <div className="w-12 h-12 rounded-2xl bg-raised border border-line text-ink-soft flex items-center justify-center text-xl mb-3">
        <i className={`bi ${icon}`}></i>
      </div>
      <div className="font-display font-semibold mb-1">{title}</div>
      {message && <p className="text-ink-soft text-sm max-w-[42ch] mb-0">{message}</p>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}
