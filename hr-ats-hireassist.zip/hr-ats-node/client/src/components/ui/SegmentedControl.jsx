import { useRef } from 'react';

// Button group for a small set of mutually exclusive choices (filters, form options).
//   <SegmentedControl value={v} onChange={setV} ariaLabel="Job status"
//                     options={[{ value: 'open', label: 'Open' }, ...]} />
// `full` stretches the buttons to fill the row (form fields). Arrow keys move the selection.
export default function SegmentedControl({ value, onChange, options, ariaLabel, size = 'md', full = false, disabled = false, className = '' }) {
  const refs = useRef([]);

  function onKeyDown(e, index) {
    const dir = e.key === 'ArrowRight' || e.key === 'ArrowDown' ? 1 : e.key === 'ArrowLeft' || e.key === 'ArrowUp' ? -1 : 0;
    if (!dir) return;
    e.preventDefault();
    const next = (index + dir + options.length) % options.length;
    onChange(options[next].value);
    refs.current[next]?.focus();
  }

  return (
    <div
      className={`seg seg--${size} ${full ? 'seg--full' : ''} ${className}`}
      role="radiogroup" aria-label={ariaLabel}
      style={full ? { gridTemplateColumns: `repeat(${options.length}, minmax(0, 1fr))` } : undefined}
    >
      {options.map((o, i) => {
        const active = o.value === value;
        return (
          <button
            key={String(o.value)} ref={(el) => { refs.current[i] = el; }} type="button" role="radio"
            aria-checked={active} tabIndex={active || (value === undefined && i === 0) ? 0 : -1}
            disabled={disabled} onClick={() => onChange(o.value)} onKeyDown={(e) => onKeyDown(e, i)}
          >
            {o.icon && <i className={`bi ${o.icon}`} aria-hidden="true"></i>}
            {o.label}
          </button>
        );
      })}
    </div>
  );
}
