// Slim animated progress bar. `value` is 0–100.
export default function ProgressBar({ value = 0, label, className = '' }) {
  const v = Math.max(0, Math.min(100, Number(value) || 0));
  return (
    <div className={`pbar ${className}`} role="progressbar" aria-label={label} aria-valuemin={0} aria-valuemax={100} aria-valuenow={v}>
      <div className="pbar__fill" style={{ width: `${v}%` }}></div>
    </div>
  );
}
