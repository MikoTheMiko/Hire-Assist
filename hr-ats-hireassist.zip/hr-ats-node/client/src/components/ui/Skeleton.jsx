// Shimmering placeholder block. Size it with className (h-*, w-*) or style.
export default function Skeleton({ className = '', style }) {
  return <div className={`skeleton ${className}`} style={style} aria-hidden="true" />;
}
