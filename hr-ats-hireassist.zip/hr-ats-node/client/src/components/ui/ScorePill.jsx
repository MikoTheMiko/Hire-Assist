import { scoreBand } from '../../utils/format';

const CLASSES = {
  high: 'bg-success-soft text-success-ink border-success-ink/25',
  mid: 'bg-gold-soft text-gold border-gold/25',
  low: 'bg-danger-soft text-danger border-danger/25',
};

// Compact AI-score chip for lists ("91"). Renders a muted dash when unscored.
export default function ScorePill({ score, pendingLabel = '-' }) {
  if (score === null || score === undefined) {
    return <span className="text-ink-soft text-xs">{pendingLabel}</span>;
  }
  return (
    <span className={`inline-flex items-center justify-center min-w-[2.6rem] px-2 py-1 rounded-lg border font-display font-bold text-sm tabular-nums ${CLASSES[scoreBand(score)]}`}>
      {score}
    </span>
  );
}
