import useCountUp from '../../hooks/useCountUp';
import Sparkline from '../charts/Sparkline';
import Skeleton from './Skeleton';

const ACCENTS = {
  teal: { icon: 'bg-teal/10 text-teal', spark: '#6366F1' },
  violet: { icon: 'bg-violet/15 text-violet', spark: '#8B5CF6' },
  gold: { icon: 'bg-gold/15 text-gold', spark: '#F59E0B' },
  green: { icon: 'bg-success-ink/10 text-success-ink', spark: '#10B981' },
};

// Big-number KPI card:  128 / Total Applications / ↑ 12.4% vs previous 30 days
export function StatCardSkeleton() {
  return (
    <div className="card p-5">
      <div className="flex justify-between mb-5"><Skeleton className="h-4 w-28" /><Skeleton className="h-9 w-9 !rounded-xl" /></div>
      <Skeleton className="h-11 w-24 mb-3" />
      <Skeleton className="h-3.5 w-40" />
    </div>
  );
}

export default function StatCard({ label, value, icon, accent = 'teal', changePct, changeLabel, footnote, sparkline }) {
  const shown = useCountUp(value);
  const a = ACCENTS[accent];
  const hasChange = changePct !== null && changePct !== undefined;
  const trend = !hasChange ? null : changePct > 0 ? 'up' : changePct < 0 ? 'down' : 'flat';

  return (
    <div className="card card-hover p-5 relative overflow-hidden">
      <div className="flex items-start justify-between mb-4">
        <span className="eyebrow">{label}</span>
        <span className={`w-9 h-9 rounded-xl flex items-center justify-center text-[1.05rem] ${a.icon}`}>
          <i className={`bi ${icon}`}></i>
        </span>
      </div>

      <div className="flex items-end justify-between gap-3">
        <div className="min-w-0">
          <div className="kpi-value" aria-label={`${label}: ${value}`}>{shown.toLocaleString()}</div>
          <div className="mt-2.5 text-[0.8rem] flex items-center gap-1.5 flex-wrap min-h-[1.25rem]">
            {trend && (
              <span className={`font-semibold inline-flex items-center gap-0.5 ${trend === 'up' ? 'trend-up' : trend === 'down' ? 'trend-down' : 'trend-flat'}`}>
                <i className={`bi ${trend === 'up' ? 'bi-arrow-up' : trend === 'down' ? 'bi-arrow-down' : 'bi-dash'}`}></i>
                {Math.abs(changePct)}%
              </span>
            )}
            <span className="text-ink-soft">{hasChange ? changeLabel : footnote}</span>
          </div>
        </div>
        {sparkline && <Sparkline values={sparkline} color={a.spark} width={92} height={40} />}
      </div>
    </div>
  );
}
