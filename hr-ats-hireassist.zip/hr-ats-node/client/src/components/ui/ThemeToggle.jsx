import { useTheme } from '../../context/ThemeContext';

const OPTIONS = [
  { value: 'light', label: 'Light', icon: 'bi-sun' },
  { value: 'dark', label: 'Dark', icon: 'bi-moon-stars' },
  { value: 'system', label: 'System', icon: 'bi-display' },
];

// Light / Dark / System selector. Icon-only by default (compact for the top bars),
// `labels` adds the text for roomier spots such as the mobile menu.
export default function ThemeToggle({ labels = false, className = '' }) {
  const { theme, setTheme } = useTheme();
  return (
    <div className={`theme-toggle ${labels ? 'theme-toggle--labels' : ''} ${className}`} role="radiogroup" aria-label="Color theme">
      {OPTIONS.map((o) => (
        <button
          key={o.value} type="button" role="radio" aria-checked={theme === o.value}
          className={theme === o.value ? 'is-active' : ''} title={`${o.label} theme`} aria-label={`${o.label} theme`}
          onClick={() => setTheme(o.value)}
        >
          <i className={`bi ${o.icon}`} aria-hidden="true"></i>
          {labels && <span>{o.label}</span>}
        </button>
      ))}
    </div>
  );
}
