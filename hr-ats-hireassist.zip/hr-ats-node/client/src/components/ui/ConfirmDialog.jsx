import { useEffect, useId, useRef } from 'react';
import { createPortal } from 'react-dom';

// Reusable confirmation modal. Cancel gets focus first (the safe choice), Tab stays inside the dialog,
// Escape or a click on the backdrop cancels, and the page behind does not scroll.
//   <ConfirmDialog open title="..." message="..." confirmLabel="..." cancelLabel="..." tone="danger"
//                  busy={saving} onConfirm={...} onCancel={...} />
export default function ConfirmDialog({
  open, title, message, confirmLabel = 'Confirm', cancelLabel = 'Cancel',
  tone = 'primary', icon, busy = false, onConfirm, onCancel,
}) {
  const panelRef = useRef(null);
  const cancelRef = useRef(null);
  const titleId = useId();
  const messageId = useId();

  useEffect(() => {
    if (!open) return undefined;
    const previouslyFocused = document.activeElement;
    cancelRef.current?.focus();
    const scrollLock = document.body.style.overflow;
    document.body.style.overflow = 'hidden';

    function onKeyDown(e) {
      if (e.key === 'Escape' && !busy) { e.stopPropagation(); onCancel(); return; }
      if (e.key !== 'Tab' || !panelRef.current) return;
      const focusable = panelRef.current.querySelectorAll('button:not([disabled])');
      if (focusable.length === 0) return;
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    }
    document.addEventListener('keydown', onKeyDown);
    return () => {
      document.removeEventListener('keydown', onKeyDown);
      document.body.style.overflow = scrollLock;
      previouslyFocused?.focus?.();
    };
  }, [open, busy, onCancel]);

  if (!open) return null;

  const danger = tone === 'danger';
  return createPortal(
    <div className="dialog-backdrop" onMouseDown={(e) => { if (e.target === e.currentTarget && !busy) onCancel(); }}>
      <div ref={panelRef} className="dialog" role="alertdialog" aria-modal="true" aria-labelledby={titleId} aria-describedby={messageId}>
        <div className={`dialog__icon ${danger ? 'is-danger' : ''}`} aria-hidden="true">
          <i className={`bi ${icon || (danger ? 'bi-exclamation-triangle' : 'bi-question-circle')}`}></i>
        </div>
        <h2 id={titleId} className="dialog__title">{title}</h2>
        <p id={messageId} className="dialog__message">{message}</p>
        <div className="dialog__actions">
          <button ref={cancelRef} type="button" className="btn btn-outline-secondary" onClick={onCancel} disabled={busy}>{cancelLabel}</button>
          <button type="button" className={`btn ${danger ? 'btn-danger' : 'btn-primary'}`} onClick={onConfirm} disabled={busy}>
            {busy && <span className="btn-spinner" aria-hidden="true"></span>}{confirmLabel}
          </button>
        </div>
      </div>
    </div>,
    document.body
  );
}
