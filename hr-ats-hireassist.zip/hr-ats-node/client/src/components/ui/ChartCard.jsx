import Skeleton from './Skeleton';
import ErrorState from './ErrorState';
import EmptyState from './EmptyState';

// Frame for every dashboard visualisation. It owns the loading / error / empty
// states so each chart only has to render the "happy path".
//   isEmpty + empty={{icon,title,message}} -> empty state instead of children
export default function ChartCard({
  title, subtitle, action, loading, error, onRetry, isEmpty, empty,
  refreshing = false, skeletonHeight = 220, className = '', children,
}) {
  return (
    <section className={`card p-5 sm:p-6 flex flex-col ${className}`} aria-busy={loading || refreshing}>
      <div className="flex items-start justify-between gap-3 mb-4">
        <div className="min-w-0">
          <h2 className="text-[1.02rem] font-semibold mb-0.5">{title}</h2>
          {subtitle && <p className="text-ink-soft text-[0.8rem] mb-0">{subtitle}</p>}
        </div>
        {action && <div className="shrink-0">{action}</div>}
      </div>

      <div className={`flex-1 transition-opacity duration-200 ${refreshing ? 'opacity-60' : 'opacity-100'}`}>
        {loading ? (
          <div className="space-y-3" style={{ minHeight: skeletonHeight }}>
            <Skeleton className="h-4 w-1/3" />
            <Skeleton className="w-full" style={{ height: skeletonHeight - 40 }} />
          </div>
        ) : error ? (
          <ErrorState message="Unable to load this data." onRetry={onRetry} compact />
        ) : isEmpty ? (
          <EmptyState compact {...empty} />
        ) : (
          children
        )}
      </div>
    </section>
  );
}
