import RatingRing from './ratings/RatingRing';

// Kept as a thin wrapper so every existing <ScoreDial score size /> call site
// gets the new thick animated ring without any import changes.
export default function ScoreDial({ score, size = 72, label = 'AI fit score' }) {
  return <RatingRing score={score} size={size} label={label} />;
}
