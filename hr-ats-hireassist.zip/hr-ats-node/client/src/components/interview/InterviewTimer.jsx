import { useEffect, useRef, useState } from 'react';
import { formatClock } from '../../utils/format';

export const WARNING_SECONDS = 5 * 60;
export const CRITICAL_SECONDS = 60;

// Countdown for the AI interview. The server owns the deadline: it sends `remainingSeconds` (measured on
// the database clock), and this component counts down locally from that moment using the monotonic
// performance clock, so a wrong or changed device clock cannot stretch the interview. Because the server
// value is re-sent on every load, a page refresh continues from the real remaining time, never restarting.
//
//   <InterviewTimer remainingSeconds={s} totalSeconds={1200} syncKey={session.id} running onExpire={fn} />
//
// `syncKey` should change whenever a fresh server reading arrives. `onExpire` fires once when it hits 00:00.
export default function InterviewTimer({ remainingSeconds, totalSeconds, syncKey, running = true, onExpire, showBar = true }) {
  const deadline = useRef(performance.now() + remainingSeconds * 1000);
  const expiredFired = useRef(false);
  const [left, setLeft] = useState(remainingSeconds);

  // Re-anchor whenever the server gives us a new reading (initial load, refresh, resync).
  useEffect(() => {
    deadline.current = performance.now() + remainingSeconds * 1000;
    expiredFired.current = false;
    setLeft(remainingSeconds);
  }, [syncKey, remainingSeconds]);

  useEffect(() => {
    if (!running) return undefined;
    const tick = () => {
      const seconds = Math.max(0, Math.ceil((deadline.current - performance.now()) / 1000));
      setLeft(seconds);
      if (seconds === 0 && !expiredFired.current) {
        expiredFired.current = true;
        onExpire?.();
      }
    };
    tick();
    const id = setInterval(tick, 250);
    return () => clearInterval(id);
  }, [running, syncKey, onExpire]);

  const level = !running ? 'ended' : left <= CRITICAL_SECONDS ? 'critical' : left <= WARNING_SECONDS ? 'warning' : 'normal';
  const pct = totalSeconds ? Math.min(100, (left / totalSeconds) * 100) : 0;
  const announce = left === WARNING_SECONDS || left === CRITICAL_SECONDS || left === 0; // screen readers: only at key moments

  return (
    <div className="flex flex-col gap-2 min-w-[150px]">
      <div className={`interview-timer interview-timer--${level}`} role="timer" aria-label="Time remaining in the interview">
        <i className={`bi ${level === 'critical' ? 'bi-alarm-fill' : 'bi-stopwatch'} interview-timer__icon`} aria-hidden="true"></i>
        <div>
          <span className="interview-timer__label">{running ? 'Time left' : 'Time up'}</span>
          <span className="interview-timer__time">{formatClock(left)}</span>
        </div>
        <span className="sr-only" aria-live="assertive">{announce ? `${formatClock(left)} remaining` : ''}</span>
      </div>
      {showBar && (
        <div className={`timer-track ${level === 'warning' ? 'is-warning' : level === 'critical' ? 'is-critical' : ''}`} aria-hidden="true">
          <div style={{ width: `${pct}%` }}></div>
        </div>
      )}
    </div>
  );
}
