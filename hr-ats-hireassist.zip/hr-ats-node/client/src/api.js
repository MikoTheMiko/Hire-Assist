import axios from 'axios';

// Where the API lives. By default it is the same host the page was opened from, on port 4000, so it
// works whether you browse to localhost, 127.0.0.1 or a LAN address (a hardcoded "localhost" points
// at the wrong machine - and gives ERR_CONNECTION_REFUSED - as soon as the page is opened from
// another device). For a deployed app set VITE_API_URL (e.g. https://api.example.com) in client/.env.
export const API_ORIGIN = (import.meta.env.VITE_API_URL || `${window.location.protocol}//${window.location.hostname}:4000`).replace(/\/$/, '');

// One shared axios instance. Every request automatically gets the JWT
// attached (once the user logs in) via the interceptor below, so
// individual components never have to think about auth headers.
const api = axios.create({
  baseURL: `${API_ORIGIN}/api`,
});

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

export default api;
