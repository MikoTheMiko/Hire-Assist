import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App.jsx';
import './styles.css';
import './styles/ring.css';
import './styles/nav.css';
import './styles/landing.css';
import './styles/applicant.css';

// This is where React actually attaches to the <div id="root"> in index.html.
// Everything the app renders happens inside <App />.
ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
