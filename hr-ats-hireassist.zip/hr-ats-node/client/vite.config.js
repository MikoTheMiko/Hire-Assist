import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Vite is the dev server + build tool. It compiles JSX and gives you
// instant hot-reload while you edit — save a file, see it update in the
// browser immediately, no manual refresh.
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
  },
});
