// Shared low-level "talk to whichever AI provider is configured" helper.
// Both aiScreening.js (resume screening) and interviewAi.js (live technical
// interview) call through this so there's one place that knows about
// OpenRouter vs Gemini, JSON-mode, and cleaning up messy model output.

const REQUEST_TIMEOUT_MS = Number(process.env.AI_TIMEOUT_MS) || 60000;
const MAX_TOKEN_CEILING = 16000;

export function extractJsonFromText(text) {
  let cleaned = text.trim()
    .replace(/^```(json)?/i, '')
    .replace(/```$/, '')
    .trim();

  const start = cleaned.indexOf('{');
  const end = cleaned.lastIndexOf('}');
  if (start !== -1 && end !== -1 && end > start) {
    return cleaned.slice(start, end + 1);
  }
  return cleaned;
}

// fetch() throws (instead of returning a response) on DNS failures, dropped
// connections and timeouts. Turn those into the same { error, status } shape
// the rest of the code uses, so they can be retried on the other provider
// instead of escaping as an unhandled rejection.
async function safeFetch(url, options, providerLabel) {
  try {
    return { res: await fetch(url, { ...options, signal: AbortSignal.timeout(REQUEST_TIMEOUT_MS) }) };
  } catch (err) {
    const timedOut = err?.name === 'TimeoutError' || err?.name === 'AbortError';
    return {
      error: timedOut
        ? `${providerLabel} did not respond within ${Math.round(REQUEST_TIMEOUT_MS / 1000)}s.`
        : `Could not reach ${providerLabel}: ${err?.cause?.code || err?.message || 'network error'}`,
      status: 503,
    };
  }
}

async function callOpenRouter(prompt, maxTokens) {
  if (!process.env.OPENROUTER_API_KEY || process.env.OPENROUTER_API_KEY === 'your_openrouter_key_here') {
    return { error: 'OpenRouter API key not configured in .env', notConfigured: true };
  }
  if (!process.env.OPENROUTER_MODEL) {
    return { error: 'OPENROUTER_MODEL is not set in .env', notConfigured: true };
  }

  const { res, error, status } = await safeFetch('https://openrouter.ai/api/v1/chat/completions', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${process.env.OPENROUTER_API_KEY}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      model: process.env.OPENROUTER_MODEL,
      messages: [{ role: 'user', content: prompt }],
      temperature: 0.3,
      max_tokens: maxTokens,
      response_format: { type: 'json_object' },
    }),
  }, 'OpenRouter');
  if (error) return { error, status };

  if (!res.ok) {
    const body = await res.text();
    return { error: `OpenRouter API returned HTTP ${res.status}: ${body.slice(0, 500)}`, status: res.status, body };
  }

  const data = await res.json();
  const choice = data.choices?.[0];
  const text = choice?.message?.content;
  if (!text) return { error: 'Unexpected OpenRouter response shape.' };
  return { text, truncated: choice?.finish_reason === 'length' };
}

async function callGemini(prompt, maxTokens) {
  if (!process.env.GEMINI_API_KEY || process.env.GEMINI_API_KEY === 'your_gemini_key_here') {
    return { error: 'Gemini API key not configured in .env', notConfigured: true };
  }
  if (!process.env.GEMINI_MODEL) {
    return { error: 'GEMINI_MODEL is not set in .env', notConfigured: true };
  }

  const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(process.env.GEMINI_MODEL)}:generateContent`;

  const { res, error, status } = await safeFetch(url, {
    method: 'POST',
    // Key goes in a header rather than the URL so it can't leak into logs/error messages.
    headers: { 'Content-Type': 'application/json', 'x-goog-api-key': process.env.GEMINI_API_KEY },
    body: JSON.stringify({
      contents: [{ role: 'user', parts: [{ text: prompt }] }],
      generationConfig: {
        temperature: 0.3,
        maxOutputTokens: maxTokens,
        responseMimeType: 'application/json',
      },
    }),
  }, 'Gemini');
  if (error) return { error, status };

  if (!res.ok) {
    const body = await res.text();
    return { error: `Gemini API returned HTTP ${res.status}: ${body.slice(0, 500)}`, status: res.status, body };
  }

  const data = await res.json();
  const candidate = data.candidates?.[0];
  // Join every text part - a response can be split across several parts.
  const text = (candidate?.content?.parts || []).map((p) => p.text || '').join('');
  if (!text) {
    const reason = candidate?.finishReason || data.promptFeedback?.blockReason;
    return { error: `Unexpected Gemini response shape${reason ? ` (${reason})` : ''}.` };
  }
  return { text, truncated: candidate?.finishReason === 'MAX_TOKENS' };
}

const PROVIDERS = { openrouter: callOpenRouter, gemini: callGemini };

// A wrong/retired model ID comes back as 404, or as a 400 whose body talks
// about the model. The other provider uses a different model setting, so it
// may well work - worth a retry.
function isModelError(result) {
  if (result.status === 404) return true;
  if (result.status === 400) return /model/i.test(result.body || result.error || '') && /(not found|invalid|valid model|not supported|unknown|does not exist|no endpoints)/i.test(result.body || result.error || '');
  return false;
}

// Errors worth retrying against the other provider: the request itself was
// fine, but this provider can't serve it right now - out of credits (402),
// rate limited (429), an outage or timeout (5xx), a rejected API key
// (401/403, each provider has its own key), a model ID that doesn't exist, or
// this provider simply not being configured. A plain 400 (bad request)
// would fail identically on the other provider too, so it is left alone.
function isRetryable(result) {
  const { status } = result;
  return Boolean(result.notConfigured)
    || status === 401 || status === 402 || status === 403 || status === 429
    || (status >= 500 && status < 600)
    || isModelError(result);
}

/**
 * Calls the primary provider (AI_PROVIDER=gemini|openrouter, default
 * openrouter). If it fails with a retryable, provider-side error and the
 * *other* provider has an API key configured, automatically retries once
 * against that other provider before giving up.
 */
export async function callProvider(prompt, maxTokens = 2000) {
  const primaryName = process.env.AI_PROVIDER === 'gemini' ? 'gemini' : 'openrouter';
  const fallbackName = primaryName === 'gemini' ? 'openrouter' : 'gemini';

  const primaryResult = await PROVIDERS[primaryName](prompt, maxTokens);
  if (!primaryResult.error) return primaryResult;
  if (!isRetryable(primaryResult)) return primaryResult;

  const fallbackKeyEnv = fallbackName === 'gemini' ? 'GEMINI_API_KEY' : 'OPENROUTER_API_KEY';
  const fallbackKeyPlaceholder = fallbackName === 'gemini' ? 'your_gemini_key_here' : 'your_openrouter_key_here';
  const fallbackConfigured = process.env[fallbackKeyEnv] && process.env[fallbackKeyEnv] !== fallbackKeyPlaceholder;
  if (!fallbackConfigured) return primaryResult;

  console.warn(`[ai] ${primaryName} failed (${primaryResult.error}) - falling back to ${fallbackName}`);
  const fallbackResult = await PROVIDERS[fallbackName](prompt, maxTokens);
  if (fallbackResult.error) {
    return { error: `${primaryName} failed: ${primaryResult.error} | ${fallbackName} fallback also failed: ${fallbackResult.error}` };
  }
  return { ...fallbackResult, _fallbackUsed: fallbackName };
}

function tryParse(text) {
  try { return JSON.parse(extractJsonFromText(text)); } catch { return null; }
}

/**
 * Calls the provider expecting a JSON object back.
 *  - If the reply was cut off by the token limit (common with "thinking"
 *    models, whose reasoning counts against the limit), retry the SAME prompt
 *    with a bigger limit. Asking the model to "repair" a truncated reply just
 *    produces the same truncated reply.
 *  - Otherwise, one "please fix your JSON" repair attempt.
 */
export async function callProviderForJson(prompt, maxTokens = 2000) {
  let raw = await callProvider(prompt, maxTokens);
  if (raw.error) return raw;

  let parsed = tryParse(raw.text);
  if (parsed) { parsed._raw = raw.text; return parsed; }

  if (raw.truncated && maxTokens < MAX_TOKEN_CEILING) {
    const bigger = Math.min(maxTokens * 2, MAX_TOKEN_CEILING);
    console.warn(`[ai] reply hit the ${maxTokens}-token limit and was cut off - retrying with ${bigger}`);
    const retry = await callProvider(prompt, bigger);
    if (retry.error) return retry;
    parsed = tryParse(retry.text);
    if (parsed) { parsed._raw = retry.text; return parsed; }
    return { error: retry.truncated
      ? 'AI response was cut off by the token limit. Raise AI_SCREENING_MAX_TOKENS.'
      : 'AI response could not be parsed as JSON.', raw: retry.text };
  }

  const repairPrompt = `Your previous response was not valid JSON. Return ONLY the corrected valid JSON object, nothing else:\n\n${raw.text}`;
  const repair = await callProvider(repairPrompt, maxTokens);
  if (repair.error) return repair;
  parsed = tryParse(repair.text);
  if (parsed) { parsed._raw = repair.text; return parsed; }
  return { error: 'AI response could not be parsed as JSON.', raw: repair.text };
}
