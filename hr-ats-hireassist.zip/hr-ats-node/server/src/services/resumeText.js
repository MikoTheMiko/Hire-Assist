import fs from 'fs/promises';
import path from 'path';

// Hard cap on what we keep/send to the AI. A normal resume is 3-10k characters;
// anything beyond this is almost certainly junk and just burns tokens.
export const MAX_RESUME_CHARS = 30000;

function clean(text) {
  return (text || '')
    .replace(/\u0000/g, '')
    .replace(/\r\n/g, '\n')
    .replace(/[ \t]+\n/g, '\n')
    .replace(/\n{3,}/g, '\n\n')
    .trim()
    .slice(0, MAX_RESUME_CHARS);
}

// pdf-parse and mammoth are both solid, dependency-light choices for this.
//
// IMPORTANT: pdf-parse must be imported from 'pdf-parse/lib/pdf-parse.js', not
// from the package root. The root index.js contains a leftover debug block
// (`if (!module.parent) { ... fs.readFileSync('./test/data/05-versions-space.pdf') }`)
// that runs when the package is loaded through ESM `import()`, and throws
// ENOENT because that test file doesn't exist in this project - which made
// every PDF upload fail to parse.
export async function extractResumeText(filePath, originalName) {
  const ext = path.extname(originalName).toLowerCase();

  if (ext === '.txt') {
    return clean(await fs.readFile(filePath, 'utf-8'));
  }

  if (ext === '.pdf') {
    const pdfParse = (await import('pdf-parse/lib/pdf-parse.js')).default;
    const buffer = await fs.readFile(filePath);
    const data = await pdfParse(buffer);
    return clean(data.text);
  }

  if (ext === '.docx') {
    const mammoth = (await import('mammoth')).default;
    const buffer = await fs.readFile(filePath);
    const result = await mammoth.extractRawText({ buffer });
    return clean(result.value);
  }

  return '';
}

export { clean as cleanResumeText };
