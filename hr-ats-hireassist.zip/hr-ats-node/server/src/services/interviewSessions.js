import { pool } from '../db.js';
import { generateAssessmentReport } from './interviewAi.js';
import { emitInterviewStatus, emitInterviewReportReady } from '../socket.js';

// One place for the interview lifecycle so the routes, the application
// withdraw/archive actions and the background sweeper all end sessions the same way.
//
// Statuses: not_started (no row yet) | in_progress | completed | timed_out | cancelled
export const INTERVIEW_DURATION_SECONDS = 20 * 60;

// The database clock decides what "expired" means, so the browser's clock can never
// extend or shorten an interview. remaining_seconds is what the client counts down from.
const SESSION_SELECT = `SELECT s.*,
    GREATEST(0, TIMESTAMPDIFF(SECOND, NOW(), s.expires_at)) AS remaining_seconds,
    (s.expires_at IS NOT NULL AND s.expires_at <= NOW()) AS is_expired
  FROM interview_sessions s`;

export async function loadSession(applicationId) {
  const [rows] = await pool.query(`${SESSION_SELECT} WHERE s.application_id = ?`, [applicationId]);
  return rows[0] || null;
}

export async function loadSessionById(sessionId) {
  const [rows] = await pool.query(`${SESSION_SELECT} WHERE s.id = ?`, [sessionId]);
  return rows[0] || null;
}

// Moves an in-progress session to a terminal status. The `AND status = 'in_progress'`
// guard makes this safe against races (double submit, sweeper vs. applicant, etc.):
// only one caller wins. Returns true if this call ended the session.
export async function finishSession(sessionId, status, reason) {
  const [result] = await pool.query(
    `UPDATE interview_sessions SET status = ?, ended_reason = ?, completed_at = NOW()
     WHERE id = ? AND status = 'in_progress'`,
    [status, reason, sessionId]
  );
  if (result.affectedRows !== 1) return false;

  const [rows] = await pool.query(
    `SELECT s.id AS session_id, s.application_id, s.questions, a.user_id AS applicant_user_id, a.resume_text,
        j.title, j.department, j.seniority_level, j.employment_type, j.description,
        j.required_skills, j.preferred_skills, j.min_years_experience, j.education_requirement,
        j.created_by AS hr_user_id
     FROM interview_sessions s
     JOIN applications a ON a.id = s.application_id
     JOIN jobs j ON j.id = a.job_id
     WHERE s.id = ?`,
    [sessionId]
  );
  const ctx = rows[0];
  if (!ctx) return true;

  emitInterviewStatus({
    applicationId: ctx.application_id, status, reason,
    applicantUserId: ctx.applicant_user_id, hrUserId: ctx.hr_user_id,
  });

  // A report is only generated when the interview was finished or ran out of time,
  // and only when there is at least one real answer to assess.
  if (status === 'completed' || status === 'timed_out') {
    generateReportAsync(ctx, reason).catch((err) =>
      console.error(`Report generation crashed for session ${sessionId}:`, err));
  }
  return true;
}

async function generateReportAsync(ctx, reason) {
  const [answers] = await pool.query(
    'SELECT * FROM interview_answers WHERE session_id = ? AND skipped = 0 ORDER BY question_index ASC',
    [ctx.session_id]
  );
  if (answers.length === 0) return; // nothing to assess, e.g. every question was skipped

  let totalQuestions = null;
  try { totalQuestions = JSON.parse(ctx.questions).length; } catch { /* leave null */ }

  const report = await generateAssessmentReport(ctx, ctx.resume_text, answers, { totalQuestions, endedReason: reason });
  if (report.error) {
    console.error(`Assessment report generation failed for session ${ctx.session_id}:`, report.error);
    return;
  }

  await pool.query(
    `UPDATE interview_sessions SET
      report_technical_score = ?, report_communication_score = ?,
      report_strengths = ?, report_weaknesses = ?, report_recommendation = ?, report_summary = ?
     WHERE id = ?`,
    [
      report.technical_score, report.communication_score,
      JSON.stringify(report.strengths || []), JSON.stringify(report.weaknesses || []),
      report.recommendation || null, report.summary || '',
      ctx.session_id,
    ]
  );
  emitInterviewReportReady({
    applicationId: Number(ctx.application_id), report,
    applicantUserId: ctx.applicant_user_id, hrUserId: ctx.hr_user_id,
  });
}

// If the deadline has passed, ends the session as timed_out and returns the fresh row.
export async function expireIfNeeded(session) {
  if (session && session.status === 'in_progress' && session.is_expired) {
    await finishSession(session.id, 'timed_out', 'time_expired');
    return loadSessionById(session.id);
  }
  return session;
}

// Used when an application is withdrawn or archived: any live interview is cancelled.
export async function cancelActiveSession(applicationId, reason) {
  const [rows] = await pool.query(
    `SELECT id FROM interview_sessions WHERE application_id = ? AND status = 'in_progress'`, [applicationId]
  );
  for (const row of rows) await finishSession(row.id, 'cancelled', reason);
}

// Applicants who close the tab don't stop the clock. This makes sure HR still sees
// "Timed out" without anybody having to reopen the interview page.
async function sweepExpiredSessions() {
  const [rows] = await pool.query(
    `SELECT id FROM interview_sessions WHERE status = 'in_progress' AND expires_at IS NOT NULL AND expires_at <= NOW()`
  );
  for (const row of rows) await finishSession(row.id, 'timed_out', 'time_expired');
}

export function startInterviewSweeper(intervalMs = 15000) {
  const timer = setInterval(() => {
    sweepExpiredSessions().catch((err) => console.error('Interview sweeper failed:', err));
  }, intervalMs);
  timer.unref();
  sweepExpiredSessions().catch((err) => console.error('Interview sweeper failed:', err));
  return timer;
}
