import { callProviderForJson } from './aiClient.js';
import { MAX_RESUME_CHARS } from './resumeText.js';

// Room for the full JSON reply (scores, skill lists, summary, 4-6 questions)
// PLUS any hidden "thinking" tokens a reasoning model spends first. 2000 was
// too tight and caused truncated, unparseable replies on longer resumes.
const SCREENING_MAX_TOKENS = Number(process.env.AI_SCREENING_MAX_TOKENS) || 6000;

function buildScreeningPrompt(job, resumeText) {
  const required = job.required_skills || 'Not specified';
  const preferred = job.preferred_skills || 'Not specified';

  return `You are an experienced HR screening assistant. Analyze the RESUME against the
JOB, and return ONLY a single valid JSON object (no markdown, no commentary,
no code fences) matching exactly this schema:

{
  "overall_score": <integer 0-100>,
  "skills_score": <integer 0-100>,
  "experience_score": <integer 0-100>,
  "education_score": <integer 0-100>,
  "matched_skills": ["skill1", "skill2"],
  "missing_skills": ["skill1", "skill2"],
  "strengths": ["short bullet", "short bullet"],
  "gaps": ["short bullet", "short bullet"],
  "summary": "2-3 sentence recruiter-facing summary of overall fit",
  "suggested_questions": [
    {"question": "specific interview question", "reason": "why this question, grounded in the resume"}
  ]
}

Base every judgment strictly on the text provided. Do not invent facts not
present in the resume. Provide 4-6 suggested_questions, each grounded in a
specific, concrete detail from the resume rather than generic questions.

JOB TITLE: ${job.title}
SENIORITY: ${job.seniority_level}
MIN YEARS EXPERIENCE: ${job.min_years_experience}
EDUCATION REQUIREMENT: ${job.education_requirement}
REQUIRED SKILLS: ${required}
PREFERRED SKILLS: ${preferred}
JOB DESCRIPTION:
${job.description}

RESUME TEXT:
${resumeText}`;
}

const clampScore = (v) => {
  const n = Math.round(Number(v));
  return Number.isFinite(n) ? Math.min(100, Math.max(0, n)) : null;
};
const asList = (v) => (Array.isArray(v) ? v : []);

/**
 * Checks and normalizes the model's reply. A reply that parses as JSON but has
 * no usable overall_score would otherwise be saved as NULL and leave the
 * application showing "Analyzing..." forever, so it is treated as a failure.
 */
function normalizeResult(parsed) {
  const overall = clampScore(parsed.overall_score);
  if (overall === null) {
    return { error: 'AI response was missing a valid overall_score.', raw: parsed._raw };
  }
  return {
    ...parsed,
    overall_score: overall,
    skills_score: clampScore(parsed.skills_score) ?? overall,
    experience_score: clampScore(parsed.experience_score) ?? overall,
    education_score: clampScore(parsed.education_score) ?? overall,
    matched_skills: asList(parsed.matched_skills),
    missing_skills: asList(parsed.missing_skills),
    strengths: asList(parsed.strengths),
    gaps: asList(parsed.gaps),
    suggested_questions: asList(parsed.suggested_questions),
    summary: typeof parsed.summary === 'string' ? parsed.summary : '',
  };
}

/**
 * Runs AI screening for a given job + resume text.
 * Returns the parsed result object, or { error } on failure.
 */
export async function runAiScreening(job, resumeText) {
  if (!resumeText || !resumeText.trim()) {
    return { error: 'No resume text available to analyze.' };
  }

  const prompt = buildScreeningPrompt(job, resumeText.slice(0, MAX_RESUME_CHARS));
  const result = await callProviderForJson(prompt, SCREENING_MAX_TOKENS);
  if (result.error) return result;
  return normalizeResult(result);
}
