import { callProviderForJson } from './aiClient.js';

function jobContext(job) {
  return `JOB TITLE: ${job.title}
SENIORITY: ${job.seniority_level}
MIN YEARS EXPERIENCE: ${job.min_years_experience}
REQUIRED SKILLS: ${job.required_skills || 'Not specified'}
PREFERRED SKILLS: ${job.preferred_skills || 'Not specified'}
JOB DESCRIPTION:
${job.description}`;
}

/**
 * Step 1-2 of the flow: AI analyzes the resume + job requirements and
 * generates a fixed set of personalized technical interview questions.
 * Returns { questions: [{ question, focus_area }] } or { error }.
 */
export async function generateInterviewQuestions(job, resumeText) {
  if (!resumeText || !resumeText.trim()) {
    return { error: 'No resume text available to build an interview from.' };
  }

  const prompt = `You are an experienced technical interviewer. Based on the JOB REQUIREMENTS and
the candidate's RESUME below, design a short, personalized technical interview
made of two question types only:

- "multiple_choice": a question with exactly 4 plausible choices, only one correct.
- "identification": a question whose correct answer is a single short term,
  name, or short phrase (e.g. a technology, pattern, command, or concept) —
  not an essay question.

Return ONLY a single valid JSON object (no markdown, no commentary, no code
fences) matching exactly this schema:

{
  "questions": [
    {
      "type": "multiple_choice" | "identification",
      "question": "specific technical question, grounded in a concrete detail from the resume or the job's required skills",
      "focus_area": "short label, e.g. 'React / State Management'",
      "choices": ["choice A", "choice B", "choice C", "choice D"],
      "correct_answer": "the correct choice (must exactly match one entry in choices) for multiple_choice, or the expected short answer for identification"
    }
  ]
}

Write exactly 5 questions, ordered from foundational to more probing, with a
mix of both types (at least 2 of each). Omit "choices" (or leave it an empty
array) for "identification" questions. Ground each question in something
specific from the resume (a listed skill, project, or role) or a required
skill from the job that the resume doesn't clearly cover. Avoid generic
questions like "tell me about yourself".

${jobContext(job)}

RESUME TEXT:
${resumeText}`;

  const result = await callProviderForJson(prompt, 2000);
  if (result.error) return result;
  if (!Array.isArray(result.questions) || result.questions.length === 0) {
    return { error: 'AI did not return any interview questions.' };
  }
  // Defensive normalization in case the model drifts slightly from the schema.
  result.questions = result.questions.map((q) => ({
    type: q.type === 'multiple_choice' ? 'multiple_choice' : 'identification',
    question: q.question,
    focus_area: q.focus_area || null,
    choices: q.type === 'multiple_choice' && Array.isArray(q.choices) ? q.choices : [],
    correct_answer: q.correct_answer || null,
  }));
  return result;
}

/**
 * Step: evaluate a single answer against its question. `question` is the
 * full stored question object ({ type, question, choices, correct_answer }),
 * not just the text. Returns { score (0-100), feedback } or { error }.
 *
 * Multiple-choice is graded deterministically (it has one objectively
 * correct choice) so it's instant and never mis-scored by the model.
 * Identification answers go through the AI so close-but-not-exact phrasing
 * (synonyms, casing, extra words) can still earn credit.
 */
export async function evaluateInterviewAnswer(job, question, answer) {
  if (question.type === 'multiple_choice') {
    const isCorrect = normalize(answer) === normalize(question.correct_answer);
    return {
      score: isCorrect ? 100 : 0,
      feedback: isCorrect
        ? 'Selected the correct option.'
        : `Selected an incorrect option. Correct answer: ${question.correct_answer}.`,
    };
  }

  const prompt = `You are grading one answer in a live technical interview. The question expects
a short, specific answer (a term, name, command, or short phrase) — not an essay.
Grade the CANDIDATE ANSWER against the EXPECTED ANSWER below. Give full or
near-full credit for answers that are substantively correct even if worded
differently, abbreviated, or slightly imprecise; give low credit for answers
that are vague, wrong, or evasive.

Return ONLY a single valid JSON object (no markdown, no commentary, no code
fences) matching exactly this schema:

{
  "score": <integer 0-100>,
  "feedback": "1-2 sentence recruiter-facing note on the technical quality of this specific answer"
}

${jobContext(job)}

INTERVIEW QUESTION:
${question.question}

EXPECTED ANSWER (reference only, do not reveal verbatim in feedback):
${question.correct_answer || 'Not specified — use your own technical judgment.'}

CANDIDATE ANSWER:
${answer}`;

  const result = await callProviderForJson(prompt, 400);
  if (result.error) return result;
  if (typeof result.score !== 'number') return { error: 'AI did not return a valid score.' };
  return result;
}

function normalize(s) {
  return (s || '').trim().toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();
}

/**
 * Final step: AI generates the Technical Assessment Report once every
 * question has been answered and evaluated.
 * Returns the report object or { error }.
 */
export async function generateAssessmentReport(job, resumeText, qaPairs, meta = {}) {
  const transcript = qaPairs
    .map((qa, i) => `Q${i + 1} (${qa.focus_area || 'General'}): ${qa.question}\nAnswer: ${qa.answer}\nPer-answer score: ${qa.eval_score}/100 — ${qa.eval_feedback}`)
    .join('\n\n');

  const unanswered = Math.max(0, (meta.totalQuestions || qaPairs.length) - qaPairs.length);
  const coverageNote = unanswered > 0
    ? `\nCOVERAGE NOTE: ${unanswered} of ${meta.totalQuestions} questions were skipped or not reached${meta.endedReason === 'time_expired' ? ' (the 20 minute time limit expired)' : ''}. Do NOT treat unanswered questions as wrong answers. Base scores only on the answered questions, and mention the limited coverage in the summary.\n`
    : '';

  const prompt = `You are compiling the final Technical Assessment Report for a candidate who
finished a live AI-conducted technical interview. Use the JOB
REQUIREMENTS, the candidate's RESUME, and the full INTERVIEW TRANSCRIPT
(including per-answer scores already assigned) below.

Return ONLY a single valid JSON object (no markdown, no commentary, no code
fences) matching exactly this schema:

{
  "technical_score": <integer 0-100, overall technical competence across the interview>,
  "communication_score": <integer 0-100, clarity and structure of the candidate's answers>,
  "strengths": ["short bullet", "short bullet"],
  "weaknesses": ["short bullet", "short bullet"],
  "recommendation": "Strong Hire" | "Hire" | "Lean Hire" | "No Hire",
  "summary": "3-4 sentence recruiter-facing narrative summary of the candidate's technical performance in this interview"
}

Base every judgment strictly on the transcript and resume provided. Weigh the
per-answer scores heavily but use your own judgment for the overall picture.
${coverageNote}
${jobContext(job)}

RESUME TEXT:
${resumeText}

INTERVIEW TRANSCRIPT:
${transcript}`;

  const result = await callProviderForJson(prompt, 1200);
  if (result.error) return result;
  if (typeof result.technical_score !== 'number') return { error: 'AI did not return a valid technical_score.' };
  return result;
}
