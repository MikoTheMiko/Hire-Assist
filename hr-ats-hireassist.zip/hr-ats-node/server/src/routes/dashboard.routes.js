import express from 'express';
import { pool } from '../db.js';
import { requireAuth, requireRole } from '../middleware/auth.js';
import { catchAsync } from '../utils/catchAsync.js';

// Analytics for the HR dashboard. Every query is scoped to jobs created by
// the logged-in HR user (j.created_by = ?) — the same ownership rule the
// applications/jobs routes already use — and everything is computed with SQL
// aggregation (COUNT / AVG / GROUP BY), never from client-side data.
const router = express.Router();
router.use(requireAuth, requireRole('hr'));

// Same list used by the application status ENUM in schema.sql / the client filter.
const PIPELINE_STAGES = ['submitted', 'screened', 'shortlisted', 'interview', 'offer', 'rejected', 'withdrawn'];
// Archived applications are removed from the active workspace, so they are left out of every number below.
const ACTIVE = "a.status <> 'archived'";
const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

const num = (v) => Number(v || 0);
const pad = (n) => String(n).padStart(2, '0');
const ymd = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;

// "Today" according to the database, so bucket boundaries match the SQL
// (CURDATE()) even if Node and MySQL are on different timezones.
async function dbToday() {
  const [[row]] = await pool.query(`SELECT DATE_FORMAT(CURDATE(), '%Y-%m-%d') AS today`);
  const [y, m, d] = row.today.split('-').map(Number);
  return new Date(y, m - 1, d);
}

function lastNDays(today, n) {
  const days = [];
  for (let i = n - 1; i >= 0; i--) {
    const d = new Date(today.getFullYear(), today.getMonth(), today.getDate() - i);
    days.push({ key: ymd(d), label: `${MONTHS[d.getMonth()]} ${d.getDate()}` });
  }
  return days;
}

function lastNMonths(today, n) {
  const months = [];
  for (let i = n - 1; i >= 0; i--) {
    const d = new Date(today.getFullYear(), today.getMonth() - i, 1);
    months.push({ key: `${d.getFullYear()}-${pad(d.getMonth() + 1)}`, label: MONTHS[d.getMonth()] });
  }
  return months;
}

function pctChange(current, previous) {
  if (!previous) return null; // no baseline -> no honest percentage
  return Math.round(((current - previous) / previous) * 1000) / 10;
}

function clampLimit(raw, fallback, max) {
  const n = parseInt(raw, 10);
  if (!n || n < 1) return fallback;
  return Math.min(n, max);
}

// Daily counts for the last N days (missing days are zero-filled) — used for KPI sparklines.
async function dailySeries(table, dateCol, joinSql, uid, days, today) {
  const [rows] = await pool.query(
    `SELECT DATE_FORMAT(${dateCol}, '%Y-%m-%d') AS bucket, COUNT(*) AS c
     FROM ${table} ${joinSql}
     WHERE j.created_by = ? AND ${ACTIVE} AND ${dateCol} >= DATE_SUB(CURDATE(), INTERVAL ? DAY)
     GROUP BY bucket`,
    [uid, days - 1]
  );
  const map = new Map(rows.map((r) => [r.bucket, num(r.c)]));
  return lastNDays(today, days).map((d) => map.get(d.key) || 0);
}

const APP_JOIN = 'a JOIN jobs j ON j.id = a.job_id';
const SESSION_JOIN = 's JOIN applications a ON a.id = s.application_id JOIN jobs j ON j.id = a.job_id';

// ---- KPI cards ------------------------------------------------------------
router.get('/stats', catchAsync(async (req, res) => {
  const uid = req.user.id;
  const today = await dbToday();

  const [[apps]] = await pool.query(
    `SELECT COUNT(*) AS total,
        SUM(a.created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)) AS last30,
        SUM(a.created_at >= DATE_SUB(NOW(), INTERVAL 60 DAY) AND a.created_at < DATE_SUB(NOW(), INTERVAL 30 DAY)) AS prev30,
        SUM(a.status = 'offer') AS offers
     FROM applications ${APP_JOIN} WHERE j.created_by = ? AND ${ACTIVE}`, [uid]
  );
  const [[jobs]] = await pool.query(
    `SELECT COUNT(*) AS total, SUM(status = 'open') AS open_jobs,
        SUM(status = 'draft') AS drafts, SUM(status = 'closed') AS closed
     FROM jobs WHERE created_by = ?`, [uid]
  );
  const [[ivs]] = await pool.query(
    `SELECT COUNT(*) AS total, SUM(s.status = 'completed') AS completed, SUM(s.status = 'in_progress') AS in_progress,
        SUM(s.status = 'timed_out') AS timed_out, SUM(s.status = 'cancelled') AS cancelled,
        SUM(s.started_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)) AS last30,
        SUM(s.started_at >= DATE_SUB(NOW(), INTERVAL 60 DAY) AND s.started_at < DATE_SUB(NOW(), INTERVAL 30 DAY)) AS prev30
     FROM interview_sessions ${SESSION_JOIN} WHERE j.created_by = ? AND ${ACTIVE}`, [uid]
  );

  const [appSpark, ivSpark] = await Promise.all([
    dailySeries('applications', 'a.created_at', APP_JOIN, uid, 14, today),
    dailySeries('interview_sessions', 's.started_at', SESSION_JOIN, uid, 14, today),
  ]);

  const totalApps = num(apps.total);
  const offers = num(apps.offers);
  res.json({
    applications: {
      total: totalApps, last30: num(apps.last30), previous30: num(apps.prev30),
      change_pct: pctChange(num(apps.last30), num(apps.prev30)), sparkline: appSpark,
    },
    jobs: { total: num(jobs.total), open: num(jobs.open_jobs), drafts: num(jobs.drafts), closed: num(jobs.closed) },
    interviews: {
      total: num(ivs.total), completed: num(ivs.completed), in_progress: num(ivs.in_progress),
      timed_out: num(ivs.timed_out), cancelled: num(ivs.cancelled),
      last30: num(ivs.last30), previous30: num(ivs.prev30),
      change_pct: pctChange(num(ivs.last30), num(ivs.prev30)), sparkline: ivSpark,
    },
    // There is no "hired" status in the schema — 'offer' is the furthest a candidate goes.
    offers: { total: offers, rate_pct: totalApps ? Math.round((offers / totalApps) * 1000) / 10 : null },
  });
}));

// ---- Applications over time ----------------------------------------------
router.get('/applications-over-time', catchAsync(async (req, res) => {
  const uid = req.user.id;
  const range = ['7d', '30d', '6m'].includes(req.query.range) ? req.query.range : '30d';
  const today = await dbToday();

  let buckets, rows;
  if (range === '6m') {
    buckets = lastNMonths(today, 6);
    [rows] = await pool.query(
      `SELECT DATE_FORMAT(a.created_at, '%Y-%m') AS bucket, COUNT(*) AS c
       FROM applications ${APP_JOIN}
       WHERE j.created_by = ? AND ${ACTIVE} AND a.created_at >= DATE_FORMAT(DATE_SUB(CURDATE(), INTERVAL 5 MONTH), '%Y-%m-01')
       GROUP BY bucket`, [uid]
    );
  } else {
    const days = range === '7d' ? 7 : 30;
    buckets = lastNDays(today, days);
    [rows] = await pool.query(
      `SELECT DATE_FORMAT(a.created_at, '%Y-%m-%d') AS bucket, COUNT(*) AS c
       FROM applications ${APP_JOIN}
       WHERE j.created_by = ? AND ${ACTIVE} AND a.created_at >= DATE_SUB(CURDATE(), INTERVAL ? DAY)
       GROUP BY bucket`, [uid, days - 1]
    );
  }

  const map = new Map(rows.map((r) => [r.bucket, num(r.c)]));
  const points = buckets.map((b) => ({ key: b.key, label: b.label, count: map.get(b.key) || 0 }));
  res.json({ range, granularity: range === '6m' ? 'month' : 'day', total: points.reduce((s, p) => s + p.count, 0), points });
}));

// ---- Hiring pipeline ------------------------------------------------------
router.get('/pipeline', catchAsync(async (req, res) => {
  const [rows] = await pool.query(
    `SELECT a.status, COUNT(*) AS c FROM applications ${APP_JOIN}
     WHERE j.created_by = ? AND ${ACTIVE} GROUP BY a.status`, [req.user.id]
  );
  const map = new Map(rows.map((r) => [r.status, num(r.c)]));
  const stages = PIPELINE_STAGES.map((status) => ({ status, count: map.get(status) || 0 }));
  res.json({ total: stages.reduce((s, x) => s + x.count, 0), stages });
}));

// ---- Applications by job --------------------------------------------------
router.get('/jobs-performance', catchAsync(async (req, res) => {
  const limit = clampLimit(req.query.limit, 8, 10);
  const [rows] = await pool.query(
    `SELECT j.id, j.title, j.status, COUNT(a.id) AS application_count, ROUND(AVG(a.ai_overall_score)) AS avg_score
     FROM jobs j JOIN applications a ON a.job_id = j.id
     WHERE j.created_by = ? AND ${ACTIVE}
     GROUP BY j.id, j.title, j.status
     ORDER BY application_count DESC, j.title ASC
     LIMIT ?`, [req.user.id, limit]
  );
  res.json({
    jobs: rows.map((r) => ({
      id: r.id, title: r.title, status: r.status,
      applications: num(r.application_count), avg_score: r.avg_score === null ? null : num(r.avg_score),
    })),
  });
}));

// ---- AI screening score distribution -------------------------------------
router.get('/screening-distribution', catchAsync(async (req, res) => {
  const uid = req.user.id;
  const [rows] = await pool.query(
    `SELECT CASE
        WHEN a.ai_overall_score >= 90 THEN '90-100'
        WHEN a.ai_overall_score >= 80 THEN '80-89'
        WHEN a.ai_overall_score >= 70 THEN '70-79'
        WHEN a.ai_overall_score >= 60 THEN '60-69'
        ELSE 'below-60' END AS bucket,
        COUNT(*) AS c
     FROM applications ${APP_JOIN}
     WHERE j.created_by = ? AND ${ACTIVE} AND a.ai_overall_score IS NOT NULL
     GROUP BY bucket`, [uid]
  );
  const [[summary]] = await pool.query(
    `SELECT COUNT(a.ai_overall_score) AS scored, ROUND(AVG(a.ai_overall_score), 1) AS average,
        SUM(a.ai_overall_score IS NULL) AS pending
     FROM applications ${APP_JOIN} WHERE j.created_by = ? AND ${ACTIVE}`, [uid]
  );
  const map = new Map(rows.map((r) => [r.bucket, num(r.c)]));
  const buckets = [
    { key: '90-100', label: '90-100' }, { key: '80-89', label: '80-89' }, { key: '70-79', label: '70-79' },
    { key: '60-69', label: '60-69' }, { key: 'below-60', label: 'Below 60' },
  ].map((b) => ({ ...b, count: map.get(b.key) || 0 }));

  res.json({
    scored: num(summary.scored),
    pending: num(summary.pending),
    average: summary.average === null ? null : Number(summary.average),
    buckets,
  });
}));

// ---- Interview performance ------------------------------------------------
router.get('/interview-performance', catchAsync(async (req, res) => {
  const [[row]] = await pool.query(
    `SELECT COUNT(*) AS total, SUM(s.status = 'completed') AS completed, SUM(s.status = 'in_progress') AS in_progress,
        SUM(s.status = 'timed_out') AS timed_out, SUM(s.status = 'cancelled') AS cancelled,
        COUNT(s.report_technical_score) AS scored,
        ROUND(AVG(s.report_technical_score)) AS technical_avg,
        ROUND(AVG(s.report_communication_score)) AS communication_avg
     FROM interview_sessions ${SESSION_JOIN} WHERE j.created_by = ? AND ${ACTIVE}`, [req.user.id]
  );
  res.json({
    total: num(row.total), completed: num(row.completed), in_progress: num(row.in_progress),
    timed_out: num(row.timed_out), cancelled: num(row.cancelled),
    scored: num(row.scored), // completed sessions whose AI report has finished generating
    technical_avg: row.technical_avg === null ? null : num(row.technical_avg),
    communication_avg: row.communication_avg === null ? null : num(row.communication_avg),
  });
}));

// ---- Recent applications --------------------------------------------------
router.get('/recent-applications', catchAsync(async (req, res) => {
  const limit = clampLimit(req.query.limit, 6, 20);
  const [rows] = await pool.query(
    `SELECT a.id, a.status, a.ai_overall_score, a.ai_error, a.created_at, u.name AS applicant_name, j.title AS job_title
     FROM applications a JOIN jobs j ON j.id = a.job_id JOIN users u ON u.id = a.user_id
     WHERE j.created_by = ? AND ${ACTIVE} ORDER BY a.created_at DESC, a.id DESC LIMIT ?`, [req.user.id, limit]
  );
  res.json({ applications: rows });
}));

// ---- Recent interview activity -------------------------------------------
router.get('/recent-interviews', catchAsync(async (req, res) => {
  const limit = clampLimit(req.query.limit, 6, 20);
  const [rows] = await pool.query(
    `SELECT s.id, s.application_id, s.status, s.current_index, s.questions,
        s.report_technical_score, s.report_communication_score, s.started_at, s.completed_at,
        u.name AS applicant_name, j.title AS job_title
     FROM interview_sessions s
     JOIN applications a ON a.id = s.application_id
     JOIN jobs j ON j.id = a.job_id
     JOIN users u ON u.id = a.user_id
     WHERE j.created_by = ? AND ${ACTIVE}
     ORDER BY COALESCE(s.completed_at, s.started_at) DESC, s.id DESC LIMIT ?`, [req.user.id, limit]
  );
  res.json({
    interviews: rows.map(({ questions, ...r }) => {
      let total = null;
      try { total = JSON.parse(questions).length; } catch { /* leave null */ }
      return { ...r, total_questions: total };
    }),
  });
}));

export default router;
