import express from 'express';
import { pool } from '../db.js';
import { requireAuth, requireRole } from '../middleware/auth.js';
import { generateInterviewQuestions, evaluateInterviewAnswer } from '../services/interviewAi.js';
import { emitInterviewStarted, emitInterviewTurn } from '../socket.js';
import {
  INTERVIEW_DURATION_SECONDS, loadSession, expireIfNeeded, finishSession,
} from '../services/interviewSessions.js';
import { catchAsync } from '../utils/catchAsync.js';

const router = express.Router();

// Application statuses that no longer allow an interview to be started or continued.
const INACTIVE_APPLICATION_STATUSES = ['withdrawn', 'archived'];

// Loads the application + its job (flattened, so it can be passed straight
// into the AI service functions which expect job.title/description/etc.)
// and checks the requesting user is either the applicant who owns it or the
// HR user who posted the job.
async function loadApplicationForAccess(applicationId, user) {
  const [rows] = await pool.query(
    `SELECT a.*, j.title, j.department, j.seniority_level, j.employment_type, j.description,
        j.required_skills, j.preferred_skills, j.min_years_experience, j.education_requirement,
        j.created_by AS job_owner_id
     FROM applications a JOIN jobs j ON a.job_id = j.id WHERE a.id = ?`,
    [applicationId]
  );
  const app = rows[0];
  if (!app) return null;

  const isOwnerApplicant = user.role === 'applicant' && app.user_id === user.id;
  const isOwnerHr = user.role === 'hr' && app.job_owner_id === user.id;
  if (!isOwnerApplicant && !isOwnerHr) return null;

  return { app, isOwnerApplicant, isOwnerHr };
}

// Never send `correct_answer` (or anything beyond what's needed to render
// the question) to the client while it's still live, that's the answer key.
function sanitizeQuestion(q) {
  if (!q) return null;
  return { type: q.type || 'identification', question: q.question, focus_area: q.focus_area || null, choices: q.choices || [] };
}

async function loadAnswers(sessionId) {
  const [answers] = await pool.query(
    'SELECT * FROM interview_answers WHERE session_id = ? ORDER BY question_index ASC', [sessionId]
  );
  return answers;
}

function serializeSession(session, answers) {
  const questions = JSON.parse(session.questions);
  const inProgress = session.status === 'in_progress';
  return {
    id: session.id,
    status: session.status,
    ended_reason: session.ended_reason || null,
    current_index: session.current_index,
    total_questions: questions.length,
    current_question: inProgress ? sanitizeQuestion(questions[session.current_index]) : null,
    duration_seconds: session.duration_seconds,
    // Seconds left according to the database clock at the moment of this response.
    remaining_seconds: inProgress ? Number(session.remaining_seconds) : 0,
    expires_at: session.expires_at,
    answered_count: answers.filter((a) => !a.skipped).length,
    skipped_count: answers.filter((a) => a.skipped).length,
    history: answers.map((a) => ({
      question_index: a.question_index,
      question: a.question,
      focus_area: a.focus_area,
      type: questions[a.question_index]?.type || 'identification',
      choices: questions[a.question_index]?.choices || [],
      answer: a.answer,
      skipped: !!a.skipped,
      eval_score: a.eval_score,
      eval_feedback: a.eval_feedback,
    })),
    // Only sessions with at least one real answer get a report (completed or timed out).
    report: session.report_technical_score !== null && session.report_technical_score !== undefined ? {
      technical_score: session.report_technical_score,
      communication_score: session.report_communication_score,
      strengths: session.report_strengths ? JSON.parse(session.report_strengths) : [],
      weaknesses: session.report_weaknesses ? JSON.parse(session.report_weaknesses) : [],
      recommendation: session.report_recommendation,
      summary: session.report_summary,
    } : null,
    started_at: session.started_at,
    completed_at: session.completed_at,
  };
}

const ENDED_MESSAGES = {
  completed: 'This interview is already complete.',
  timed_out: 'The 20 minute time limit has expired. This interview was submitted automatically.',
  cancelled: 'This interview was cancelled and can no longer be continued.',
};

// Sends the "this session is not accepting answers" response, including the
// up-to-date session so the client can switch to the right screen at once.
async function respondEnded(res, session) {
  const answers = await loadAnswers(session.id);
  return res.status(409).json({
    error: ENDED_MESSAGES[session.status] || 'This interview is not active.',
    code: session.status,
    session: serializeSession(session, answers),
  });
}

// HR: every interview session across the jobs they posted (powers the
// Interviews page). Optional ?status=in_progress|completed|timed_out|cancelled and
// ?search= (candidate name or job title). Registered before '/:applicationId'.
router.get('/hr/list', requireAuth, requireRole('hr'), catchAsync(async (req, res) => {
  let sql = `SELECT s.id, s.application_id, s.status, s.ended_reason, s.current_index, s.questions,
      s.report_technical_score, s.report_communication_score, s.report_recommendation,
      s.started_at, s.completed_at, u.name AS applicant_name, u.email AS applicant_email, j.title AS job_title
    FROM interview_sessions s
    JOIN applications a ON a.id = s.application_id
    JOIN jobs j ON j.id = a.job_id
    JOIN users u ON u.id = a.user_id
    WHERE j.created_by = ?`;
  const params = [req.user.id];

  if (['in_progress', 'completed', 'timed_out', 'cancelled'].includes(req.query.status)) { sql += ' AND s.status = ?'; params.push(req.query.status); }

  const term = (req.query.search || '').toString().trim().slice(0, 100);
  if (term) {
    const like = `%${term.replace(/[\\%_]/g, '\\$&')}%`;
    sql += ' AND (u.name LIKE ? OR u.email LIKE ? OR j.title LIKE ?)';
    params.push(like, like, like);
  }
  sql += ' ORDER BY COALESCE(s.completed_at, s.started_at) DESC, s.id DESC';

  const [rows] = await pool.query(sql, params);
  res.json(rows.map(({ questions, ...r }) => {
    let total = null;
    try { total = JSON.parse(questions).length; } catch { /* leave null */ }
    return { ...r, total_questions: total };
  }));
}));

// Get the interview session + transcript so far (applicant owner or HR owner).
// Returns { session: null, status: 'not_started' } if the applicant hasn't started one yet.
// If the timer has run out, the session is closed as timed_out before it is returned.
router.get('/:applicationId', requireAuth, catchAsync(async (req, res) => {
  const access = await loadApplicationForAccess(req.params.applicationId, req.user);
  if (!access) return res.status(403).json({ error: 'Not authorized.' });

  let session = await loadSession(req.params.applicationId);
  if (!session) return res.json({ session: null, status: 'not_started' });

  session = await expireIfNeeded(session);
  const answers = await loadAnswers(session.id);
  res.json({ session: serializeSession(session, answers), status: session.status });
}));

// Applicant: start the interview. AI analyzes resume + job requirements and
// generates the personalized question set. Idempotent - if a session already
// exists (e.g. the applicant refreshed mid-interview), just returns it. The 20 minute
// clock starts here, after the questions exist, so AI generation time isn't charged.
router.post('/:applicationId/start', requireAuth, requireRole('applicant'), catchAsync(async (req, res) => {
  const access = await loadApplicationForAccess(req.params.applicationId, req.user);
  if (!access || !access.isOwnerApplicant) return res.status(403).json({ error: 'Not authorized.' });
  const { app } = access;

  let existing = await loadSession(req.params.applicationId);
  if (existing) {
    existing = await expireIfNeeded(existing);
    const answers = await loadAnswers(existing.id);
    return res.json({ session: serializeSession(existing, answers) });
  }

  if (INACTIVE_APPLICATION_STATUSES.includes(app.status)) {
    return res.status(409).json({
      error: app.status === 'withdrawn'
        ? 'This application was withdrawn, so the interview is no longer available.'
        : 'This application is no longer active, so the interview is not available.',
      code: app.status,
    });
  }

  if (!app.resume_text || !app.resume_text.trim()) {
    return res.status(400).json({ error: 'No resume text on file to build an interview from.' });
  }

  const generated = await generateInterviewQuestions(app, app.resume_text);
  if (generated.error) return res.status(502).json({ error: generated.error });

  let result;
  try {
    [result] = await pool.query(
      `INSERT INTO interview_sessions (application_id, status, questions, current_index, duration_seconds, expires_at)
       VALUES (?, 'in_progress', ?, 0, ?, DATE_ADD(NOW(), INTERVAL ? SECOND))`,
      [req.params.applicationId, JSON.stringify(generated.questions), INTERVIEW_DURATION_SECONDS, INTERVIEW_DURATION_SECONDS]
    );
  } catch (err) {
    if (err.code === 'ER_DUP_ENTRY') {
      // Lost a race with a duplicate request - just return the session that won.
      const winner = await loadSession(req.params.applicationId);
      return res.json({ session: serializeSession(winner, await loadAnswers(winner.id)) });
    }
    throw err;
  }

  // Move the application into the interview stage, without downgrading it if
  // HR already moved it further along (e.g. offer/rejected).
  await pool.query(
    `UPDATE applications SET status = 'interview' WHERE id = ? AND status IN ('submitted', 'screened', 'shortlisted')`,
    [req.params.applicationId]
  );

  const session = serializeSession(await loadSession(req.params.applicationId), []);
  emitInterviewStarted({ applicationId: Number(req.params.applicationId), session });
  res.status(201).json({ session });
}));

// Shared by "answer" and "skip": records the turn, tells the room, then either
// moves to the next question or finishes the interview.
async function recordTurnAndAdvance({ req, res, session, questions, turn, evaluation }) {
  const currentQuestion = questions[session.current_index];

  try {
    await pool.query(
      `INSERT INTO interview_answers (session_id, question_index, question, focus_area, answer, skipped, eval_score, eval_feedback)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [session.id, session.current_index, currentQuestion.question, currentQuestion.focus_area || null,
        turn.answer, turn.skipped ? 1 : 0, turn.skipped ? null : evaluation.score, turn.skipped ? null : (evaluation.feedback || '')]
    );
  } catch (err) {
    if (err.code === 'ER_DUP_ENTRY') return res.status(409).json({ error: 'That question was already handled.' });
    throw err;
  }

  emitInterviewTurn({
    applicationId: Number(req.params.applicationId),
    turn: {
      question_index: session.current_index,
      question: currentQuestion.question,
      focus_area: currentQuestion.focus_area || null,
      type: currentQuestion.type || 'identification',
      choices: currentQuestion.choices || [],
      answer: turn.answer,
      skipped: !!turn.skipped,
      eval_score: turn.skipped ? null : evaluation.score,
      eval_feedback: turn.skipped ? null : (evaluation.feedback || ''),
    },
  });

  const nextIndex = session.current_index + 1;
  const isDone = nextIndex >= questions.length;
  const evalPayload = turn.skipped ? null : { score: evaluation.score, feedback: evaluation.feedback };

  await pool.query(
    `UPDATE interview_sessions SET current_index = ? WHERE id = ? AND status = 'in_progress'`, [nextIndex, session.id]
  );

  if (!isDone) {
    return res.json({
      done: false, skipped: !!turn.skipped, eval: evalPayload,
      next_question: sanitizeQuestion(questions[nextIndex]),
      current_index: nextIndex, total_questions: questions.length,
    });
  }

  // Respond immediately - don't make the applicant wait on the (slower)
  // full-report generation. finishSession() kicks it off; the report arrives over the socket.
  await finishSession(session.id, 'completed', 'all_answered');
  return res.json({
    done: true, status: 'completed', skipped: !!turn.skipped, eval: evalPayload,
    total_questions: questions.length,
    message: 'Interview complete. Generating your Technical Assessment Report...',
  });
}

// Loads the live session for a write action, closing it first if time ran out.
// Returns the session, or null after sending the error response itself.
async function requireLiveSession(req, res) {
  let session = await loadSession(req.params.applicationId);
  if (!session) { res.status(404).json({ error: 'Interview has not been started yet.' }); return null; }
  session = await expireIfNeeded(session);
  if (session.status !== 'in_progress') { await respondEnded(res, session); return null; }
  return session;
}

// Applicant: submit an answer to the current question. AI evaluates it,
// then either returns the next question or - if that was the last one -
// completes the session and kicks off the final report in the background.
router.post('/:applicationId/answer', requireAuth, requireRole('applicant'), catchAsync(async (req, res) => {
  const access = await loadApplicationForAccess(req.params.applicationId, req.user);
  if (!access || !access.isOwnerApplicant) return res.status(403).json({ error: 'Not authorized.' });
  const { app } = access;

  const answer = (req.body.answer || '').trim();
  if (!answer) return res.status(400).json({ error: 'Answer cannot be empty.' });

  const session = await requireLiveSession(req, res);
  if (!session) return undefined;

  const questions = JSON.parse(session.questions);
  const currentQuestion = questions[session.current_index];
  if (!currentQuestion) return res.status(409).json({ error: 'No current question found for this session.' });

  const evaluation = await evaluateInterviewAnswer(app, currentQuestion, answer);
  if (evaluation.error) return res.status(502).json({ error: evaluation.error });

  // The AI call can take a few seconds. If the session was closed meanwhile
  // (timer expired, cancelled, application withdrawn) the answer is not accepted.
  const fresh = await loadSession(req.params.applicationId);
  if (!fresh || fresh.status !== 'in_progress') return respondEnded(res, fresh || session);

  return recordTurnAndAdvance({ req, res, session, questions, turn: { answer, skipped: false }, evaluation });
}));

// Applicant: skip the current question. Recorded as unanswered (no score),
// not as a technical failure, and the interview moves on.
router.post('/:applicationId/skip', requireAuth, requireRole('applicant'), catchAsync(async (req, res) => {
  const access = await loadApplicationForAccess(req.params.applicationId, req.user);
  if (!access || !access.isOwnerApplicant) return res.status(403).json({ error: 'Not authorized.' });

  const session = await requireLiveSession(req, res);
  if (!session) return undefined;

  const questions = JSON.parse(session.questions);
  if (!questions[session.current_index]) return res.status(409).json({ error: 'No current question found for this session.' });

  return recordTurnAndAdvance({ req, res, session, questions, turn: { answer: '', skipped: true } });
}));

// Applicant: leave the interview for good. Progress so far is kept, the session is
// marked cancelled and cannot be resumed. Calling it again is harmless.
router.post('/:applicationId/cancel', requireAuth, requireRole('applicant'), catchAsync(async (req, res) => {
  const access = await loadApplicationForAccess(req.params.applicationId, req.user);
  if (!access || !access.isOwnerApplicant) return res.status(403).json({ error: 'Not authorized.' });

  let session = await loadSession(req.params.applicationId);
  if (!session) return res.status(404).json({ error: 'Interview has not been started yet.' });
  session = await expireIfNeeded(session);

  if (session.status === 'in_progress') {
    await finishSession(session.id, 'cancelled', 'user_cancelled');
    session = await loadSession(req.params.applicationId);
  } else if (session.status !== 'cancelled') {
    return respondEnded(res, session); // already completed or timed out, nothing to cancel
  }
  res.json({ session: serializeSession(session, await loadAnswers(session.id)) });
}));

export default router;
