import express from 'express';
import { pool } from '../db.js';
import { requireAuth, requireRole } from '../middleware/auth.js';
import { catchAsync } from '../utils/catchAsync.js';

const router = express.Router();

// Salary is optional and estimated, but if given it has to make sense.
function validateSalaryRange(min, max) {
  const hasMin = min !== '' && min !== undefined && min !== null;
  const hasMax = max !== '' && max !== undefined && max !== null;
  if (hasMin && (isNaN(min) || Number(min) < 0)) return 'Minimum salary must be a positive number.';
  if (hasMax && (isNaN(max) || Number(max) < 0)) return 'Maximum salary must be a positive number.';
  if (hasMin && hasMax && Number(min) > Number(max)) return 'Minimum salary cannot be greater than maximum salary.';
  return null;
}

function normalizeSalary(v) {
  return v === '' || v === undefined || v === null ? null : v;
}

// Public: list open jobs
// Optional ?q= does a case-insensitive partial match on title, description, department and skills.
// With no q the response is exactly what it was before.
router.get('/', catchAsync(async (req, res) => {
  let sql = `SELECT j.*, u.name AS posted_by FROM jobs j JOIN users u ON j.created_by = u.id
     WHERE j.status = 'open'`;
  const params = [];
  const term = (req.query.q || '').toString().trim().slice(0, 100);
  if (term) {
    const like = `%${term.replace(/[\\%_]/g, '\\$&')}%`;
    sql += ' AND (j.title LIKE ? OR j.description LIKE ? OR j.department LIKE ? OR j.required_skills LIKE ? OR j.preferred_skills LIKE ?)';
    params.push(like, like, like, like, like);
  }
  sql += ' ORDER BY j.created_at DESC';
  const [rows] = await pool.query(sql, params);
  res.json(rows);
}));

// Public: job detail
router.get('/:id', catchAsync(async (req, res) => {
  const [rows] = await pool.query(
    `SELECT j.*, u.name AS posted_by FROM jobs j JOIN users u ON j.created_by = u.id WHERE j.id = ?`,
    [req.params.id]
  );
  if (!rows[0]) return res.status(404).json({ error: 'Job not found.' });
  res.json(rows[0]);
}));

// HR: create a job
router.post('/', requireAuth, requireRole('hr'), catchAsync(async (req, res) => {
  const {
    title, department, seniority_level, employment_type, description,
    required_skills, preferred_skills, min_years_experience, education_requirement, status,
    salary_min, salary_max, salary_type,
  } = req.body;

  if (!title || !description) {
    return res.status(400).json({ error: 'Title and description are required.' });
  }

  const salaryError = validateSalaryRange(salary_min, salary_max);
  if (salaryError) return res.status(400).json({ error: salaryError });

  const [result] = await pool.query(
    `INSERT INTO jobs (title, department, seniority_level, employment_type, description,
      required_skills, preferred_skills, min_years_experience, education_requirement, status,
      salary_min, salary_max, salary_type, created_by)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [title, department || null, seniority_level || 'Mid', employment_type || 'Full-time', description,
      required_skills || '', preferred_skills || '', min_years_experience || 0,
      education_requirement || null, status || 'open',
      normalizeSalary(salary_min), normalizeSalary(salary_max), salary_type || 'Monthly',
      req.user.id]
  );

  res.status(201).json({ id: result.insertId });
}));

// HR: edit a job they posted
router.put('/:id', requireAuth, requireRole('hr'), catchAsync(async (req, res) => {
  const [rows] = await pool.query('SELECT * FROM jobs WHERE id = ?', [req.params.id]);
  const job = rows[0];
  if (!job) return res.status(404).json({ error: 'Job not found.' });
  if (job.created_by !== req.user.id) return res.status(403).json({ error: 'Not authorized to edit this job.' });

  const {
    title, department, seniority_level, employment_type, description,
    required_skills, preferred_skills, min_years_experience, education_requirement, status,
    salary_min, salary_max, salary_type,
  } = req.body;

  if (!title || !description) {
    return res.status(400).json({ error: 'Title and description are required.' });
  }

  const salaryError = validateSalaryRange(salary_min, salary_max);
  if (salaryError) return res.status(400).json({ error: salaryError });

  await pool.query(
    `UPDATE jobs SET title = ?, department = ?, seniority_level = ?, employment_type = ?, description = ?,
      required_skills = ?, preferred_skills = ?, min_years_experience = ?, education_requirement = ?, status = ?,
      salary_min = ?, salary_max = ?, salary_type = ?
     WHERE id = ?`,
    [title, department || null, seniority_level || 'Mid', employment_type || 'Full-time', description,
      required_skills || '', preferred_skills || '', min_years_experience || 0,
      education_requirement || null, status || 'open',
      normalizeSalary(salary_min), normalizeSalary(salary_max), salary_type || 'Monthly',
      req.params.id]
  );

  res.json({ ok: true });
}));

// HR: quick status toggle — this is the "Close Job" / "Reopen Job" action,
// kept separate from the full edit form since it's a one-click, frequent
// action HR should be able to do straight from the job list.
router.patch('/:id/status', requireAuth, requireRole('hr'), catchAsync(async (req, res) => {
  const { status } = req.body;
  if (!['open', 'closed', 'draft'].includes(status)) {
    return res.status(400).json({ error: 'Invalid status.' });
  }

  const [rows] = await pool.query('SELECT created_by FROM jobs WHERE id = ?', [req.params.id]);
  const job = rows[0];
  if (!job) return res.status(404).json({ error: 'Job not found.' });
  if (job.created_by !== req.user.id) return res.status(403).json({ error: 'Not authorized to update this job.' });

  await pool.query('UPDATE jobs SET status = ? WHERE id = ?', [status, req.params.id]);
  res.json({ ok: true, status });
}));

// HR: permanently remove a job they posted. This cascades to that job's
// applications (resumes, AI screenings, interview history) — the client is
// expected to show a clear warning before calling this; closing the job
// (PATCH .../status) is the non-destructive alternative that keeps existing
// applications and interview records intact while stopping new ones.
router.delete('/:id', requireAuth, requireRole('hr'), catchAsync(async (req, res) => {
  const [rows] = await pool.query('SELECT * FROM jobs WHERE id = ?', [req.params.id]);
  const job = rows[0];
  if (!job) return res.status(404).json({ error: 'Job not found.' });
  if (job.created_by !== req.user.id) return res.status(403).json({ error: 'Not authorized to delete this job.' });

  await pool.query('DELETE FROM jobs WHERE id = ?', [req.params.id]);
  res.json({ ok: true });
}));

// HR: jobs they've posted. Plain (id, title) is used to populate the filter
// dropdown on the applications dashboard; ?full=1 returns everything needed
// for the "My Job Postings" management page, including applicant counts.
router.get('/mine/list', requireAuth, requireRole('hr'), catchAsync(async (req, res) => {
  if (req.query.full) {
    // Optional: ?search=  (title, description, department, skills; case-insensitive, partial)
    //           ?status=open|closed|draft   ?sort=newest|oldest|title|applicants
    const where = ['j.created_by = ?'];
    const params = [req.user.id];

    if (['open', 'closed', 'draft'].includes(req.query.status)) {
      where.push('j.status = ?');
      params.push(req.query.status);
    }

    const term = (req.query.search || '').toString().trim().slice(0, 100);
    if (term) {
      const like = `%${term.replace(/[\\%_]/g, '\\$&')}%`;
      where.push('(j.title LIKE ? OR j.description LIKE ? OR j.department LIKE ? OR j.required_skills LIKE ? OR j.preferred_skills LIKE ?)');
      params.push(like, like, like, like, like);
    }

    const orderBy = {
      newest: 'j.created_at DESC, j.id DESC',
      oldest: 'j.created_at ASC, j.id ASC',
      title: 'j.title ASC',
      applicants: 'application_count DESC, j.created_at DESC',
    }[req.query.sort] || 'j.created_at DESC, j.id DESC';

    const [rows] = await pool.query(
      `SELECT j.*, COUNT(a.id) AS application_count
       FROM jobs j LEFT JOIN applications a ON a.job_id = j.id
       WHERE ${where.join(' AND ')}
       GROUP BY j.id
       ORDER BY ${orderBy}`,
      params
    );
    return res.json(rows);
  }

  const [rows] = await pool.query(
    'SELECT id, title FROM jobs WHERE created_by = ? ORDER BY created_at DESC',
    [req.user.id]
  );
  res.json(rows);
}));

export default router;
