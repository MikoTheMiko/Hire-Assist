import express from 'express';
import fs from 'fs/promises';
import path from 'path';
import { pool } from '../db.js';
import { requireAuth, requireRole } from '../middleware/auth.js';
import { uploadResume } from '../middleware/upload.js';
import { extractResumeText, cleanResumeText } from '../services/resumeText.js';
import { runAiScreening } from '../services/aiScreening.js';
import { emitScreeningComplete, emitScreeningFailed, emitStatusChange } from '../socket.js';
import { cancelActiveSession } from '../services/interviewSessions.js';
import { catchAsync } from '../utils/catchAsync.js';

const router = express.Router();

// Statuses HR may pick from the status control. 'withdrawn' belongs to the applicant and
// 'archived' has its own archive / restore actions, so neither is settable here.
const HR_SETTABLE_STATUSES = ['submitted', 'screened', 'shortlisted', 'interview', 'offer', 'rejected'];
const UPLOAD_ROOT = path.resolve(process.cwd(), 'uploads');
const RESUME_MIME = {
  '.pdf': 'application/pdf',
  '.txt': 'text/plain; charset=utf-8',
  '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
};
// Browsers can display these types inline. Everything else is offered as a download.
const INLINE_RESUME_TYPES = new Set(['.pdf', '.txt']);

async function saveScreeningResult(applicationId, parsed) {
  await pool.query(
    `UPDATE applications SET
      ai_overall_score = ?, ai_skills_score = ?, ai_experience_score = ?, ai_education_score = ?,
      ai_strengths = ?, ai_gaps = ?, ai_matched_skills = ?, ai_missing_skills = ?,
      ai_summary = ?, ai_questions = ?, ai_raw_response = ?, ai_analyzed_at = NOW(), ai_error = NULL,
      status = IF(status = 'submitted', 'screened', status)
     WHERE id = ?`,
    [
      parsed.overall_score, parsed.skills_score, parsed.experience_score, parsed.education_score,
      JSON.stringify(parsed.strengths || []), JSON.stringify(parsed.gaps || []),
      JSON.stringify(parsed.matched_skills || []), JSON.stringify(parsed.missing_skills || []),
      parsed.summary, JSON.stringify(parsed.suggested_questions || []), parsed._raw || '',
      applicationId,
    ]
  );
}

// Deletes an uploaded resume that we decided not to keep (validation failed, insert failed...).
async function discardUpload(file) {
  if (!file?.path) return;
  try { await fs.unlink(file.path); } catch { /* already gone */ }
}

// Stores why screening failed so the UI shows a failure + retry instead of "Analyzing..." forever,
// and tells whoever is watching right now over the socket.
async function recordScreeningFailure(applicationId, message, applicantUserId, hrUserId) {
  const shortMessage = String(message || 'AI screening failed.').slice(0, 500);
  try {
    await pool.query('UPDATE applications SET ai_error = ? WHERE id = ?', [shortMessage, applicationId]);
  } catch (err) {
    console.error(`Could not record screening failure for application ${applicationId}:`, err);
  }
  emitScreeningFailed({ applicationId, error: shortMessage, applicantUserId, hrUserId });
}

// Fires the AI screening in the background and pushes the result over the socket
// the moment it's done — this is what lets the applicant/HR see the score appear
// live instead of waiting on the HTTP request. Never throws: every failure path
// ends in recordScreeningFailure so nobody is left waiting on a result that isn't coming.
async function runScreeningAsync(applicationId, job, resumeText, applicantUserId, hrUserId) {
  try {
    const result = await runAiScreening(job, resumeText);
    if (result.error) {
      console.error(`AI screening failed for application ${applicationId}:`, result.error);
      await recordScreeningFailure(applicationId, result.error, applicantUserId, hrUserId);
      return;
    }
    await saveScreeningResult(applicationId, result);
    emitScreeningComplete({ applicationId, result, applicantUserId, hrUserId });
  } catch (err) {
    console.error(`Screening crashed for application ${applicationId}:`, err);
    await recordScreeningFailure(applicationId, `Unexpected error: ${err.message}`, applicantUserId, hrUserId);
  }
}

// Applicant: submit an application
router.post('/', requireAuth, requireRole('applicant'), uploadResume.single('resume_file'), catchAsync(async (req, res) => {
  // multer has already written the file to disk by the time we get here, so every early
  // return below must discard it or rejected applications leave orphan files behind.
  const reject = async (status, error) => {
    await discardUpload(req.file);
    return res.status(status).json({ error });
  };

  const jobId = Number(req.body.job_id);
  const pastedText = cleanResumeText(req.body.resume_text);
  const expectedSalary = req.body.expected_salary === '' || req.body.expected_salary === undefined
    ? null : Number(req.body.expected_salary);
  const expectedSalaryType = expectedSalary !== null ? (req.body.expected_salary_type || 'Monthly') : null;

  if (expectedSalary !== null && (isNaN(expectedSalary) || expectedSalary < 0)) {
    return reject(400, 'Expected salary must be a positive number.');
  }
  if (!req.file && !pastedText) {
    return reject(400, 'Please upload a resume file or paste your resume text.');
  }

  const [jobs] = await pool.query('SELECT * FROM jobs WHERE id = ? AND status = "open"', [jobId]);
  const job = jobs[0];
  if (!job) return reject(404, 'This job is not available for applications.');

  const [existing] = await pool.query(
    'SELECT id FROM applications WHERE user_id = ? AND job_id = ?', [req.user.id, jobId]
  );
  if (existing.length > 0) return reject(409, 'You already applied to this job. You can find it under My Applications.');

  let resumePath = null;
  let resumeText = pastedText;

  if (req.file) {
    resumePath = `uploads/${req.file.filename}`;
    if (!pastedText) {
      let extractError = null;
      try {
        resumeText = await extractResumeText(req.file.path, req.file.originalname);
      } catch (err) {
        console.error('Resume extraction failed:', err);
        extractError = err;
      }
      // Refuse up front when the file can't be read, instead of saving an application that
      // can never be screened (e.g. a scanned/image-only PDF, a corrupt or password-protected file).
      if (extractError || !resumeText) {
        return reject(400, 'We could not read any text from that file. It may be a scanned or password-protected document. Please paste your resume text instead, or upload a text-based PDF, DOCX or TXT.');
      }
    }
  }

  let applicationId;
  try {
    const [result] = await pool.query(
      `INSERT INTO applications (user_id, job_id, resume_path, resume_text, expected_salary, expected_salary_type, status)
       VALUES (?, ?, ?, ?, ?, ?, 'submitted')`,
      [req.user.id, jobId, resumePath, resumeText, expectedSalary, expectedSalaryType]
    );
    applicationId = result.insertId;
  } catch (err) {
    // Double-click / two tabs racing past the duplicate check above: the unique key catches it.
    if (err.code === 'ER_DUP_ENTRY') return reject(409, 'You already applied to this job. You can find it under My Applications.');
    await discardUpload(req.file);
    throw err;
  }

  // Don't block the response on the AI call — respond immediately, screen in the background
  res.status(201).json({ id: applicationId, message: 'Application submitted. Analyzing your resume...' });
  runScreeningAsync(applicationId, job, resumeText, req.user.id, job.created_by);
}));

// Applicant: my applications
router.get('/mine', requireAuth, requireRole('applicant'), catchAsync(async (req, res) => {
  const [rows] = await pool.query(
    `SELECT a.*, j.title AS job_title, j.department, j.employment_type, j.salary_min, j.salary_max, j.salary_type,
        COALESCE((SELECT s.status FROM interview_sessions s WHERE s.application_id = a.id LIMIT 1), 'not_started') AS interview_status,
        (SELECT COUNT(*) FROM messages m WHERE m.application_id = a.id AND m.sender_id != ? AND m.is_read = 0) AS unread_count
     FROM applications a JOIN jobs j ON a.job_id = j.id
     WHERE a.user_id = ? ORDER BY a.created_at DESC`,
    [req.user.id, req.user.id]
  );
  res.json(rows);
}));

// HR: applications for jobs they posted, filterable + searchable.
// Query params (all optional, all combinable):
//   job_id, status            - exact filters (status=archived lists archived ones; they are hidden otherwise)
//   search                    - case-insensitive partial match on applicant name, email,
//                               job title, department, or AI-matched skills
//   min_score / max_score     - AI overall score range (inclusive)
//   unscored=1                - only applications the AI hasn't scored yet
router.get('/', requireAuth, requireRole('hr'), catchAsync(async (req, res) => {
  const { job_id, status, search, min_score, max_score, unscored } = req.query;
  let sql = `SELECT a.*, j.title AS job_title, u.name AS applicant_name, u.email AS applicant_email,
      (SELECT COUNT(*) FROM messages m WHERE m.application_id = a.id AND m.sender_id != ? AND m.is_read = 0) AS unread_count
    FROM applications a
    JOIN jobs j ON a.job_id = j.id
    JOIN users u ON a.user_id = u.id
    WHERE j.created_by = ?`;
  const params = [req.user.id, req.user.id];

  if (job_id) { sql += ' AND a.job_id = ?'; params.push(job_id); }
  if (status) { sql += ' AND a.status = ?'; params.push(status); }
  // Archived applications are removed from the active workspace unless HR asks for them.
  else { sql += " AND a.status <> 'archived'"; }

  const term = (search || '').toString().trim().slice(0, 100);
  if (term) {
    // Escape LIKE wildcards so "100%" or "a_b" are matched literally.
    const like = `%${term.replace(/[\\%_]/g, '\\$&')}%`;
    sql += ` AND (u.name LIKE ? OR u.email LIKE ? OR j.title LIKE ? OR j.department LIKE ? OR a.ai_matched_skills LIKE ?)`;
    params.push(like, like, like, like, like);
  }

  if (unscored === '1') {
    sql += ' AND a.ai_overall_score IS NULL';
  } else {
    if (min_score !== undefined && min_score !== '' && !isNaN(min_score)) { sql += ' AND a.ai_overall_score >= ?'; params.push(Number(min_score)); }
    if (max_score !== undefined && max_score !== '' && !isNaN(max_score)) { sql += ' AND a.ai_overall_score <= ?'; params.push(Number(max_score)); }
  }

  sql += ' ORDER BY a.ai_overall_score DESC, a.created_at DESC';

  const [rows] = await pool.query(sql, params);
  res.json(rows);
}));

// Get one application (applicant sees their own; HR sees any tied to their jobs)
router.get('/:id', requireAuth, catchAsync(async (req, res) => {
  const [rows] = await pool.query(
    `SELECT a.*, j.title AS job_title, j.department, j.created_by AS job_owner_id,
        j.salary_min AS job_salary_min, j.salary_max AS job_salary_max, j.salary_type AS job_salary_type,
        u.name AS applicant_name, u.email AS applicant_email
     FROM applications a JOIN jobs j ON a.job_id = j.id JOIN users u ON a.user_id = u.id
     WHERE a.id = ?`,
    [req.params.id]
  );
  const app = rows[0];
  if (!app) return res.status(404).json({ error: 'Application not found.' });

  const isOwnerApplicant = req.user.role === 'applicant' && app.user_id === req.user.id;
  const isOwnerHr = req.user.role === 'hr' && app.job_owner_id === req.user.id;
  if (!isOwnerApplicant && !isOwnerHr) return res.status(403).json({ error: 'Not authorized.' });

  res.json(app);
}));

// HR: update application status
router.patch('/:id/status', requireAuth, requireRole('hr'), catchAsync(async (req, res) => {
  const { status } = req.body;
  if (!HR_SETTABLE_STATUSES.includes(status)) return res.status(400).json({ error: 'Invalid status.' });

  const [rows] = await pool.query(
    `SELECT a.user_id, a.status, j.created_by FROM applications a JOIN jobs j ON a.job_id = j.id WHERE a.id = ?`,
    [req.params.id]
  );
  const app = rows[0];
  if (!app || app.created_by !== req.user.id) return res.status(404).json({ error: 'Application not found.' });
  if (app.status === 'withdrawn') return res.status(409).json({ error: 'The applicant withdrew this application, so its status can no longer be changed.' });
  if (app.status === 'archived') return res.status(409).json({ error: 'Restore this application before changing its status.' });

  await pool.query('UPDATE applications SET status = ? WHERE id = ?', [status, req.params.id]);
  emitStatusChange({ applicationId: Number(req.params.id), status, applicantUserId: app.user_id });
  res.json({ ok: true, status });
}));

// Applicant: withdraw their own application. The row and its history stay in the database,
// the status becomes 'withdrawn', and any live interview is cancelled.
router.post('/:id/withdraw', requireAuth, requireRole('applicant'), catchAsync(async (req, res) => {
  const [rows] = await pool.query(
    `SELECT a.id, a.user_id, a.status, j.created_by AS hr_user_id
     FROM applications a JOIN jobs j ON a.job_id = j.id WHERE a.id = ? AND a.user_id = ?`,
    [req.params.id, req.user.id]
  );
  const app = rows[0];
  if (!app) return res.status(404).json({ error: 'Application not found.' });
  if (app.status === 'withdrawn') return res.json({ ok: true, status: 'withdrawn' });

  await pool.query(
    `UPDATE applications SET
       previous_status = IF(status = 'archived', previous_status, status),
       status = 'withdrawn', withdrawn_at = NOW()
     WHERE id = ?`,
    [app.id]
  );
  await cancelActiveSession(app.id, 'application_withdrawn');

  // Applicant made this change themselves, so only HR gets the notification.
  emitStatusChange({ applicationId: app.id, status: 'withdrawn', hrUserId: app.hr_user_id });
  res.json({ ok: true, status: 'withdrawn' });
}));

// HR: remove an application from the active workspace. Nothing is deleted, the previous
// status is remembered so it can be restored, and any live interview is cancelled.
router.patch('/:id/archive', requireAuth, requireRole('hr'), catchAsync(async (req, res) => {
  const [rows] = await pool.query(
    `SELECT a.id, a.status FROM applications a JOIN jobs j ON a.job_id = j.id WHERE a.id = ? AND j.created_by = ?`,
    [req.params.id, req.user.id]
  );
  const app = rows[0];
  if (!app) return res.status(404).json({ error: 'Application not found.' });
  if (app.status === 'archived') return res.json({ ok: true, status: 'archived' });

  await pool.query(
    `UPDATE applications SET previous_status = status, status = 'archived', archived_at = NOW() WHERE id = ?`, [app.id]
  );
  await cancelActiveSession(app.id, 'application_archived');
  emitStatusChange({ applicationId: app.id, status: 'archived' }); // internal housekeeping: no bell for the applicant
  res.json({ ok: true, status: 'archived' });
}));

// HR: bring an archived application back to the status it had before.
router.patch('/:id/restore', requireAuth, requireRole('hr'), catchAsync(async (req, res) => {
  const [rows] = await pool.query(
    `SELECT a.id, a.status, a.previous_status FROM applications a JOIN jobs j ON a.job_id = j.id WHERE a.id = ? AND j.created_by = ?`,
    [req.params.id, req.user.id]
  );
  const app = rows[0];
  if (!app) return res.status(404).json({ error: 'Application not found.' });
  if (app.status !== 'archived') return res.status(409).json({ error: 'This application is not archived.' });

  const restored = app.previous_status && app.previous_status !== 'archived' ? app.previous_status : 'screened';
  await pool.query(
    `UPDATE applications SET status = ?, previous_status = NULL, archived_at = NULL WHERE id = ?`, [restored, app.id]
  );
  emitStatusChange({ applicationId: app.id, status: restored });
  res.json({ ok: true, status: restored });
}));

// HR: re-run AI screening
router.post('/:id/rerun-ai', requireAuth, requireRole('hr'), catchAsync(async (req, res) => {
  const [rows] = await pool.query(
    `SELECT a.*, j.* , a.id AS app_id, a.user_id AS applicant_user_id
     FROM applications a JOIN jobs j ON a.job_id = j.id WHERE a.id = ? AND j.created_by = ?`,
    [req.params.id, req.user.id]
  );
  const app = rows[0];
  if (!app) return res.status(404).json({ error: 'Application not found.' });
  if (!app.resume_text || !app.resume_text.trim()) {
    return res.status(400).json({ error: 'This application has no resume text to analyze.' });
  }

  await pool.query('UPDATE applications SET ai_error = NULL WHERE id = ?', [app.app_id]);
  res.json({ message: 'Re-analyzing...' });
  runScreeningAsync(app.app_id, app, app.resume_text, app.applicant_user_id, req.user.id);
}));

// Applicant: retry screening on their own application after it failed (no score yet and an
// error was recorded). Limited to that case so it can't be used to re-roll a score.
router.post('/:id/retry-screening', requireAuth, requireRole('applicant'), catchAsync(async (req, res) => {
  const [rows] = await pool.query(
    `SELECT a.*, j.*, a.id AS app_id, a.user_id AS applicant_user_id, j.created_by AS hr_user_id
     FROM applications a JOIN jobs j ON a.job_id = j.id WHERE a.id = ? AND a.user_id = ?`,
    [req.params.id, req.user.id]
  );
  const app = rows[0];
  if (!app) return res.status(404).json({ error: 'Application not found.' });
  if (app.ai_overall_score !== null || !app.ai_error) {
    return res.status(409).json({ error: 'This application does not need a screening retry.' });
  }
  if (!app.resume_text || !app.resume_text.trim()) {
    return res.status(400).json({ error: 'This application has no resume text to analyze.' });
  }

  await pool.query('UPDATE applications SET ai_error = NULL WHERE id = ?', [app.app_id]);
  res.json({ message: 'Retrying...' });
  runScreeningAsync(app.app_id, app, app.resume_text, req.user.id, app.hr_user_id);
}));

// Serve the resume file (auth-gated instead of a static public folder).
// The browser must send the Authorization header, so the client fetches this as a blob
// and opens it (a plain <a href> or window.open cannot attach the token). Add ?download=1
// to force a download. Only the applicant who owns the application and the HR user who
// owns the job can read it.
router.get('/:id/resume', requireAuth, catchAsync(async (req, res) => {
  const [rows] = await pool.query(
    `SELECT a.resume_path, a.user_id, j.created_by AS job_owner_id
     FROM applications a JOIN jobs j ON a.job_id = j.id WHERE a.id = ?`,
    [req.params.id]
  );
  const app = rows[0];
  if (!app || !app.resume_path) return res.status(404).json({ error: 'No resume file for this application.' });

  const isOwnerApplicant = req.user.role === 'applicant' && app.user_id === req.user.id;
  const isOwnerHr = req.user.role === 'hr' && app.job_owner_id === req.user.id;
  if (!isOwnerApplicant && !isOwnerHr) return res.status(403).json({ error: 'Not authorized.' });

  // Resolve and confirm the path stays inside uploads/ before touching the disk.
  const filePath = path.resolve(process.cwd(), app.resume_path);
  if (!filePath.startsWith(`${UPLOAD_ROOT}${path.sep}`)) return res.status(404).json({ error: 'File not found on server.' });

  try {
    await fs.access(filePath);
  } catch {
    return res.status(404).json({ error: 'File not found on server.' });
  }

  const ext = path.extname(filePath).toLowerCase();
  const asDownload = req.query.download === '1' || !INLINE_RESUME_TYPES.has(ext);
  // Stored as resume_<userId>_<timestamp>_<original name>; show the original name to people.
  const displayName = path.basename(filePath).replace(/^resume_\d+_\d+_/, '').replace(/"/g, '');

  res.set({
    'Content-Type': RESUME_MIME[ext] || 'application/octet-stream',
    'Content-Disposition': `${asDownload ? 'attachment' : 'inline'}; filename="${displayName}"`,
    'X-Content-Type-Options': 'nosniff',
    'Cache-Control': 'private, no-store',
    'Access-Control-Expose-Headers': 'Content-Disposition',
  });
  res.sendFile(filePath);
}));

export default router;
