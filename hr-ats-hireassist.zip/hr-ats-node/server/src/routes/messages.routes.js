import express from 'express';
import { pool } from '../db.js';
import { requireAuth, requireRole } from '../middleware/auth.js';
import { emitNewMessage } from '../socket.js';
import { catchAsync } from '../utils/catchAsync.js';

const router = express.Router();

async function getApplicationAccess(applicationId, user) {
  const [rows] = await pool.query(
    `SELECT a.user_id AS applicant_id, j.created_by AS hr_id
     FROM applications a JOIN jobs j ON a.job_id = j.id WHERE a.id = ?`,
    [applicationId]
  );
  const app = rows[0];
  if (!app) return null;

  const isApplicant = user.role === 'applicant' && user.id === app.applicant_id;
  const isHr = user.role === 'hr' && user.id === app.hr_id;
  if (!isApplicant && !isHr) return null;

  return { ...app, isApplicant, isHr };
}

// HR: conversation list for the Messages page — every application of theirs
// that has at least one message, newest activity first, with unread counts.
// Registered before '/:applicationId'.
router.get('/hr/conversations', requireAuth, catchAsync(async (req, res) => {
  if (req.user.role !== 'hr') return res.status(403).json({ error: 'Not authorized.' });
  const [rows] = await pool.query(
    `SELECT a.id AS application_id, a.status, u.name AS applicant_name, u.name AS counterpart_name, j.title AS job_title,
        lm.body AS last_body, lm.created_at AS last_at, lm.sender_id AS last_sender_id,
        (SELECT COUNT(*) FROM messages m WHERE m.application_id = a.id AND m.sender_id != ? AND m.is_read = 0) AS unread_count
     FROM applications a
     JOIN jobs j ON j.id = a.job_id
     JOIN users u ON u.id = a.user_id
     JOIN messages lm ON lm.id = (SELECT MAX(m2.id) FROM messages m2 WHERE m2.application_id = a.id)
     WHERE j.created_by = ?
     ORDER BY lm.created_at DESC, lm.id DESC`,
    [req.user.id, req.user.id]
  );
  res.json(rows);
}));

// Applicant: conversation list for their Messages page. Same shape as the HR list, but it
// includes every application they own (even with no messages yet) so they can start a
// conversation with the recruiter. Conversations with messages come first, newest activity on top.
router.get('/mine/conversations', requireAuth, requireRole('applicant'), catchAsync(async (req, res) => {
  const [rows] = await pool.query(
    `SELECT a.id AS application_id, a.status, hr.name AS counterpart_name, j.title AS job_title,
        lm.body AS last_body, lm.created_at AS last_at, lm.sender_id AS last_sender_id,
        (SELECT COUNT(*) FROM messages m WHERE m.application_id = a.id AND m.sender_id != ? AND m.is_read = 0) AS unread_count
     FROM applications a
     JOIN jobs j ON j.id = a.job_id
     JOIN users hr ON hr.id = j.created_by
     LEFT JOIN messages lm ON lm.id = (SELECT MAX(m2.id) FROM messages m2 WHERE m2.application_id = a.id)
     WHERE a.user_id = ?
     ORDER BY lm.created_at IS NULL, lm.created_at DESC, a.created_at DESC`,
    [req.user.id, req.user.id]
  );
  res.json(rows);
}));

// Total unread messages for the signed-in user (drives the badge on the Messages link).
// Scoped exactly like the thread access rules: an applicant's own applications, or an HR user's jobs.
router.get('/unread-count', requireAuth, catchAsync(async (req, res) => {
  const ownerColumn = req.user.role === 'hr' ? 'j.created_by' : 'a.user_id';
  const [[row]] = await pool.query(
    `SELECT COUNT(*) AS c FROM messages m
     JOIN applications a ON a.id = m.application_id
     JOIN jobs j ON j.id = a.job_id
     WHERE m.sender_id != ? AND m.is_read = 0 AND ${ownerColumn} = ?`,
    [req.user.id, req.user.id]
  );
  res.json({ count: Number(row.c) });
}));

// Get the message thread for an application, marking incoming messages as read
router.get('/:applicationId', requireAuth, catchAsync(async (req, res) => {
  const access = await getApplicationAccess(req.params.applicationId, req.user);
  if (!access) return res.status(403).json({ error: 'Not authorized.' });

  await pool.query(
    'UPDATE messages SET is_read = 1 WHERE application_id = ? AND sender_id != ?',
    [req.params.applicationId, req.user.id]
  );

  const [rows] = await pool.query(
    `SELECT m.*, u.name AS sender_name, u.role AS sender_role
     FROM messages m JOIN users u ON m.sender_id = u.id
     WHERE m.application_id = ? ORDER BY m.created_at ASC`,
    [req.params.applicationId]
  );
  res.json(rows);
}));

// Mark the incoming messages of a thread as read (used when a message arrives while the thread is open)
router.post('/:applicationId/read', requireAuth, catchAsync(async (req, res) => {
  const access = await getApplicationAccess(req.params.applicationId, req.user);
  if (!access) return res.status(403).json({ error: 'Not authorized.' });
  await pool.query(
    'UPDATE messages SET is_read = 1 WHERE application_id = ? AND sender_id != ?',
    [req.params.applicationId, req.user.id]
  );
  res.json({ ok: true });
}));

// Send a message on an application's thread
router.post('/:applicationId', requireAuth, catchAsync(async (req, res) => {
  const { body } = req.body;
  if (!body || !body.trim()) return res.status(400).json({ error: 'Message cannot be empty.' });

  const access = await getApplicationAccess(req.params.applicationId, req.user);
  if (!access) return res.status(403).json({ error: 'Not authorized.' });

  const [result] = await pool.query(
    'INSERT INTO messages (application_id, sender_id, body) VALUES (?, ?, ?)',
    [req.params.applicationId, req.user.id, body.trim()]
  );

  const message = {
    id: result.insertId,
    application_id: Number(req.params.applicationId),
    sender_id: req.user.id,
    sender_name: req.user.name,
    sender_role: req.user.role,
    body: body.trim(),
    created_at: new Date().toISOString(),
  };

  const recipientUserId = access.isApplicant ? access.hr_id : access.applicant_id;
  emitNewMessage({ applicationId: req.params.applicationId, message, recipientUserId });

  res.status(201).json(message);
}));

export default router;
