// CLIENT_URL may hold one origin or several, comma-separated, e.g.
//   CLIENT_URL=http://localhost:5173,http://127.0.0.1:5173,http://192.168.1.20:5173
// Read lazily (at call time) so it works regardless of when dotenv loads.
export function allowedOrigins() {
  const list = (process.env.CLIENT_URL || 'http://localhost:5173')
    .split(',')
    .map((s) => s.trim().replace(/\/$/, ''))
    .filter(Boolean);
  return list.length === 1 ? list[0] : list;
}
