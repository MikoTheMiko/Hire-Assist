// Express 4 doesn't automatically catch rejected promises from async route
// handlers. Left unwrapped, an error thrown inside one of them (e.g. a query
// against a table that doesn't exist yet) becomes an *unhandled promise
// rejection* - and since Node 15+, unhandled rejections crash the whole
// process by default. That takes down every other route with it, not just
// the one that errored.
//
// Wrap any async handler with this so its errors go to next(err) instead,
// which routes them to the centralized error handler in index.js and returns
// a normal JSON error response.
export function catchAsync(fn) {
  return (req, res, next) => {
    Promise.resolve(fn(req, res, next)).catch(next);
  };
}
