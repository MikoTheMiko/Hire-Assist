import multer from 'multer';
import path from 'path';
import fs from 'fs';

const uploadDir = path.join(process.cwd(), 'uploads');
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadDir),
  filename: (req, file, cb) => {
    const safeName = file.originalname.replace(/[^a-zA-Z0-9._-]/g, '_');
    cb(null, `resume_${req.user.id}_${Date.now()}_${safeName}`);
  },
});

const allowedExt = ['.pdf', '.docx', '.txt'];

export const uploadResume = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB
  fileFilter: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    if (!allowedExt.includes(ext)) {
      // status 400 so the central error handler reports a client error, not a 500
      const err = new Error('Only PDF, DOCX, or TXT files are allowed.');
      err.status = 400;
      return cb(err);
    }
    cb(null, true);
  },
});
