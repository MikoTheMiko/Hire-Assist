import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import { createServer } from 'http';
import multer from 'multer';
import { allowedOrigins } from './utils/origins.js';
import { initSocket } from './socket.js';
import { ensureSchema } from './db.js';
import { startInterviewSweeper } from './services/interviewSessions.js';

import authRoutes from './routes/auth.routes.js';
import jobsRoutes from './routes/jobs.routes.js';
import applicationsRoutes from './routes/applications.routes.js';
import messagesRoutes from './routes/messages.routes.js';
import interviewsRoutes from './routes/interviews.routes.js';
import dashboardRoutes from './routes/dashboard.routes.js';

dotenv.config();

// Last-resort safety net: if anything anywhere throws outside of a route
// handler's control (or a wrapped handler still slips through), log it
// instead of letting Node's default behavior (crashing the process on an
// unhandled rejection) take the whole API + WebSocket server down.
process.on('unhandledRejection', (err) => {
  console.error('Unhandled promise rejection (server kept running):', err);
});
process.on('uncaughtException', (err) => {
  console.error('Uncaught exception (server kept running):', err);
});

const app = express();
app.use(cors({ origin: allowedOrigins(), credentials: true }));
app.use(express.json());

app.use('/api/auth', authRoutes);
app.use('/api/jobs', jobsRoutes);
app.use('/api/applications', applicationsRoutes);
app.use('/api/messages', messagesRoutes);
app.use('/api/interviews', interviewsRoutes);
app.use('/api/dashboard', dashboardRoutes);

app.get('/api/health', (req, res) => res.json({ ok: true }));

// Central error handler - catches multer errors, unhandled route errors, etc.
app.use((err, req, res, next) => {
  console.error(err);
  if (res.headersSent) return next(err);

  // Upload problems are the user's to fix, so report them as 400s with a readable message.
  if (err instanceof multer.MulterError) {
    const message = err.code === 'LIMIT_FILE_SIZE' ? 'That file is larger than 5 MB.' : `Upload problem: ${err.message}`;
    return res.status(400).json({ error: message });
  }
  res.status(err.status || 500).json({ error: err.message || 'Something went wrong.' });
});

const httpServer = createServer(app);
initSocket(httpServer);

const PORT = process.env.PORT || 4000;

// If the port can't be bound (usually: another copy of the server, or the old PHP app, is
// already on it) the process used to stay alive but serve nothing, because the
// uncaughtException handler above swallowed the error - the browser then saw
// ERR_CONNECTION_REFUSED with no hint why. Fail loudly and exit instead.
httpServer.on('error', (err) => {
  if (err.code === 'EADDRINUSE') {
    console.error(`Port ${PORT} is already in use. Stop the other process, or set a different PORT in .env.`);
  } else {
    console.error('Server failed to start:', err);
  }
  process.exit(1);
});

httpServer.listen(PORT, () => {
  console.log(`API + WebSocket server running on http://localhost:${PORT}`);
  ensureSchema();
  startInterviewSweeper(); // closes interviews whose 20 minute timer ran out
});
