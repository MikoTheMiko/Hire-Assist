import mysql from 'mysql2/promise';
import dotenv from 'dotenv';
dotenv.config();

export const pool = mysql.createPool({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  port: process.env.DB_PORT || 3306,
  waitForConnections: true,
  connectionLimit: 10,
});

// Brings an existing database up to date with columns the code now relies on, so a missed
// migration can't break application submission. (schema.sql / migrations/ stay the source of truth.)
export async function ensureSchema() {
  try {
    const [rows] = await pool.query(
      `SELECT COUNT(*) AS n FROM information_schema.COLUMNS
       WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'applications' AND COLUMN_NAME = 'ai_error'`
    );
    if (rows[0].n === 0) {
      await pool.query(
        `ALTER TABLE applications ADD COLUMN ai_error VARCHAR(500) DEFAULT NULL AFTER ai_analyzed_at`
      );
      console.log('Added missing column applications.ai_error (migration 006).');
    }
  } catch (err) {
    console.error('Could not verify the database schema. Is MySQL running and is DB_NAME correct?', err.message);
  }
}
