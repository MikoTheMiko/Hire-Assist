import { Server } from 'socket.io';
import jwt from 'jsonwebtoken';
import { allowedOrigins } from './utils/origins.js';

let io;

export function initSocket(httpServer) {
  io = new Server(httpServer, {
    cors: { origin: allowedOrigins(), credentials: true },
  });

  // Authenticate the socket connection using the same JWT as the REST API
  io.use((socket, next) => {
    const token = socket.handshake.auth?.token;
    if (!token) return next(new Error('Not authenticated'));
    try {
      const payload = jwt.verify(token, process.env.JWT_SECRET);
      socket.user = payload;
      next();
    } catch {
      next(new Error('Invalid session'));
    }
  });

  io.on('connection', (socket) => {
    // Every user gets a personal room for notifications addressed to them
    socket.join(`user:${socket.user.id}`);

    // Client asks to join a specific application's chat thread when they open it
    socket.on('application:join', (applicationId) => {
      socket.join(`application:${applicationId}`);
    });

    socket.on('application:leave', (applicationId) => {
      socket.leave(`application:${applicationId}`);
    });
  });

  return io;
}

export function getIo() {
  if (!io) throw new Error('Socket.io not initialized yet.');
  return io;
}

// Helper: broadcast a new message to everyone viewing that application's thread,
// plus a lightweight notification to the recipient's personal room (for badges
// even when they're not currently looking at that thread).
export function emitNewMessage({ applicationId, message, recipientUserId }) {
  getIo().to(`application:${applicationId}`).emit('message:new', message);
  getIo().to(`user:${recipientUserId}`).emit('notification', {
    type: 'message',
    applicationId,
    preview: message.body.slice(0, 80),
  });
}

// Room event keeps any open application page in sync. Pass applicantUserId and/or
// hrUserId to also drop a bell notification for that person (leave one out when
// they are the one who made the change, or when it is internal housekeeping).
export function emitStatusChange({ applicationId, status, applicantUserId, hrUserId }) {
  getIo().to(`application:${applicationId}`).emit('application:status', { applicationId, status });
  const notification = { type: 'status', applicationId, status };
  if (applicantUserId) getIo().to(`user:${applicantUserId}`).emit('notification', notification);
  if (hrUserId) getIo().to(`user:${hrUserId}`).emit('notification', notification);
}

export function emitScreeningComplete({ applicationId, result, applicantUserId, hrUserId }) {
  const payload = { applicationId, result };
  getIo().to(`user:${applicantUserId}`).emit('screening:complete', payload);
  getIo().to(`user:${hrUserId}`).emit('screening:complete', payload);
}

export function emitScreeningFailed({ applicationId, error, applicantUserId, hrUserId }) {
  const payload = { applicationId, error };
  if (applicantUserId) getIo().to(`user:${applicantUserId}`).emit('screening:failed', payload);
  if (hrUserId) getIo().to(`user:${hrUserId}`).emit('screening:failed', payload);
}

// Interview flow: applicant starts a session, answers questions one at a
// time, and everyone watching that application's page (applicant + HR, both
// already in the `application:<id>` room) sees each turn live.
export function emitInterviewStarted({ applicationId, session }) {
  getIo().to(`application:${applicationId}`).emit('interview:started', { applicationId, session });
}

export function emitInterviewTurn({ applicationId, turn }) {
  getIo().to(`application:${applicationId}`).emit('interview:turn', { applicationId, turn });
}

export function emitInterviewReportReady({ applicationId, report, applicantUserId, hrUserId }) {
  const payload = { applicationId, report };
  getIo().to(`application:${applicationId}`).emit('interview:report_ready', payload);
  getIo().to(`user:${applicantUserId}`).emit('notification', {
    type: 'interview_report',
    applicationId,
  });
  getIo().to(`user:${hrUserId}`).emit('notification', {
    type: 'interview_report',
    applicationId,
  });
}

// Interview reached a terminal state (completed, timed_out or cancelled). The application
// room gets the status change live. HR is always notified. The applicant is only notified
// when the timer ran out while they were away (they already know about the other cases).
export function emitInterviewStatus({ applicationId, status, reason, applicantUserId, hrUserId }) {
  getIo().to(`application:${applicationId}`).emit('interview:status', { applicationId, status, reason });
  const notification = { type: 'interview_status', applicationId, status, reason };
  if (hrUserId) getIo().to(`user:${hrUserId}`).emit('notification', notification);
  if (applicantUserId && reason === 'time_expired') getIo().to(`user:${applicantUserId}`).emit('notification', notification);
}
