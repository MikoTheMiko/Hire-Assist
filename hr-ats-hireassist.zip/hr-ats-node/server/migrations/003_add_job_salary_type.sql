-- Run this against an existing hr_ats database to add a salary period to
-- job postings' estimated salary range:
--   mysql -u root -p hr_ats < server/migrations/003_add_job_salary_type.sql
-- (New installs don't need this — it's already included in schema.sql.)

USE hr_ats;

ALTER TABLE jobs
  ADD COLUMN salary_type ENUM('Monthly','Annual') DEFAULT 'Monthly'
    COMMENT 'Period the salary_min/salary_max figures are quoted in'
    AFTER salary_max;
