-- Run this against an existing hr_ats database to add the live AI
-- technical-interview feature without losing any existing data:
--   mysql -u root -p hr_ats < server/migrations/001_add_interview_sessions.sql
-- (New installs don't need this — it's already included in schema.sql.)

USE hr_ats;

-- One row per application: the generated question set, progress, and the
-- final Technical Assessment Report once the interview is complete.
CREATE TABLE IF NOT EXISTS interview_sessions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    application_id INT NOT NULL,
    status ENUM('in_progress', 'completed') NOT NULL DEFAULT 'in_progress',
    questions TEXT NOT NULL COMMENT 'JSON array of {question, focus_area}, generated once at session start',
    current_index INT NOT NULL DEFAULT 0,

    -- Final AI-generated Technical Assessment Report (populated when status = completed)
    report_technical_score INT DEFAULT NULL,
    report_communication_score INT DEFAULT NULL,
    report_strengths TEXT DEFAULT NULL,
    report_weaknesses TEXT DEFAULT NULL,
    report_recommendation VARCHAR(30) DEFAULT NULL,
    report_summary TEXT DEFAULT NULL,

    started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_at DATETIME DEFAULT NULL,

    UNIQUE KEY unique_session_per_application (application_id),
    FOREIGN KEY (application_id) REFERENCES applications(id) ON DELETE CASCADE
);

-- One row per question asked + answered + AI-evaluated.
CREATE TABLE IF NOT EXISTS interview_answers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    session_id INT NOT NULL,
    question_index INT NOT NULL,
    question TEXT NOT NULL,
    focus_area VARCHAR(150) DEFAULT NULL,
    answer TEXT NOT NULL,
    eval_score INT DEFAULT NULL COMMENT 'AI-assigned 0-100 score for this specific answer',
    eval_feedback TEXT DEFAULT NULL,
    answered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (session_id) REFERENCES interview_sessions(id) ON DELETE CASCADE
);
