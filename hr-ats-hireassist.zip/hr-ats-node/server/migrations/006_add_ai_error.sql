-- Records why AI screening failed so the UI can say so (and offer a retry)
-- instead of showing "Analyzing..." forever.
--
-- Run ONCE against an existing hr_ats database:
--   mysql -u root -p hr_ats < server/migrations/006_add_ai_error.sql
-- (New installs don't need this, it is already included in schema.sql.)

USE hr_ats;

ALTER TABLE applications
  ADD COLUMN ai_error VARCHAR(500) DEFAULT NULL COMMENT 'Last AI screening failure, NULL when screening succeeded or is still running' AFTER ai_analyzed_at;
