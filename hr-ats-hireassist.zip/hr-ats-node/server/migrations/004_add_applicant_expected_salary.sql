-- Run this against an existing hr_ats database to add the applicant's own
-- expected salary to applications (separate from the job's HR-set budget
-- range in jobs.salary_min/salary_max):
--   mysql -u root -p hr_ats < server/migrations/004_add_applicant_expected_salary.sql
-- (New installs don't need this — it's already included in schema.sql.)

USE hr_ats;

ALTER TABLE applications
  ADD COLUMN expected_salary INT DEFAULT NULL
    COMMENT 'Applicant-stated expected salary - their own figure, separate from the job''s budget range'
    AFTER resume_text,
  ADD COLUMN expected_salary_type ENUM('Monthly','Annual') DEFAULT NULL
    COMMENT 'Period expected_salary is quoted in'
    AFTER expected_salary;
