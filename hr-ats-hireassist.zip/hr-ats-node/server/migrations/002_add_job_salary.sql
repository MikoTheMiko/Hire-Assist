-- Run this against an existing hr_ats database to add an optional estimated
-- salary range to job postings:
--   mysql -u root -p hr_ats < server/migrations/002_add_job_salary.sql
-- (New installs don't need this — it's already included in schema.sql.)

USE hr_ats;

ALTER TABLE jobs
  ADD COLUMN salary_min INT DEFAULT NULL COMMENT 'Optional estimated annual salary range (min)' AFTER education_requirement,
  ADD COLUMN salary_max INT DEFAULT NULL COMMENT 'Optional estimated annual salary range (max)' AFTER salary_min;
