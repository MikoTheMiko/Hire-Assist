-- Interview timer, richer interview statuses, skipped questions, and
-- application withdraw / archive support.
--
-- Run ONCE against an existing hr_ats database:
--   mysql -u root -p hr_ats < server/migrations/005_interview_timer_and_application_lifecycle.sql
-- (New installs don't need this, it is already included in schema.sql.)

USE hr_ats;

-- ---------- Interview sessions ----------
-- status is now: not_started | in_progress | completed | timed_out | cancelled
-- ("not_started" is what the API reports when no session row exists yet.)
-- completed_at is reused as "ended at" for every terminal status.
ALTER TABLE interview_sessions
  MODIFY COLUMN status ENUM('not_started', 'in_progress', 'completed', 'timed_out', 'cancelled') NOT NULL DEFAULT 'in_progress',
  ADD COLUMN duration_seconds INT NOT NULL DEFAULT 1200 COMMENT 'Total time allowed for the whole interview (20 minutes)',
  ADD COLUMN expires_at DATETIME DEFAULT NULL COMMENT 'Hard deadline, set when the session starts',
  ADD COLUMN ended_reason VARCHAR(30) DEFAULT NULL COMMENT 'all_answered | time_expired | user_cancelled | application_withdrawn | application_archived';

-- Sessions that were already running get a fresh 20 minutes from now, so the
-- migration never instantly times out somebody's interview.
UPDATE interview_sessions
   SET expires_at = DATE_ADD(NOW(), INTERVAL duration_seconds SECOND)
 WHERE status = 'in_progress' AND expires_at IS NULL;

-- ---------- Interview answers ----------
-- A skipped question is stored with an empty answer and skipped = 1 (no AI score),
-- so it is recorded as "unanswered" rather than as a technical failure.
ALTER TABLE interview_answers
  ADD COLUMN skipped TINYINT(1) NOT NULL DEFAULT 0 AFTER answer,
  ADD UNIQUE KEY unique_answer_per_question (session_id, question_index);

-- ---------- Applications ----------
-- withdrawn: the applicant withdrew. archived: HR removed it from the active workspace.
-- Nothing is deleted; previous_status lets HR restore an archived application.
ALTER TABLE applications
  MODIFY COLUMN status ENUM('submitted', 'screened', 'shortlisted', 'interview', 'offer', 'rejected', 'withdrawn', 'archived') NOT NULL DEFAULT 'submitted',
  ADD COLUMN previous_status VARCHAR(20) DEFAULT NULL,
  ADD COLUMN withdrawn_at DATETIME DEFAULT NULL,
  ADD COLUMN archived_at DATETIME DEFAULT NULL;
