-- ============================================
-- HR-Applicant Communication & Screening System
-- ============================================

CREATE DATABASE IF NOT EXISTS hr_ats CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE hr_ats;

-- ---------- Users (applicants & HR) ----------
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('applicant', 'hr') NOT NULL DEFAULT 'applicant',
    desired_position VARCHAR(150) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ---------- Jobs / Positions ----------
CREATE TABLE jobs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(150) NOT NULL,
    department VARCHAR(100) DEFAULT NULL,
    seniority_level ENUM('Junior','Mid','Senior','Lead') DEFAULT 'Mid',
    employment_type ENUM('Full-time','Part-time','Contract','Internship') DEFAULT 'Full-time',
    description TEXT NOT NULL,
    required_skills TEXT COMMENT 'Comma-separated',
    preferred_skills TEXT COMMENT 'Comma-separated',
    min_years_experience INT DEFAULT 0,
    education_requirement VARCHAR(150) DEFAULT NULL,
    salary_min INT DEFAULT NULL COMMENT 'Optional estimated salary range (min) - HR-provided job budget',
    salary_max INT DEFAULT NULL COMMENT 'Optional estimated salary range (max) - HR-provided job budget',
    salary_type ENUM('Monthly','Annual') DEFAULT 'Monthly' COMMENT 'Period the salary_min/salary_max figures are quoted in',
    status ENUM('open','closed','draft') NOT NULL DEFAULT 'open',
    created_by INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE CASCADE
);

-- ---------- Applications ----------
CREATE TABLE applications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    job_id INT NOT NULL,
    resume_path VARCHAR(255) DEFAULT NULL,
    resume_text MEDIUMTEXT DEFAULT NULL COMMENT 'Plain text used for AI analysis',
    expected_salary INT DEFAULT NULL COMMENT 'Applicant-stated expected salary - their own figure, separate from the job''s budget range',
    expected_salary_type ENUM('Monthly','Annual') DEFAULT NULL COMMENT 'Period expected_salary is quoted in',
    status ENUM('submitted','screened','shortlisted','interview','offer','rejected','withdrawn','archived') NOT NULL DEFAULT 'submitted',
    previous_status VARCHAR(20) DEFAULT NULL COMMENT 'Status before the application was archived',
    withdrawn_at DATETIME DEFAULT NULL,
    archived_at DATETIME DEFAULT NULL,

    -- AI screening output
    ai_overall_score INT DEFAULT NULL,
    ai_skills_score INT DEFAULT NULL,
    ai_experience_score INT DEFAULT NULL,
    ai_education_score INT DEFAULT NULL,
    ai_strengths TEXT DEFAULT NULL,
    ai_gaps TEXT DEFAULT NULL,
    ai_matched_skills TEXT DEFAULT NULL,
    ai_missing_skills TEXT DEFAULT NULL,
    ai_summary TEXT DEFAULT NULL,
    ai_questions TEXT DEFAULT NULL COMMENT 'JSON array of {question, reason}',
    ai_raw_response MEDIUMTEXT DEFAULT NULL,
    ai_analyzed_at DATETIME DEFAULT NULL,
    ai_error VARCHAR(500) DEFAULT NULL COMMENT 'Last AI screening failure, NULL when screening succeeded or is still running',

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_application (user_id, job_id),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (job_id) REFERENCES jobs(id) ON DELETE CASCADE
);

-- ---------- Interview Sessions (AI-conducted live technical interview) ----------
-- One row per application: the generated question set, progress, and the
-- final Technical Assessment Report once the interview is complete.
CREATE TABLE interview_sessions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    application_id INT NOT NULL,
    status ENUM('not_started', 'in_progress', 'completed', 'timed_out', 'cancelled') NOT NULL DEFAULT 'in_progress',
    questions TEXT NOT NULL COMMENT 'JSON array of {question, focus_area}, generated once at session start',
    duration_seconds INT NOT NULL DEFAULT 1200 COMMENT 'Total time allowed for the whole interview (20 minutes)',
    expires_at DATETIME DEFAULT NULL COMMENT 'Hard deadline, set when the session starts',
    ended_reason VARCHAR(30) DEFAULT NULL COMMENT 'all_answered | time_expired | user_cancelled | application_withdrawn | application_archived',
    current_index INT NOT NULL DEFAULT 0,

    -- Final AI-generated Technical Assessment Report (populated when status = completed)
    report_technical_score INT DEFAULT NULL,
    report_communication_score INT DEFAULT NULL,
    report_strengths TEXT DEFAULT NULL,
    report_weaknesses TEXT DEFAULT NULL,
    report_recommendation VARCHAR(30) DEFAULT NULL,
    report_summary TEXT DEFAULT NULL,

    started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_at DATETIME DEFAULT NULL COMMENT 'When the session ended (any terminal status)',

    UNIQUE KEY unique_session_per_application (application_id),
    FOREIGN KEY (application_id) REFERENCES applications(id) ON DELETE CASCADE
);

-- ---------- Interview Answers (one row per question asked/answered/evaluated) ----------
CREATE TABLE interview_answers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    session_id INT NOT NULL,
    question_index INT NOT NULL,
    question TEXT NOT NULL,
    focus_area VARCHAR(150) DEFAULT NULL,
    answer TEXT NOT NULL,
    skipped TINYINT(1) NOT NULL DEFAULT 0 COMMENT 'Skipped questions have an empty answer and no AI score',
    eval_score INT DEFAULT NULL COMMENT 'AI-assigned 0-100 score for this specific answer',
    eval_feedback TEXT DEFAULT NULL,
    answered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    UNIQUE KEY unique_answer_per_question (session_id, question_index),
    FOREIGN KEY (session_id) REFERENCES interview_sessions(id) ON DELETE CASCADE
);

-- ---------- Messages (HR <-> Applicant, per application) ----------
CREATE TABLE messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    application_id INT NOT NULL,
    sender_id INT NOT NULL,
    body TEXT NOT NULL,
    is_read TINYINT(1) NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (application_id) REFERENCES applications(id) ON DELETE CASCADE,
    FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ---------- Seed: first HR account ----------
-- Do NOT hardcode a password hash here. After importing this schema, visit
-- create_admin.php once in your browser to create the first HR account
-- with a properly generated bcrypt hash, then delete that file.
