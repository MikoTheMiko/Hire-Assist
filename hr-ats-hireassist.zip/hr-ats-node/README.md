# HireAssist — Node + React (Real-Time) Version

This is a full rewrite of the PHP version using **Node.js + Express + Socket.io** on the backend and **React (Vite)** on the frontend. Same MySQL database and schema — the AI screening, messaging, and job/application logic all carry over, but now everything updates live over a WebSocket instead of full-page reloads.

## What's different from the PHP version

- No page reloads — React swaps pages in and out instantly (a **Single Page App**)
- **Real-time**: new chat messages, AI screening results, and status changes appear the instant they happen, on both the applicant's and HR's screen, via Socket.io
- A notification bell in the nav bar shows live updates even when you're not on that page
- Auth uses JWT tokens instead of PHP sessions (needed since the frontend and backend are now separate apps)

## Project structure

```
hr-ats-node/
├── server/              # Node/Express API + Socket.io
│   ├── src/
│   │   ├── index.js      # main entry point
│   │   ├── db.js         # MySQL connection pool
│   │   ├── socket.js     # WebSocket setup + real-time event helpers
│   │   ├── middleware/    # JWT auth, file upload handling
│   │   ├── routes/        # auth, jobs, applications, messages
│   │   └── services/      # AI screening (OpenRouter/Gemini), resume text extraction
│   ├── schema.sql        # same schema as the PHP version
│   └── .env.example
└── client/              # React (Vite) frontend
    └── src/
        ├── context/       # AuthContext (login state), SocketContext (WebSocket)
        ├── components/    # Navbar, ChatThread, ScoreDial, StatusBadge, ProtectedRoute
        └── pages/         # one component per "page"
```

## Setup

### 1. Database
Same as before — if you already have the `hr_ats` database from the PHP version, **you can reuse it as-is**, nothing needs to change. Otherwise:
```bash
mysql -u root -p < server/schema.sql
```

### 2. Backend
```bash
cd server
npm install
cp .env.example .env
```
Edit `.env` with your DB credentials and AI API key (same values as `config.php` had). Then:
```bash
npm run dev
```
This starts the API + WebSocket server on `http://localhost:4000`. `npm run dev` uses Node's built-in `--watch` flag, so it restarts automatically when you edit a file.

### 3. Frontend
In a **second terminal**:
```bash
cd client
npm install
npm run dev
```
This starts the React dev server on `http://localhost:5173`. Open that URL in your browser.

You need **both terminals running at once** — the React app (port 5173) talks to the API (port 4000).

## A few React basics, since you're new to it

- **Components** are just JavaScript functions that return HTML-like syntax called JSX. Every file in `src/pages/` and `src/components/` is one component.
- **`useState`** holds a piece of data that can change (like the list of applications) and re-renders the page automatically when it changes.
- **`useEffect`** runs code when a component first appears (e.g. "fetch this data when the page loads") or when something specific changes.
- **Context** (`AuthContext.jsx`, `SocketContext.jsx`) is how "who's logged in" and "the WebSocket connection" are shared across the whole app without passing them through every component manually.
- Nothing here needs a build step while you're developing — Vite's dev server (`npm run dev`) handles it live. You only run `npm run build` when you're ready to deploy.

I left comments in the trickier files (`AuthContext.jsx`, `SocketContext.jsx`, `ChatThread.jsx`, `App.jsx`) explaining what's happening — those four are the best starting point for understanding how the pieces fit together.


## HR dashboard & redesign (analytics, search, new HR pages)

The HR area has a dark "AI recruitment SaaS" look (tokens in `client/tailwind.config.js`, components in `client/src/styles.css`) and a real analytics dashboard at `/hr/dashboard`.

**HR routes**

| Route | Page |
|---|---|
| `/hr/dashboard` | Analytics dashboard (was the applications list) |
| `/hr/applications` | Applications list — search + status/job/score filters (`?status=` / `?job=` deep-links work) |
| `/hr/jobs` | Jobs — search, status filter, sort |
| `/hr/interviews` | All AI interview sessions |
| `/hr/messages` | Conversation inbox + live chat |
| `/hr/applications/:id`, `/hr/post-job`, `/hr/jobs/:id/edit` | unchanged |

**New API endpoints** (all HR-only, scoped to the logged-in HR user's own jobs, computed with SQL aggregation)

- `GET /api/dashboard/stats`
- `GET /api/dashboard/applications-over-time?range=7d|30d|6m`
- `GET /api/dashboard/pipeline`
- `GET /api/dashboard/jobs-performance?limit=`
- `GET /api/dashboard/screening-distribution`
- `GET /api/dashboard/interview-performance`
- `GET /api/dashboard/recent-applications`, `GET /api/dashboard/recent-interviews`
- `GET /api/interviews/hr/list?status=&search=`
- `GET /api/messages/hr/conversations`

**Extended (backwards compatible) endpoints**

- `GET /api/applications` now also accepts `search` (name, email, job title, department, matched skills), `min_score`, `max_score`, `unscored=1`. Still returns a plain array.
- `GET /api/jobs/mine/list?full=1` now also accepts `search` (title, description, department, skills), `status`, `sort=newest|oldest|title|applicants`.

**Database:** no schema changes or migrations. **New dependencies:** none (charts are small SVG/CSS components in `client/src/components/charts/`).

Note on data: there is no "hired" status or status-change timestamp in the schema, so the KPI is **Offers** (status = `offer`) and it has no period-over-period trend; application and interview KPIs compare the last 30 days with the 30 days before.

## AI Technical Interview flow

Applications now go through a live, AI-conducted technical interview instead of
just a static resume screening:

```
Applicant
   ↓
Starts Interview Session          POST /api/interviews/:applicationId/start
   ↓
AI analyzes Resume + Job Requirements
   ↓
AI generates 5 personalized technical questions
   ↓
AI asks Question 1                 (first question comes back from /start)
   ↓
Applicant answers                  POST /api/interviews/:applicationId/answer
   ↓
AI evaluates answer                 (score + feedback saved per answer)
   ↓
AI asks Question 2 ... (repeats until all questions are answered)
   ↓
Interview Completed                 (session marked completed)
   ↓
AI generates Technical Assessment Report   (generated in the background, pushed
   ↓                                        live over the socket when ready)
HR Reviews Results                  (HrApplicationView shows report + full transcript)
   ↓
Final HR Decision                   (existing status dropdown: shortlisted/offer/rejected)
```

**New pieces:**
- `server/src/services/interviewAi.js` — generates the question set, grades each answer, and compiles the final report. Shares its AI-provider plumbing with resume screening via the new `server/src/services/aiClient.js`.
- `server/src/routes/interviews.routes.js` — `GET/POST /api/interviews/...`
- `interview_sessions` / `interview_answers` tables (see `server/schema.sql`; if you already have a database, run `server/migrations/001_add_interview_sessions.sql` against it instead of re-importing the whole schema).
- `jobs.salary_min` / `jobs.salary_max` columns for the optional estimated salary range (if you already have a database, run `server/migrations/002_add_job_salary.sql` against it instead of re-importing the whole schema).
- `jobs.salary_type` column (Monthly/Annual) for that range (`server/migrations/003_add_job_salary_type.sql`).
- `applications.expected_salary` / `applications.expected_salary_type` columns for the applicant's own stated expectation (`server/migrations/004_add_applicant_expected_salary.sql`).
- `client/src/pages/Interview.jsx` — the applicant's one-question-at-a-time chat UI (linked from `ApplicantApplicationView`).
- `HrApplicationView.jsx` now shows the live interview transcript as it happens and the final report once it's ready, via the same `application:<id>` socket room the chat thread already uses.

The old "suggested_questions" from the initial AI resume screening are still generated and shown to HR as a reference, but they're no longer just a static list — the interview flow now actually asks a fresh, tailored question set and scores the candidate's real answers.

## How the real-time flow actually works

1. Browser connects to the server over a WebSocket (Socket.io) right after login, authenticated with the same JWT used for regular API calls.
2. Each user joins a personal room (`user:<id>`) — this is what powers the notification bell, even for pages they're not currently viewing.
3. When you open a specific application's page, the browser also joins an `application:<id>` room — this is what makes the chat thread update live for both people in it.
4. When someone sends a message, changes a status, or the AI finishes screening a resume, the server emits an event into the relevant room(s), and every connected browser in that room updates instantly — no polling, no refresh.

## Deploying later

For production, you'd build the React app (`npm run build` in `client/`, which outputs static files) and serve those from a static host or from Express itself, while the `server/` API+socket process runs continuously (e.g. on a VPS, Render, Railway, or similar — this can't run on typical shared PHP/cPanel hosting the way the old version could, since it needs a persistent Node process for WebSockets).

---

## Redesign notes

**Theme.** One light theme for the whole app (public, applicant and HR) — no dark mode, no switcher. Colours are CSS variables in `client/src/styles.css`; Tailwind class names read them. Background is `#F8FAFC` with a very subtle indigo/violet/blue ambient glow on a fixed `body::before` layer; the landing hero has a slightly stronger glow, and the How-it-works / AI sections have faint tints. Cards are solid white with a subtle border and soft shadow.

**Brand.** HireAssist — logo in `client/src/components/ui/Logo.jsx` (indigo rounded square, white H, small spark) and `client/public/favicon.svg`.

**Typography.** Space Grotesk removed. Inter (400–800) everywhere; bold headings, tight tracking.

**Rating rings.** `components/ratings/RatingRing.jsx` — SVG, round caps, stroke ≈ 17% of diameter, one clockwise sweep (1200 ms, `cubic-bezier(0.16,1,0.3,1)`) + number count-up when scrolled into view, instant under `prefers-reduced-motion`. `ScoreDial` now wraps it, so every existing call site (HR + applicant) uses it.

**New / reorganised frontend files**
- `components/layout/` Navbar, PublicLayout · `components/forms/SearchBar` · `components/cards/` JobCard, ApplicationCard, HeroPreview · `components/ratings/RatingRing` · `components/ui/ProgressBar`
- `styles/` ring.css, nav.css, landing.css, applicant.css (plain CSS, one file per area)
- Pages redesigned: JobsList (landing + working search), JobDetail, Apply, ApplicantDashboard, Login, Register, Interview (polish only — logic untouched)

**Backend changes (additive, backwards-compatible)**
- `GET /api/jobs?q=` — optional case-insensitive partial match on title, description, department, skills. Without `q` the response is unchanged.
- `GET /api/applications/mine` — also returns `interview_status`, `employment_type`, and salary fields.

No routes renamed, no schema/migration changes.

**Note:** the hero "AI match" preview on the landing page is a labelled *example* illustration, not applicant data.


## Update: interview timer, withdraw/archive, themes, toasts, applicant messages

**Database (run once on an existing install):**
```bash
mysql -u root -p hr_ats < server/migrations/005_interview_timer_and_application_lifecycle.sql
```
New installs get everything from `server/schema.sql`.

**Interview timer.** The AI technical interview has a 20 minute limit. The server owns the deadline (`interview_sessions.expires_at`, measured on the database clock), so refreshing the page continues the same countdown and the browser clock cannot extend it. When time runs out the session is closed as `timed_out` (by the applicant's open page, or by a background sweeper every 15 seconds if they closed the tab) and no more answers are accepted. Interview statuses: `not_started` (no session yet), `in_progress`, `completed`, `timed_out`, `cancelled`. Skipped questions are stored with `skipped = 1` and no score, and are never counted as wrong answers.

**Interview API additions:** `POST /api/interviews/:applicationId/skip`, `POST /api/interviews/:applicationId/cancel`. Answer, skip and start all refuse to work once a session is ended or the application is withdrawn or archived.

**Application lifecycle.** New statuses `withdrawn` (applicant, `POST /api/applications/:id/withdraw`) and `archived` (HR, `PATCH /api/applications/:id/archive`, restore with `PATCH .../restore`). Nothing is deleted. Both cancel a live interview. Archived applications are hidden from the HR list and dashboard unless you filter by Archived.

**Resume viewing.** `GET /api/applications/:id/resume` still requires the JWT and only serves the owning applicant or the HR user who owns the job. The old link could not send the `Authorization` header, which caused "Not authenticated". The client now fetches the file as an authenticated blob (`client/src/utils/resume.js`) and opens PDFs and TXT in a new tab. DOCX files download. Add `?download=1` to force a download.

**Themes.** Light, Dark and System, saved in `localStorage` under `theme`. Colors are CSS variables in `client/src/styles.css` (`:root` for light, `html.dark` for dark), so components follow the theme automatically. An inline script in `index.html` prevents a flash on reload.

**Toasts and dialogs.** One system: `useToast()` from `context/ToastContext.jsx`. Confirmations use `components/ui/ConfirmDialog.jsx`. Dropdowns were replaced with `SegmentedControl` (few options) and `MenuSelect` (longer lists).

**Applicant messages.** `/messages` reuses the HR inbox component. New endpoints: `GET /api/messages/mine/conversations`, `GET /api/messages/unread-count`, `POST /api/messages/:applicationId/read`. Access rules are unchanged.

## Troubleshooting

**"Could not reach the server" / `ERR_CONNECTION_REFUSED` on `:4000`**
The browser can't reach the API. Check `curl http://localhost:4000/api/health` returns `{"ok":true}`. If the server prints
`Port 4000 is already in use`, stop the other process (an old copy, or the PHP version) or change `PORT`.
`npm run dev` restarts the server whenever you save a server file, and requests sent during that second fail,
so use `npm start` when testing uploads. The client calls the API on the same host the page was opened from
(port 4000); set `VITE_API_URL` in `client/.env` if the API lives elsewhere, and list every browser origin you use in
`CLIENT_URL` (comma-separated).

**Resume uploads / "Analyzing..." never finishes**
- PDFs are read with `pdf-parse/lib/pdf-parse.js` (importing the package root crashes under ESM). Scanned or
  image-only PDFs have no text layer; the upload is rejected with a message asking for pasted text.
- If AI screening fails (bad key or model ID, no credits, timeout, unparseable reply) the reason is stored in
  `applications.ai_error`, the applicant sees a "Try again" button, and HR sees the reason next to "Re-run AI".
  The server log has the full provider error. Check `OPENROUTER_MODEL` / `GEMINI_MODEL` against each provider's model list.
- Existing database? Run `server/migrations/006_add_ai_error.sql` (the server also adds the column on startup if it is missing).
