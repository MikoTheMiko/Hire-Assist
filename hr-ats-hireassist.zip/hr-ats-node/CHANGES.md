# Fixes in this build

## Why resume submission failed

- `server/src/services/resumeText.js`: PDFs now parse. The `pdf-parse` package root crashed on every PDF under ESM, so the import now points at `pdf-parse/lib/pdf-parse.js`. Extracted text is cleaned and capped.
- `server/src/routes/applications.routes.js`:
  - Unreadable files (scanned or corrupt PDFs) are rejected with a clear 400 before anything is saved, and rejected uploads are deleted from disk.
  - A double-click or two-tab race returns 409 instead of a 500.
  - Failed AI screening is no longer silent. The reason is stored in `ai_error`, pushed over the socket, and retryable through `POST /applications/:id/retry-screening` (applicant) or `rerun-ai` (HR).
- `server/src/services/aiClient.js`:
  - Request timeouts and network errors are handled and retried on the other provider instead of hanging.
  - Fallback to the other provider now also covers a wrong model ID, a rejected key, or an unconfigured primary.
  - Truncated replies are retried with a larger token limit instead of a useless "repair" prompt.
  - The Gemini key moved from the URL to a header.
- `server/src/services/aiScreening.js`: token limit raised from 2000 to 6000 (`AI_SCREENING_MAX_TOKENS`). Replies without a valid score count as failures instead of leaving "Analyzing..." forever.
- `server/src/middleware/upload.js`, `server/src/index.js`: wrong file type or file too large now returns 400 with a readable message instead of 500.

## Why the browser showed `ERR_CONNECTION_REFUSED`

- `client/src/api.js`, `client/src/context/SocketContext.jsx`: the API and socket address follow the host the page was opened from (or `VITE_API_URL`) instead of a hardcoded `localhost`.
- `client/src/pages/Apply.jsx`: shows "Could not reach the server" instead of a generic message.
- `server/src/index.js`: if port 4000 is taken, the server now prints why and exits, instead of staying alive but serving nothing.
- `server/src/utils/origins.js`, `server/src/socket.js`: `CLIENT_URL` can list several origins, comma-separated.

## UI for failed screening

Applicant page ("Try again"), HR page (reason + Re-run AI), application cards, the HR table and the dashboard list now show "Failed" instead of "Analyzing...".

## Database

New `ai_error` column. See `server/migrations/006_add_ai_error.sql` (also in `schema.sql`). The server adds the column automatically on startup if it is missing.

## Not included on purpose

Your `.env`. Copy your existing `server/.env` back in, and rotate the API keys that were inside the zip you uploaded.

## Still to check on your side

`OPENROUTER_MODEL` and `GEMINI_MODEL` in `.env` must be real model IDs on your accounts. I could not verify them without your keys.
